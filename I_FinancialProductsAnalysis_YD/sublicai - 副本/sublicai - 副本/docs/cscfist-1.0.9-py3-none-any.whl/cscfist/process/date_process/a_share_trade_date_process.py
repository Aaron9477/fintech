# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/12/10 13:16
# @Author  : wangxybjs
# @File    : date_process.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
"""
A股交易日工具
"""
from cscfist.tools import TradeDateUtils

__all__ = ['AShareTradeDateUtils']


class AShareTradeDateUtils(TradeDateUtils):
    def __init__(self, begin_date=None, end_date=None):
        from cscfist.database.get_instance.wind_inst import wind_reader
        super().__init__(trade_date_list=wind_reader.get_a_share_calendar(
            begin_date=begin_date, end_date=end_date)['TRADE_DAYS'].tolist())

