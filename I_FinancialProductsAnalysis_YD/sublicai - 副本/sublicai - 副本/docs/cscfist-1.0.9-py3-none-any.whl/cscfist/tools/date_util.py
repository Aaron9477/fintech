import datetime
from typing import List, Optional, Union, Iterable

import numpy as np
import pandas as pd
from dateutil.relativedelta import relativedelta

__all__ = ["DateFormatTransfer", "NatureDateUtils", "ReportPeriodUtils", "TradeDateUtils"]


class DateFormatTransfer(object):
    """
    时间日期转换器
    """

    @staticmethod
    def date2str(date: Optional[datetime.date], fmt='%Y%m%d') -> str:
        """
        将时间戳格式转换为字符串

        Args:
            date: 时间格式变量
            fmt: 转换后的字符串格式

        Returns:
            转换后的字符串

        Examples:
            >>> DateFormatTransfer.date2str(datetime.datetime.now().date())
            '20220128'
        """
        res = None
        if date is not None and not (isinstance(date, float) and np.isnan(date)):
            res = date.strftime(fmt)
        return res

    @staticmethod
    def str2date(date_str: Optional[str], fmt='%Y%m%d') -> datetime.date:
        """
        将字符串转换为时间格式

        Args:
            date_str: 时间字符串
            fmt: 时间字符串格式

        Returns:
            date格式

        Examples:
            >>> DateFormatTransfer.str2date("20220128")
            datetime.datetime(2022, 1, 28, 0, 0)
        """
        res = None
        if date_str is not None:
            res = datetime.datetime.strptime(date_str, fmt)
        return res


class NatureDateUtils(object):
    @staticmethod
    def get_cur_time(fmt="%Y%m%d%H%M%S"):
        return datetime.datetime.now().strftime(fmt)

    @staticmethod
    def get_cur_date(fmt="%Y%m%d"):
        return datetime.datetime.now().strftime(fmt)

    @staticmethod
    def align_dates(obj_list: List[Union[pd.Series, pd.DataFrame]]) -> List[Union[pd.Series, pd.DataFrame]]:
        """
        将对象obj_list内元素裁剪为公共时间

        Args:
            obj_list: Series或DataFrame列表, 其中index为需要对齐的时间

        Returns:
            与obj_list的格式一致, 只是index裁剪为inner join的形式

        Examples:
            >>> a = pd.Series([1, 2, 3], index=[1, 2, 3])
            >>> b = pd.DataFrame({"A": [1, 2, 3], "B": [2, 3, 4]}, index=[1, 3, 4])
            >>> a, b = NatureDateUtils.align_dates([a, b])
            >>> a
            1    1
            3    3
            dtype: int64
            >>> b
               A  B
            1  1  2
            3  2  3
        """
        date_list = pd.concat(obj_list, axis=1, join="inner").index
        for i in range(len(obj_list)):
            obj_list[i] = obj_list[i].reindex(date_list)
        return obj_list

    @staticmethod
    def align_to_benchmark(benchmark_date_list: Iterable, time_series: pd.Series) -> pd.Series:
        """
        时间序列对齐到基准日期, 在每个基准日期按照**当日最近一次公布的值(含当日)**填充

        例如基金净值对齐到交易日中
        输出的时间列表为基准的时间, 值列表的规则如下：
        ①若日期在基准中, 则取该日期对应的值
        ②若日期不在基准中, 则将该值向后填充到下一个最近的基准中
        ③若有多个值向后填充到下一个最近基准, 则取下个最近基准前最近的一个日期对应的值
        例如交易日为20211202, 20211203, 20211206, 20211207
        基金在20211202公布净值为1.1, 则20211202得到的净值为1.1, 符合①条件
        基金在20211204公布净值为1.2, 则将该净值向后推移到20211206, 符合②条件
        基金在20211205公布净值为1.3, 则将该净值向后推移到20211206, 基金在20211206没有公布净值, 则使用20211205的净值而非20211204的净值, 符合③条件
        基金在20211203、20211207没有公布净值, 分别按照20211202、20211205公布的净值填充

        Args:
            benchmark_date_list: 基准日期
            time_series: 被对齐的时间序列, 是Series的形式, index为日期

        Returns:
            对齐后的时间序列

        Examples:
            >>> benchmark_list = [20211202, 20211203, 20211206, 20211207]
            >>> nav_series = pd.Series([1.1, 1.2, 1.3], index=[20211202, 20211204, 20211205])
            >>> NatureDateUtils.align_to_benchmark(benchmark_list, nav_series)
            20211202    1.1
            20211203    1.1
            20211206    1.3
            20211207    1.3
            dtype: float64
        """
        benchmark_date_list = np.array(benchmark_date_list)
        benchmark_date_list = benchmark_date_list[benchmark_date_list >= time_series.index[0]]
        return time_series.asof(benchmark_date_list)

    @staticmethod
    def count_dates(begin_date: str, end_date: Optional[str] = None) -> int:
        """
        统计两日期之间的自然日数量
        Args:
            begin_date: 开始日期
            end_date: 结束日期, 若为None则取当日

        Returns:
            两日期之间的自然日数量

        Examples:
            >>> NatureDateUtils.count_dates("20220124", "20220128")
            4

        """
        if end_date is None:
            end_date = datetime.datetime.now()
        else:
            end_date = datetime.datetime.strptime(end_date, "%Y%m%d")

        return (end_date - datetime.datetime.strptime(begin_date, "%Y%m%d")).days

    @staticmethod
    def date_period_change(date: str, period: str) -> Optional[str]:
        """
        对某一日期加减周期

        Args:
            date: 日期
            period: 周期，{数字}{d, w, m, q, h, y}形式, 分别代表日、周、月、季、半年、年. 如1y, 3m等

        Returns:
            运算后的日期

        Examples:
            >>> NatureDateUtils.date_period_change("20210810", "-3q")
            '20201110'
        """
        num = int(period[:-1])
        date_type = period[-1]
        if date_type == "y":
            new_date = datetime.datetime.strptime(date, "%Y%m%d") + relativedelta(years=num)
        elif date_type == "h":
            new_date = datetime.datetime.strptime(date, "%Y%m%d") + relativedelta(months=6 * num)
        elif date_type == "q":
            new_date = datetime.datetime.strptime(date, "%Y%m%d") + relativedelta(months=3 * num)
        elif date_type == "m":
            new_date = datetime.datetime.strptime(date, "%Y%m%d") + relativedelta(months=num)
        elif date_type == "w":
            new_date = datetime.datetime.strptime(date, "%Y%m%d") + relativedelta(weeks=num)
        elif date_type == "d":
            new_date = datetime.datetime.strptime(date, "%Y%m%d") + relativedelta(days=num)
        else:
            return None
        res = datetime.datetime.strftime(new_date, "%Y%m%d")
        return res

    @staticmethod
    def get_cur_period_begin(date: str, period: str) -> Optional[str]:
        """
        获取本周期开始日

        Args:
            date: 日期
            period: 周期, 是d, w, m, q, h, y格式

        Returns:
            结果日期

        Examples:
            >>> NatureDateUtils.get_cur_period_begin("20220128", "w")
            '20220124'
        """
        if period == 'y':
            res = date[:4] + '0101'
        elif period == 'h':
            month = (int(date[4:6]) - 1) // 6 * 6 + 1
            res = f"{date[:4]}{str(month).zfill(2)}01"
        elif period == 'q':
            month = 3 * ((int(date[4:6]) - 1) // 3) + 1
            res = f"{date[:4]}{str(month).zfill(2)}01"
        elif period == 'm':
            res = date[:6] + '01'
        elif period == 'w':
            date_time = datetime.datetime.strptime(date, '%Y%m%d')
            date_time = date_time - datetime.timedelta(days=date_time.weekday())
            res = date_time.strftime('%Y%m%d')
        else:
            res = None
        return res

    @staticmethod
    def get_cur_period_end(date: str, period: str) -> Optional[str]:
        """
        获取本周期期末

        Args:
            date: 日期
            period: 周期, 是d, w, m, q, h, y格式

        Returns:
            结果日期

        Examples:
            >>> NatureDateUtils.get_cur_period_end("20220128", "w")
            '20220130'
        """
        next_2_period_date = NatureDateUtils.date_period_change(date, f"1{period}")
        next_period_begin = NatureDateUtils.get_cur_period_begin(next_2_period_date, period)
        res = NatureDateUtils.date_period_change(next_period_begin, '-1d')
        return res

    @classmethod
    def align_time_series(cls, benchmark_date_list, time_series: pd.Series):
        benchmark_date_list = np.array(benchmark_date_list)
        date_list = np.array(time_series.index)
        value_list = np.array(time_series.values)
        if len(date_list) == 0:
            return pd.Series([])
        date_list_aligned = benchmark_date_list[benchmark_date_list >= date_list[0]]
        idx = date_list.searchsorted(date_list_aligned, side="right") - 1
        value_list_aligned = value_list[idx]
        return pd.Series(value_list_aligned, index=date_list_aligned)

    @staticmethod
    def get_dates(start: str, end: str, step='1d', is_include_end=True) -> List[str]:
        """
        获取起止时间内所有自然日, 可传入不同周期步长

        Args:
            start: 开始时间
            end: 结束时间
            step: 步长
            is_include_end: 是否包括末尾日期

        Returns:
            时间列表

        Examples:
            >>> NatureDateUtils.get_dates("20210128", "20220128", step="3m")
            ['20210128', '20210428', '20210728', '20211028', '20220128']
        """
        if not step[0].isdigit():
            step = f'1{step}'
        res = []
        cur = start
        while 1:
            res.append(cur)
            cur = NatureDateUtils.date_period_change(cur, step)

            if is_include_end:
                flag = cur > end
            else:
                flag = cur >= end
            if flag:
                break
        return res

    @staticmethod
    def get_end_date() -> str:
        """
        获取数据就绪时间, 即22点. 如果是当日0点-22点, 则最新截止日为前一日, 如果是当日22点-24点, 则最新截止日为当日

        Returns:
            数据就绪时间

        Examples:
            >>> NatureDateUtils.get_end_date()
            '20220127' # 与运行具体时间有关
        """
        cur_date = datetime.datetime.now().strftime('%Y%m%d')
        if datetime.datetime.now().hour >= 22:
            end_date = cur_date
        else:
            pre_day = NatureDateUtils.date_period_change(cur_date, '-1d')
            end_date = pre_day
        return end_date

    @staticmethod
    def get_last_period_begin(date: str, period: str) -> Optional[str]:
        """
        获取上一周期的期初自然日

        Args:
            date: 日期
            period: 周期

        Returns:
            上一周期的期初自然日

        Examples:
            >>> NatureDateUtils.get_last_period_begin("20220128", "w")
            '20220117'
        """

        last_end = NatureDateUtils.get_last_period_end(date, period)
        res = NatureDateUtils.get_cur_period_begin(last_end, period)
        return res

    @staticmethod
    def get_last_period_end(date: str, period: str) -> Optional[str]:
        """
        获取上一周期的期末自然日

        Args:
            date: 日期
            period: 周期

        Returns:
            上一周期的期末自然日

        Examples:
            >>> NatureDateUtils.get_last_period_end("20220128", "w")
            '20220123'
        """
        cur_period_begin = NatureDateUtils.get_cur_period_begin(date, period)
        res = NatureDateUtils.date_period_change(cur_period_begin, '-1d')
        return res

    @staticmethod
    def get_next_period_begin(date: str, period: str) -> Optional[str]:
        """
        获取下一周期的期初自然日

        Args:
            date: 日期
            period: 周期

        Returns:
            下一周期的期初自然日

        Examples:
            >>> NatureDateUtils.get_next_period_begin("20220128", "w")
            '20220131'
        """
        cur_period_end = NatureDateUtils.get_cur_period_end(date, period)
        res = NatureDateUtils.date_period_change(cur_period_end, '1d')
        return res

    @staticmethod
    def get_next_period_end(date: str, period: str) -> Optional[str]:
        """
        获取下一周期的期末自然日

        Args:
            date: 日期
            period: 周期

        Returns:
            下一周期的期末自然日

        Examples:
            >>> NatureDateUtils.get_next_period_end("20220128", "w")
            '20220206'
        """
        next_period_begin = NatureDateUtils.get_next_period_begin(date, period)
        res = NatureDateUtils.get_cur_period_end(next_period_begin, period)
        return res

    @staticmethod
    def get_now_time(fmt='%Y%m%d %X') -> str:
        """
        获取当前时间

        Args:
            fmt: str, 时间格式

        Returns:
            当前时间

        Examples:
            >>> NatureDateUtils.get_now_time()
            '20220128 12:14:57'
        """
        return datetime.datetime.now().strftime(fmt)

    @staticmethod
    def get_period_order(date: str, period: str = "w") -> str:
        """
        返回周期序, 若周期不为年, 则格式为"年份+周期符号+周期序", 如2021W2; 若周期为年, 则格式为年份, 如2013

        Args:
            date: 日期
            period: 周期, ["w", "m", "q", "h", "y"]

        Returns:
            周期序

        Examples:
            >>> NatureDateUtils.get_period_order("20210106", "w") # 20210101为周五, 则20201228-20210103为第53周, 20210106为第1周
            '2021W01'
            >>> NatureDateUtils.get_period_order("20201107", "m")
            '2020M11'
            >>> NatureDateUtils.get_period_order("20201107", "y")
            '2020'

        """
        year = date[:4]
        if period == "w":
            year, week_order, week_num = datetime.datetime.strptime(date, '%Y%m%d').isocalendar()
            return f"{year}W{str(week_order).zfill(2)}"
        if period == "m":
            return f"{year}M{date[4:6]}"
        if period == "q":
            month = int(date[4:6])
            return f"{year}Q{(month - 1) // 3 + 1}"
        if period == "h":
            month = int(date[4:6])
            return f"{year}H{(month - 1) // 6 + 1}"
        if period == "y":
            return year

    @staticmethod
    def get_period_end_date_list(begin_date, end_date, period):
        """
        获取起止时间内周期末时间列表
        """
        res = []
        cur_date = NatureDateUtils.get_cur_period_end(begin_date, period)
        while cur_date <= end_date:
            res.append(cur_date)
            cur_date = NatureDateUtils.get_next_period_end(cur_date, period)
        return res


class ReportPeriodUtils(object):
    @staticmethod
    def get_last_report_period(date: str, report_period_type: Optional[str] = None) -> str:
        """
        获取当前日期以前最近的报告期

        Args:
            date: 当前日期
            report_period_type: 报告期类型,若为None, 则取前一个季度报告期, 若不为None, 则为单季度形式"0331", "0630", "0930", "1231"

        Returns:
            报告期列表

        Examples:
            >>> ReportPeriodUtils.get_last_report_period("20210810", "0930")
            '20200930'
        """
        if report_period_type is None:
            return NatureDateUtils().get_last_period_end(date, 'q')
        else:
            year = date[:4]
            if date > year + report_period_type:
                return f"{year}{report_period_type}"
            else:
                return f"{int(year) - 1}{report_period_type}"

    @staticmethod
    def get_dates(begin_date: str, end_date: str) -> List[str]:
        """
        获取起止时间内的报告期, 包括起止时间

        Args:
            begin_date: 开始时间
            end_date: 结束时间

        Returns:
            报告期列表

        Examples:
            >>> ReportPeriodUtils.get_dates("20190101", "20210101")
            ['20190331', '20190630', '20190930', '20191231', '20200331', '20200630', '20200930', '20201231']
        """
        date_list = []
        cur_quarter_end = NatureDateUtils().get_cur_period_end(begin_date, 'q')
        while cur_quarter_end <= end_date:
            date_list.append(cur_quarter_end)
            new_year = cur_quarter_end[:4]
            month_day = cur_quarter_end[4:]
            if month_day == '1231':
                new_year = str(int(new_year) + 1)
            new_month_day = {'0331': '0630', '0630': '0930', '0930': '1231', '1231': '0331'}[month_day]
            cur_quarter_end = f'{new_year}{new_month_day}'
        return date_list


class TradeDateUtils(object):
    """
    交易日期相关API
    实际上可以拓展为任意日历的时间运算
    如果使用A股交易日历, 则可使用process中的AShareTradeDateUtils.
    """

    def __init__(self, trade_date_list: Union[np.ndarray, list]):
        if trade_date_list is None:
            raise ValueError("You must indicate trade_date_list of type np.ndarray or list instead of None")
        self.trade_date_list = np.array(trade_date_list)

    def count_trading_dates(self, start_date: str, end_date: str) -> int:
        """
        统计两个日期之间有多少交易日

        Args:
            start_date: 开始日期
            end_date: 结束日期

        Returns:
            交易日数量

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> TradeDateUtils(trade_date_list).count_trading_dates("20210730", "20210806")
            6
        """
        return self.trade_date_list.searchsorted(end_date, side='right') - self.trade_date_list.searchsorted(start_date)

    def date_period_change(self, date: str, period: str) -> str:
        """
        日期加减运算, 并对齐到交易日中

        Args:
            date: 日期
            period: 周期, {数字}{d, w, m, q, h, y}形式, 分别代表日、周、月、季、半年、年. 如1y, 3m等

        Returns:
            运算后的日期, 并对齐到交易日中

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> TradeDateUtils(trade_date_list).date_period_change("20150807", "6y")
            '20210806'
        """
        date = NatureDateUtils.date_period_change(date, period)
        res = self.get_pre_nearest_trading_date(date)
        return res

    def get_cur_period_begin(self, date: str, period: str) -> str:
        """
        获取当周期期初交易日

        Args:
            date: 日期
            period: 周期

        Returns:
            当周期期初交易日

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> TradeDateUtils(trade_date_list).get_cur_period_begin("20210806", "w")
            '20210802'
        """
        begin_date = NatureDateUtils.get_cur_period_begin(date, period)
        begin_trade_date = self.get_next_nearest_trading_date(begin_date)
        return begin_trade_date

    def get_cur_period_end(self, date: str, period: str) -> str:
        """
        获取当周期期末交易日

        Args:
            date: 日期
            period: 周期

        Returns:
            当周期期末交易日

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> TradeDateUtils(trade_date_list).get_cur_period_end("20210805", "w")
            '20210806'
        """
        end_date = NatureDateUtils.get_cur_period_end(date, period)
        end_trade_date = self.get_pre_nearest_trading_date(end_date)
        return end_trade_date

    def get_last_period_begin(self, date: str, period: str) -> str:
        """
        获取上周期期初交易日

        Args:
            date: 日期
            period: 周期

        Returns:
            上周期期初交易日

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> TradeDateUtils(trade_date_list).get_last_period_begin("20210805", "w")
            '20210730'
        """
        begin_date = NatureDateUtils.get_last_period_begin(date, period)
        begin_trade_date = self.get_next_nearest_trading_date(begin_date)
        return begin_trade_date

    def get_last_period_end(self, date: str, period: str) -> str:
        """
        获取上周期期末交易日

        Args:
            date: 日期
            period: 周期

        Returns:
            上周期期末交易日

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> TradeDateUtils(trade_date_list).get_last_period_end("20210805", "w")
            '20210730'
        """
        end_date = NatureDateUtils.get_last_period_end(date, period)
        end_trade_date = self.get_pre_nearest_trading_date(end_date)
        return end_trade_date

    def get_next_nearest_trading_date(self, date: str) -> str:
        """
        获取向后最新一次交易日

        Args:
            date: 日期

        Returns:
            向后最新一次交易日

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> TradeDateUtils(trade_date_list).get_next_nearest_trading_date("20210805")
            '20210805'
        """
        if self.is_trading_date(date):
            return date
        else:
            return self.get_next_trading_date(date)

    def get_next_period_begin(self, date: str, period: str) -> str:
        """
        获取下周期期初交易日

        Args:
            date: 日期
            period: 周期

        Returns:
            下周期期初交易日

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> TradeDateUtils(trade_date_list).get_next_period_begin("20210802", "w")
            '20210809'
        """
        begin_date = NatureDateUtils.get_next_period_begin(date, period)
        begin_trade_date = self.get_next_nearest_trading_date(begin_date)
        return begin_trade_date

    def get_next_period_end(self, date: str, period: str) -> str:
        """
        获取下周期期末交易日

        Args:
            date: 日期
            period: 周期

        Returns:
            下周期期末交易日

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> TradeDateUtils(trade_date_list).get_next_period_end("20210802", "w")
            '20210809'
        """
        end_date = NatureDateUtils.get_next_period_end(date, period)
        end_trade_date = self.get_pre_nearest_trading_date(end_date)
        return end_trade_date

    def get_next_trading_date(self, date: str, n: int = 1) -> str:
        """
        获取向后n个交易日对应日期

        Args:
            date: 日期
            n: 日期个数

        Returns:
            向后n个交易日对应日期

        Examples:
            >>> trade_date_list = ['20210809', '20210810', '20210811']
            >>> TradeDateUtils(trade_date_list).get_next_trading_date("20210810")
            '20210811'
        """
        pos = self.trade_date_list.searchsorted(date, side='right')
        if pos + n > len(self.trade_date_list):
            return self.trade_date_list[-1]
        else:
            return self.trade_date_list[pos + n - 1]

    def get_pre_nearest_trading_date(self, date: str) -> str:
        """
        获取向前最新一次交易日

        Args:
            date: 日期

        Returns:
            向前最新一次交易日

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> TradeDateUtils(trade_date_list).get_pre_nearest_trading_date("20210801")
            '20210730'
        """
        if self.is_trading_date(date):
            return date
        else:
            return self.get_previous_trading_date(date)

    def get_previous_trading_date(self, date: str, n: int = 1) -> str:
        """
        获取向前n个交易日对应日期

        Args:
            date: 日期
            n: 日期个数

        Returns:
            向前n个交易日对应日期

        Examples:
            >>> trade_date_list = ['20210809', '20210810', '20210811']
            >>> TradeDateUtils(trade_date_list).get_previous_trading_date("20210810")
            '20210809'
        """
        pos = self.trade_date_list.searchsorted(date)
        if pos >= n:
            return self.trade_date_list[pos - n]
        else:
            return self.trade_date_list[0]

    def get_trade_dates(self, begin_date: str = None, end_date: str = None, period='d', cut_last=True) -> np.ndarray:
        """
        获取交易日期列表

        Args:
            begin_date: 开始日期
            end_date: 结束日期

        Returns:
            范围在开始和结束日期之间的日期列表

        Examples:
            >>> TradeDateUtils().get_trade_dates("20210730", "20210810")
            ['20210730' '20210802' '20210803' '20210804' '20210805' '20210806' '20210809' '20210810']
        """
        if begin_date is None:
            begin_index = 0
        else:
            begin_index = self.trade_date_list.searchsorted(begin_date)
        if end_date is None:
            end_index = len(self.trade_date_list)
        else:
            end_date = self.get_pre_nearest_trading_date(end_date)
            end_index = self.trade_date_list.searchsorted(end_date)  # 结束日期若为交易日, 则取该日, 若非交易日, 取前一个交易日
        res = self.trade_date_list[begin_index:end_index + 1]
        if len(res) == 0:
            return res
        if period != 'd':
            df = pd.DataFrame({"date": res})
            df["period"] = df["date"].apply(lambda x: NatureDateUtils.get_period_order(x, period))
            df = df.groupby("period").apply(lambda x: x.sort_values(by='date', ascending=False).iloc[0]).sort_values(
                by='date')
            if cut_last:
                if not self.is_period_last_trade_date(df['date'].max(), period):
                    df = df.iloc[:-1]
            res = df["date"].values
        return res

    def get_trade_date_list(self, begin_date: Optional[str], end_date: Optional[str], period="d") -> np.ndarray:
        """
        获取起止时间内所有周期最后交易日

        Args:
            begin_date: 开始时间
            end_date: 结束时间
            period: 周期

        Returns:
            周期最后交易日列表

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> TradeDateUtils(trade_date_list).get_trade_date_list("20210730", "20210809", "w")
            array(['20210730', '20210806'], dtype=object)
        """
        if begin_date is None:
            begin_index = 0
        else:
            begin_index = self.trade_date_list.searchsorted(begin_date)
        if end_date is None:
            end_index = len(self.trade_date_list)
        else:
            end_date = self.get_pre_nearest_trading_date(end_date)
            end_index = self.trade_date_list.searchsorted(end_date)  # 结束日期若为交易日, 则取该日, 若非交易日, 取前一个交易日
        date_list = self.trade_date_list[begin_index:end_index + 1]
        if period == 'd':
            return date_list
        df = pd.DataFrame({'date': date_list})
        df['period'] = df['date'].apply(lambda x: NatureDateUtils.get_period_order(x, period))
        df = df.groupby('period').apply(lambda x: x.iloc[-1])
        date_list = df['date'].values
        date_list.sort()
        if not self.is_period_last_trade_date(date_list[-1], period):
            date_list = date_list[:-1]
        return date_list

    def transfer_period(self, time_series: pd.Series, end_date: str = None, period: str = "w") -> pd.Series:
        """
        对时间序列转换周期
        例如日频净值转换为周频

        Args:
            time_series: 时间序列
            end_date: 结束时间
                默认为time_series的最后日期. 之所以开放这个参数是因为有时时间序列不全, 希望向后补充
                例如基金净值最后公布时间为2022.1.14, 取period="w", end_date="20220128", 希望将每周的净值填充为2022.1.14的净值
                而不是将净值序列限制到2022.1.14
            period: 周期

        Returns:
            转换后的时间序列

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> time_series_ = pd.Series([1,2,3], index=["20210730", "20210803", "20210809"])
            >>> TradeDateUtils(trade_date_list).transfer_period(time_series_)
            20210730    1.0
            20210806    2.0
            dtype: float64
        """
        begin_date = time_series.index.min()
        if end_date is None:
            end_date = time_series.index.max()
        period_date_list = self.get_trade_date_list(begin_date, end_date, period)
        # 将时间序列对齐到交易日期的周期末时间
        res = NatureDateUtils.align_to_benchmark(period_date_list, time_series)
        return res

    def is_trading_date(self, date: str) -> bool:
        """
        判断是否是交易日

        Args:
            date: 待判断日期

        Returns:
            判断结果

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> TradeDateUtils(trade_date_list).is_trading_date("20210808")
            False
        """
        return date in self.trade_date_list

    def is_period_first_trade_date(self, date: str, period: str = "w") -> bool:
        """
        判断日期是否是周期期初交易日

        Args:
            date: 日期
            period: 周期["w", "m", "q", "h", "y"]

        Returns:
            判断结果

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> TradeDateUtils(trade_date_list).is_period_first_trade_date("20210806", "w") # 当日为周五, 并非当周第一个交易日
            False
        """
        prev_date = self.get_previous_trading_date(date)
        return self.is_trading_date(date) & (
                NatureDateUtils.get_period_order(prev_date, period) != NatureDateUtils.get_period_order(date,
                                                                                                        period))

    def is_period_last_trade_date(self, date: str, period: str = "w") -> bool:
        """
        判断日期是否是周期期末交易日

        Args:
            date: 日期
            period: 周期["w", "m", "q", "h", "y"]

        Returns:
            判断结果

        Examples:
            >>> trade_date_list = ['20210730', '20210802', '20210803', '20210804', '20210805', '20210806', '20210809']
            >>> TradeDateUtils(trade_date_list).is_period_last_trade_date("20210806", "w") # 当日为周五, 是当周最后一个交易日
            True
        """
        next_date = self.get_next_trading_date(date)
        return self.is_trading_date(date) & (
                NatureDateUtils.get_period_order(next_date, period) != NatureDateUtils.get_period_order(date,
                                                                                                        period))

    def get_common_interval_begin_end(self, date: str, interval: str = "1m"):
        """
        获取固定区间的开始结束日期
        Args:
            date: 日期
            interval: ['1m', '1h', '1y', '2y', ..., ’2018(单年度)']

        Returns:
            区间的开始结束日期
        """
        if interval.isdigit():  # 数字型表示单年度
            nature = f"{interval}{date[4:]}"
            interval_begin_date = self.get_last_period_end(nature, period='y')
            interval_end_date = self.get_cur_period_end(nature, period='y')
            interval_end_date = min(self.get_pre_nearest_trading_date(date), interval_end_date)
        else:
            interval_begin_date = self.date_period_change(date, f"-{interval}")
            interval_end_date = self.get_pre_nearest_trading_date(date)
        return interval_begin_date, interval_end_date

    def get_ready_trade_date(self):
        return self.get_pre_nearest_trading_date(NatureDateUtils.get_end_date())


