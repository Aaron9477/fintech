# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/8/16 16:01
# @Author  : lisl3|wangxybjs
# @File    : decorators.py
# @Project : fund_analysis
# @Function: 存放装饰器
# @Version : V0.0.1
# ------------------------------
import json
from types import FunctionType
import time

__all__ = ['is_hashable', 'class_cache', 'assure_redis_connection']


def is_hashable(variable) -> bool:
    """
    判断变量能否Hashable

    Args:
        variable: 变量
    """
    try:
        hash(variable)
        return True
    except TypeError:
        return False


def class_cache(func: FunctionType):
    """
    类定义中的缓存装饰器, 若函数名、入参相同, 则返回缓存中的值
    DataFrame等无法hash的入参无法放入缓存中

    Args:
        func: 传入的类内函数
    """

    def wrap(instance, *args, **kwargs):
        if not hasattr(instance, "cache"):
            setattr(instance, "cache", {})
        key = (func.__name__, args, json.dumps(kwargs))
        if is_hashable(key):
            if key in instance.cache:
                return instance.cache[key]
            else:
                res = func(instance, *args, **kwargs)
                instance.cache[key] = res
                return res
        else:
            res = func(instance, *args, **kwargs)
            return res

    return wrap


def assure_redis_connection(func: FunctionType, retry_times=3, sleep_time=10):
    """
    保证redis连接装饰器

    Args:
        func: 传入的参数
        retry_times: 重试次数
        sleep_time: 重试之前休眠的时间
    """

    def wrap(instance, *args, **kwargs):
        for i in range(retry_times):
            try:
                res = func(instance, *args, **kwargs)
                return res
            except:
                time.sleep(sleep_time)

    return wrap
