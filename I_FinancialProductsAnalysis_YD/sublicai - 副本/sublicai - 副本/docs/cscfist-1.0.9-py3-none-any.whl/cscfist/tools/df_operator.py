# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/2/8 9:50
# @Author  : wangxybjs
# @File    : df_option.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from typing import Tuple, List

import pandas as pd

__all__ = ['find_difference_between_df']


def find_difference_between_df(df_old: pd.DataFrame, df_new: pd.DataFrame) -> Tuple[List, List]:
    """
    查找两个DataFrame不同的地方, 用于redis时间序列的增量更新

    Args:
        df_old: 原DataFrame, 其中index必须是日期, 列必须与df_new一致
        df_new: 新DataFrame, 其中index必须是日期, 列必须与df_old一致

    Returns:
        idx_delete: df_old中存在但df_new不存在的index
        idx_append: df_old中不存在或但df_new中存在的index, 或均存在但内容不一致的记录
    """
    df_old_ = df_old.copy()
    df_new_ = df_new.copy()
    df_old_.index.name = "index"
    df_new_.index.name = "index"
    df_new_.reset_index(drop=False, inplace=True)
    df_old_.reset_index(drop=False, inplace=True)

    df_merge = df_old_.merge(df_new_, how="outer", suffixes=("_df1", "_df2"), indicator=True)
    idx_delete = (df_merge[df_merge["_merge"] == "left_only"])["index"].tolist()
    idx_append = (df_merge[df_merge["_merge"] == "right_only"])["index"].tolist()
    return idx_delete, idx_append


if __name__ == '__main__':
    df_old = pd.DataFrame({"trade_date": ["2000", "2001", "2002"], "fund_code": ["000001.OF", "000001.OF", "000001.OF"],
                           "indicator": [0.1, 0.2, 0.3]})

    df_new = pd.DataFrame({"trade_date": ["2000", "2001", "2004"], "fund_code": ["000001.OF", "000001.OF", "000001.OF"],
                           "indicator": [0.1, 0.4, 0.3]})
    # 需要删除: 2002, 需要追加: 2004, 需要更新: 2001(先删除再追加)
    find_difference_between_df(df_old, df_new)
