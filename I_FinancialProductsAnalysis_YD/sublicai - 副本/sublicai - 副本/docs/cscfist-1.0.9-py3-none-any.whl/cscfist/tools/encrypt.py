# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/8/25 18:14
# @Author  : wangxybjs
# @File    : encrypt.py
# @Project : cscfist
# @Function: 加解密
# @Version : V0.0.1
# ------------------------------
import base64
from Cryptodome.Cipher import AES

__all__ = ['encrypt_source', 'decrypt_des']


def add_to_16(value: str):
    """aes补足16位"""
    while len(value) % 16 != 0:
        value += '\0'
    return str.encode(value)  # 返回bytes


def encrypt_source(source_text: str, key='citic@csc') -> str:
    """
    加密器

    Args:
        source_text: 明文密码；
        key: 密钥。

    Returns:
        加密后的密码字符串
    """
    # 初始化加密器
    aes = AES.new(add_to_16(key), AES.MODE_ECB)
    # 先进行aes加密
    encrypt_aes = aes.encrypt(add_to_16(source_text))
    # 用base64转成字符串形式
    encrypted_text = str(base64.encodebytes(encrypt_aes), encoding='utf-8')  # 执行加密并转码返回bytes
    return encrypted_text


def decrypt_des(source_text: str, key='citic@csc'):
    """
    解密器

    Args:
        source_text: 加密后的密码字符串；
        key: 密钥。

    Returns:
        明文密码
    """
    # 初始化加密器
    aes = AES.new(add_to_16(key), AES.MODE_ECB)
    # 优先逆向解密base64成bytes
    base64_decrypted = base64.decodebytes(source_text.encode(encoding='utf-8'))
    # 执行解密密并转码返回str
    decrypted_text = str(aes.decrypt(base64_decrypted), encoding='utf-8').replace('\0', '')
    return decrypted_text


if __name__ == '__main__':
    password = '123456'
    encrypted_text = encrypt_source(password)
    decrypt_text = decrypt_des(encrypted_text)
    print(f"原密码: {password}, 加密密码: {encrypted_text}, 解密密码: {decrypt_text}")
