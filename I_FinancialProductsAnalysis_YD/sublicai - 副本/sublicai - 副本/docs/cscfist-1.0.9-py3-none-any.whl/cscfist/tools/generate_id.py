# -*- coding: utf-8 -*-

# ------------------------------
# @Time    : 2020/4/17
# @Author  : gao
# @File    : generate_id.py
# @Project : fund_analysis
# ------------------------------
import datetime
import uuid


__all__ = ['generate_id']


def generate_id():
    return uuid.uuid4().hex

def generate_update_time(fmt='%Y%m%d%H%M%S'):
    return datetime.datetime.now().strftime(fmt)