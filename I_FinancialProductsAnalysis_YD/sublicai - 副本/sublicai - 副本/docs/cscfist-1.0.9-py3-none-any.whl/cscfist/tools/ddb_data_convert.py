# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2023/1/17 9:07
# @Author  : wangxybjs
# @File    : ddb_data_convert.py
# @Project : fund_analysis_jjpg
# @Function: 
# @Version : V0.0.1
# ------------------------------
import datetime

import pandas as pd


class DDBDataConvert(object):
    @classmethod
    def py_datetime64_to_ddb_date(cls, value):
        return pd.to_datetime(str(value)).strftime("%Y.%m.%d")

    @classmethod
    def py_datetime_to_ddb_datetime(cls, value: datetime.datetime):
        return value.strftime("%Y.%m.%d %H:%M:%S")

    @classmethod
    def py_str_to_ddb_date(cls, value):
        return datetime.datetime.strptime(value, "%Y%m%d").strftime("%Y.%m.%d")

    @classmethod
    def py_str_to_ddb_datetime(cls, value):
        return datetime.datetime.strptime(value, "%Y%m%d").strftime("%Y.%m.%d %H:%M:%S")