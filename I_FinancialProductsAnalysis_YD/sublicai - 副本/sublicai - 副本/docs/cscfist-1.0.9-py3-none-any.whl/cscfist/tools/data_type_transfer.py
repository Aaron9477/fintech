# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/2/10 10:37
# @Author  : wangxybjs
# @File    : data_type_transfer.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from typing import List, Dict

import pandas as pd

__all__ = ['transfer_input_to_dict_list', 'transfer_input_to_df']


def transfer_input_to_dict_list(dict_list_or_dataframe):
    """
    将字典/DataFrame或其列表转为字典列表
    """
    save_list = dict_list_or_dataframe
    if not isinstance(dict_list_or_dataframe, List):
        save_list = [dict_list_or_dataframe]
    dict_list = []
    for d in save_list:
        if isinstance(d, Dict):
            dict_list.append(d)
        elif isinstance(d, pd.DataFrame):
            dict_list.extend(d.to_dict(orient='records'))
    return dict_list


def transfer_input_to_df(dict_list_or_dataframe):
    """
    將字典/DataFrame或列表转为DataFrame
    """
    save_list = dict_list_or_dataframe
    if not isinstance(dict_list_or_dataframe, List):
        save_list = [dict_list_or_dataframe]
    df_list = []
    for d in save_list:
        if isinstance(d, pd.DataFrame):
            df_list.append(d)
        elif isinstance(d, Dict):
            df_list.append(pd.DataFrame([d]))
    df = pd.concat(df_list)
    return df
