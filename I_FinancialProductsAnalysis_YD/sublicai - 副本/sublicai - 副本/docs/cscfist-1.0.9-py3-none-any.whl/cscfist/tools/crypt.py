import sys

from cryptography.fernet import Fernet

__all__ = ['decrypt_secret_option', 'encrypt_secret_option']


def decrypt_secret_option(f, secret_content: str, encoding: str = 'utf-8') -> str:
    secret_bytes = secret_content.encode(encoding=encoding)
    return f.decrypt(secret_bytes).decode()


def encrypt_secret_option(f, content: str, encoding: str = 'utf-8') -> str:
    content_bytes = content.encode(encoding=encoding)
    return f.encrypt(content_bytes).decode()


if __name__ == '__main__':
    if len(sys.argv) != 4:
        print("Usage: python crypt.py {key} {enc/dec} {content}")
        sys.exit(-1)

    key = sys.argv[1].encode(encoding='utf-8')
    op = sys.argv[2]
    content = sys.argv[3]

    f = Fernet(key)

    if op == 'enc':
        print(encrypt_secret_option(f, content))
    elif op == 'dec':
        print(decrypt_secret_option(f, sys.argv[3]))
    else:
        print("invalid operation, use 'enc' or 'dec' ")
