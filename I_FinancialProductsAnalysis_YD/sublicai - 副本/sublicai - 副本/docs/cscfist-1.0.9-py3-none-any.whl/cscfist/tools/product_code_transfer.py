# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/9/15 15:26
# @Author  : wangxybjs
# @File    : product_code_transfer.py
# @Project : workspaces_jjpg
# @Function: 
# @Version : V0.0.1
# ------------------------------

def transfer_fund_code_wind2dfcf(fund_code):
    """
    Wind的基金代码转为东方财富代码
    """
    return fund_code[:6]


def transfer_code(x: str):
    """
    朝阳永续的股票代码转为Wind代码
    Args:
        x:

    Returns:
    """
    if x.startswith("43") or x.startswith("83") or x.startswith("87") or x.startswith("88"):
        return x[:6] + ".BJ"
    elif x.startswith("6"):
        return x[:6] + ".SH"
    else:
        return x[:6] + ".SZ"


def transfer_stock_code(code: str, to: str = "RQAlpha"):
    """
    转换股票代码
    上海证券交易所证券代码分配规则
    https://biz.sse.com.cn/cs/zhs/xxfw/flgz/rules/sserules/sseruler20090810a.pdf

    深圳证券交易所证券代码分配规则
    http://www.szse.cn/main/rule/bsywgz/39744233.shtml

    Args:
        to: 转换成何种场景下的股票代码, 大小写不敏感
            "rqalpha": RQAlpha: 后缀为.XSHE/.XSHG形式
            "wind": 万得, 后缀为.SZ/.SH形式
            "dfcf": 东方财富
            "zyyx": 朝阳永续. 只保留前6位
    """
    if to.lower() == "rqalpha":
        if isinstance(code, str):
            code = int(code.split('.')[0])
        suffix = 'XSHG' if code >= 500000 else 'XSHE'
        return '%06d.%s' % (code, suffix)

    if to.lower() == "wind":
        if isinstance(code, str):
            code = int(code.split('.')[0])
        suffix = 'SH' if code >= 500000 else 'SZ'
        return '%06d.%s' % (code, suffix)

    if to.lower() == "zyyx":
        if isinstance(code, str):
            code = int(code.split('.')[0])
        return '%06d' % code
