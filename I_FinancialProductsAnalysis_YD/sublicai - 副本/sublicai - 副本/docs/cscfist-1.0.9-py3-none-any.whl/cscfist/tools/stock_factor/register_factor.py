# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/12/5 0:48
# @Author  : wangxybjs
# @File    : register_factor.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.get_instance.stock_factor_inst import sf_saver


def register(factor_id, source_code, factor_class_name, author, description=None, formula=None, is_calc=1,
             is_cross_stat=1, is_examine=1, begin_date_calc=None, begin_date_stat=None, begin_date_examine=None,
             dependency_factor_list=None,
             preprocess_method="winsorize_mad;neutralize_sw_total_market_value;standardize_zscore;fillna_sw1_ind_median",
             periods="1", **kwargs):
    """

    Args:
        factor_id: 因子ID, 如果在数据库有重复则会报错
        source_code: 源代码
        factor_class_name: 源代码中因子class名
        author: 作者
        description: 描述
        formula: 公式
        is_calc: 是否进行计算
        is_cross_stat: 是否进行横截面统计
        is_examine: 是否做因子检验
        begin_date_calc: 开始计算日期
        begin_date_stat: 开始统计日期
        begin_date_examine: 开始检验日期
        dependency_factor_list: 依赖因子, 格式请参考factor_basic表
        preprocess_method: 预处理方法
        periods: 周期
        **kwargs: 其他字段

    """
    kwargs.update(
        {"factor_id": factor_id, "source_code": source_code, "factor_class_name": factor_class_name, "author": author,
         "description": description, "formula": formula, "is_calc": is_calc, "is_cross_stat": is_cross_stat,
         "is_examine": is_examine, "begin_date_calc": begin_date_calc, "begin_date_stat": begin_date_stat,
         "begin_date_examine": begin_date_examine, "dependency_factor_list": dependency_factor_list,
         "preprocess_method": preprocess_method, "periods": periods})
    sf_saver.save(kwargs)
