# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/10/21 16:20
# @Author  : wangxybjs
# @File    : index_table_quick_find.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
"""
用于说明指数是从哪些表中获取的
用于get_all_index_close函数, 快速定位表
"""
INDEX_EOD_TABLE = {
    'CBA00602.CS': 'CBINDEXEODPRICES',
    'CBA00802.CS': 'CBINDEXEODPRICES',
    'CBA00702.CS': 'CBINDEXEODPRICES',
    'CBA04202.CS': 'CBINDEXEODPRICES',
    'CBA00622.CS': 'CBINDEXEODPRICES',
    'CBA00632.CS': 'CBINDEXEODPRICES',
    'CBA00642.CS': 'CBINDEXEODPRICES',
    'CBA00652.CS': 'CBINDEXEODPRICES',
    'CBA00662.CS': 'CBINDEXEODPRICES',
    'CBA03802.CS': 'CBINDEXEODPRICES',
    '000832.CSI': 'CBINDEXEODPRICES',
    '000906.SH': 'AINDEXEODPRICES',
    '885009.WI': 'CMFINDEXEOD',
    'h11001.CSI': 'CBINDEXEODPRICES',
    'h11025.CSI': 'CMFINDEXEOD'  # 该指数同时存在于AINDEXEODPRICES, 但已不维护
}
