# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2023/3/8 11:02
# @Author  : wangxybjs
# @File    : industry_type_config.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
INDUSTRY_DICT = {'SW': {'prefix': '76', 'margin': 1}}