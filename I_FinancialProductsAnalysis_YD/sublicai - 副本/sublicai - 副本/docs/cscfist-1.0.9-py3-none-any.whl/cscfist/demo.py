# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2023/6/16 18:11
# @author  : csc24044
# @File    : demo.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.read.read_wind import WindReader

a = WindReader().get_ipo_inquiry_details_count("20220101", "20230101")
print(a)