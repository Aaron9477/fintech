import logging
import os
import re
from typing import Any, Dict, List

from cryptography.fernet import Fernet
from jsonpath_ng import parse as jsonpath_parse
import toml

from cscfist.exceptions import AppConfigException, AppOptionExpandException, NoOptionError
from cscfist.tools.crypt import decrypt_secret_option

log = logging.getLogger(__name__)

_UNSET = 0

environment = 'dev'
if os.environ.get('ENV_CSCFIST') == 'PROD':
    environment = 'prod'


def expand_env_var(env_var):
    """
    Expands (potentially nested) env vars by repeatedly applying
    `expandvars` and `expanduser` until interpolation stops having
    any effect.
    """
    if not env_var:
        return env_var
    if not isinstance(env_var, str):
        return env_var
    while True:
        interpolated = os.path.expanduser(os.path.expandvars(str(env_var)))
        if interpolated == env_var:
            return interpolated
        else:
            env_var = interpolated


def decrypt_sensitive_items(options: Dict, fernet: Fernet,
                            sensitive_config_values: List[str]):
    def _decrypt_list_sensitive_items(sub_options: List, path: str = ''):
        i = 0
        for op in sub_options:
            if isinstance(op, list):
                _decrypt_list_sensitive_items(op, f"{path}.[{i}].")
            elif isinstance(op, dict):
                _decrypt_dict_sensitive_items(op, f"{path}.[{i}].")
            else:
                pass
            i = i + 1

    def _decrypt_dict_sensitive_items(sub_options: Dict, path: str = ''):
        for k, v in sub_options.items():
            if isinstance(v, dict):
                _decrypt_dict_sensitive_items(v, path + k + '.')
            elif isinstance(v, str):
                for secret in sensitive_config_values:
                    if secret in path + k:
                        v = decrypt_secret_option(fernet, v)
                        parser = jsonpath_parse('$.' + path + k)
                        parser.update(options, v)
                        break
            elif isinstance(v, list):
                _decrypt_list_sensitive_items(v, path + k)
            else:
                pass

    _decrypt_dict_sensitive_items(options)


def rec_merge(d1, d2):
    """
    递归合并字典
    :param d1: {"a": {"c": 2, "d": 1}, "b": 2}
    :param d2: {"a": {"c": 1, "f": {"zzz": 2}}, "c": 3, }
    :return: {'a': {'c': 1, 'd': 1, 'f': {'zzz': 2}}, 'b': 2, 'c': 3}
    """
    for key, value in d2.items():
        if key not in d1:
            d1[key] = value
        else:
            if isinstance(value, dict):
                rec_merge(d1[key], value)
            else:
                d1[key] = value
    return d1


def handle_secrets(options: Dict, fernet: Fernet,
                   sensitive_config_values: List[str]) -> Dict:
    decrypt_options = {}
    if not fernet:
        return decrypt_options
    for k, v in options.items():
        for secret in sensitive_config_values:
            if secret.upper() in k:
                decrypt_options.update({k: decrypt_secret_option(fernet, v)})
                break
    return decrypt_options


def expand_conf_var(option: str, conf: Dict, no_expand: bool = False) -> str:
    if no_expand:
        return option
    if not conf or not isinstance(conf, dict):
        return option
    if not isinstance(option, str):
        return option
    try:
        config_var_pattern = r'{[0-9a-zA-Z\.\-_\[\]]+}'
        config_var_keys = re.findall(config_var_pattern, option)
        config_var_dict = {}
        for k in config_var_keys:
            k = k[1:-1]
            parser = jsonpath_parse('$.' + k)
            match = parser.find(conf)
            if match:
                val = match[0].value
                val = expand_conf_var(expand_env_var(val), conf)
                config_var_dict.update({k: val})
            else:
                raise AppOptionExpandException
        for k in config_var_keys:
            option = re.sub(k, str(config_var_dict[k[1:-1]]), option)
        ret = option
    except KeyError:
        raise AppOptionExpandException
    return ret


def _default_config_file_path(file_name: str):
    templates_dir = os.path.join(os.path.dirname(__file__), 'config_templates')
    return os.path.join(templates_dir, file_name)


class BaseConfigSetting():
    def __init__(self, config_file_path: str = None):
        self._raw_conf = {}
        if config_file_path:
            self.read(config_file_path)

    @property
    def settings(self):
        return self._raw_conf

    def read(self, filename, encoding=None):
        with open(filename) as f:
            self._raw_conf = toml.loads(f.read())

    def read_str(self, conf_str: dict):
        self._raw_conf = toml.loads(conf_str)

    def has_option(self, key: str) -> bool:
        if self.get(key) is not None:
            return True
        return False

    def remove_option(self, key: str):
        jsonpath_expr = jsonpath_parse(key)
        jsonpath_expr.filter(lambda x: x, self._raw_conf)

    def update_option(self, key: str, val: Any):
        jsonpath_expr = jsonpath_parse(key)
        jsonpath_expr.update(self._raw_conf, key)

    def get(self, key: str, **kwargs) -> Any:
        jsonpath_expr = jsonpath_parse(key)
        match = jsonpath_expr.find(self._raw_conf)
        if match:
            return match[0].value
        else:
            return None

    def has_section(self, section: str) -> bool:
        if self.get_section(section):
            return True
        return False

    def get_section(self, section: str) -> Any:
        jsonpath_expr = jsonpath_parse(section)
        match = jsonpath_expr.find(self._raw_conf)
        if match and match[0].value:
            val = match[0].value
            if isinstance(val, str):
                return None
            elif isinstance(val, int) or isinstance(val, float):
                return None
            else:
                return val
        elif match and isinstance(match[0].value, bool):
            return None
        return None


class AppConfig:
    sensitive_config_values = {'password', 'secret'}
    deprecated_options = {}
    ignore_expand_options = ['log_format']
    ENV_VAR_PREFIX = 'SIMPORT__'

    def __init__(self,
                 sensitive_config_values: Dict = None,
                 deprecated_options: Dict = None,
                 ignore_expand_options: Dict = ['log_formart'],
                 config_path: str = None,
                 default_config_path: str = None,
                 fernet_key: str = None,
                 env_var_prefix: str = None):
        self.is_validated = False

        if sensitive_config_values:
            self.sensitive_config_values = sensitive_config_values
        if deprecated_options:
            self.deprecated_options = deprecated_options
        if ignore_expand_options:
            self.ignore_expand_options = ignore_expand_options

        self._default_conf = BaseConfigSetting()
        if default_config_path:
            self._default_conf.read(default_config_path)

        self._conf = BaseConfigSetting()
        if config_path:
            self._conf.read(config_path)
            if self._default_conf.settings:
                self._conf.settings.update(
                    dict(self._default_conf.settings, **self._conf.settings))

        self._fernet = None
        if fernet_key:
            self._fernet = Fernet(fernet_key)

        if env_var_prefix:
            self.ENV_VAR_PREFIX = env_var_prefix.upper() + '__'

    @property
    def default_config(self):
        return self._default_conf

    @property
    def config(self):
        return self._conf

    def init_fernet(self, fernet_key: str = ''):
        if fernet_key:
            self._fernet = Fernet(fernet_key)
        else:
            self._fernet = None

    def validate(self):
        # validate config dependencies
        self.is_validated = True

    def _env_var_name(self, key: str) -> str:
        key = key.replace('.', '__').replace('-', '_')
        return f'{self.ENV_VAR_PREFIX}{key.upper()}'

    def _get_env_var_option(self, key):
        # must have format SIMPORT__{SECTION}__{KEY} (note double underscore)
        env_var = self._env_var_name(key)
        if env_var in os.environ:
            return expand_env_var(os.environ[env_var])
        return None

    def get(self, key, **kwargs):
        key_pattern = '^[a-z0-9_.]+$'
        valid_key = re.search(key_pattern, str(key).lower())
        if not valid_key:
            raise AppConfigException(f"key [{key}] contains invalid charactor")

        key = str(key).lower()

        no_expand_conf_flag = False

        for pattern in self.ignore_expand_options:
            if pattern in key:
                no_expand_conf_flag = True
                break

        try:
            option = self._get_environment_variables(key)
            if option is not None:
                return option

            option = self._get_option_from_config_file(key, kwargs)
            if option is not None:
                return expand_conf_var(option, self._conf.settings,
                                       no_expand_conf_flag)
        except AppOptionExpandException:
            # 变量替换失败(conf配置少于option中的key、option内容无法匹配等)时不做变量替换
            log.warn(f"unable to expand variable in key [{key}]: {option} ")
            return option

        return None

    def getboolean(self, key, **kwargs):
        val = str(self.get(key, **kwargs)).lower().strip()
        if '#' in val:
            val = val.split('#')[0].strip()
        if val in ('t', 'true', '1'):
            return True
        elif val in ('f', 'false', '0'):
            return False
        else:
            raise AppConfigException(
                f'Failed to convert value to bool. Please check "{key}" key. '
                f'Current value: "{val}".')

    def getint(self, key, **kwargs):
        val = self.get(key, **kwargs)

        try:
            return int(val)
        except ValueError:
            raise AppConfigException(
                f'Failed to convert value to int. Please check "{key}" key. '
                f'Current value: "{val}".')

    def getfloat(self, key, **kwargs):
        val = self.get(key, **kwargs)

        try:
            self.update_option(key, val)
            return float(val)
        except ValueError:
            raise AppConfigException(
                f'Failed to convert value to float. Please check "{key}" key. '
                f'Current value: "{val}".')

    def _get_option_from_config_file(self, key, kwargs):
        # ...then the config file
        if self._conf and (self._conf.has_option(key) or 'fallback' in kwargs):
            return expand_env_var(self._conf.get(key, **kwargs))
        else:
            raise NoOptionError(f"key [{key}] not found in config")

    def _get_environment_variables(self, key):
        # first check environment variables
        return self._get_env_var_option(key)

    def decrypt_secrets(self):
        # decrypt all environment variables
        env_vars = dict(**os.environ)
        for k, v in env_vars.items():
            if self.ENV_VAR_PREFIX in k:
                decrypt_var = handle_secrets({k: v}, self._fernet,
                                             self.sensitive_config_values)
                os.environ[k] = decrypt_var[k]

        # decrypt all config variables
        decrypt_sensitive_items(self._conf.settings, self._fernet,
                                self.sensitive_config_values)

    def has_section(self, section: str) -> Any:
        section = section.lower()
        if self._conf.has_section(section):
            return True

        return False

    def get_section(self, section: str) -> Any:
        section = section.lower()
        ret_section = self._conf.get_section(section)
        if ret_section is not None:
            return ret_section
        else:
            raise NoOptionError(f"section [{section}] not found in config")

    def has_option(self, option):
        try:
            # Using self.get() to avoid reimplementing the priority order
            # of config variables (env, config, cmd, defaults)
            # UNSET to avoid logging a warning about missing values
            if self.get(option, fallback=_UNSET) is None:
                return False
            return True
        except (NoOptionError):
            return False

    def read(self, filename: str, encoding=None):
        self._conf.read(filename, encoding)
        if self._default_conf.settings:
            self._conf.settings.update(rec_merge(self._default_conf.settings, self._conf.settings))

    def remove_option(self, option, remove_default=True):
        """
        Remove an option if it exists in config from a file or
        default config. If both of config have the same option, this removes
        the option in both configs unless remove_default=False.
        """
        if self.has_option(option):
            self._conf.remove_option(option)

    def __getstate__(self):
        return {
            name: getattr(self, name)
            for name in [
                'is_validated',
                '_defaults',
            ]
        }


def get_fernet_key():
    """Get fernet key"""
    return os.environ.get('FERNET_KEY', '')


def get_app_home():
    """Get path to App Home"""
    return expand_env_var(os.environ.get('APP_HOME', './'))


def get_app_config():
    """
    获取项目的config
    """
    app_home = get_app_home()
    res = os.path.join(app_home, f'app_config_{environment}.toml')
    if os.path.isfile(res):
        return res


def get_home_config():
    """获取用户目录的config"""
    cscfist_path = "~/.cscfist"
    res = os.path.join(os.path.expanduser(cscfist_path), f'app_config_{environment}.toml')
    if os.path.isfile(res):
        return res


def get_module_config():
    """获取包默认config"""
    res = os.path.join(os.path.dirname(__file__), f'app_config_{environment}.toml')
    if os.path.isfile(res):
        return res


def get_env_config():
    if 'CSCFIST_APP_CONFIG' in os.environ:
        return expand_env_var(os.environ['CSCFIST_APP_CONFIG'])


def get_config_path():
    # 1. 环境变量
    config_path = get_env_config()
    if config_path is not None:
        return config_path
    # 2. 项目的配置
    config_path = get_app_config()
    if config_path is not None:
        return config_path
    # 3. 用户目录的配置
    config_path = get_home_config()
    if config_path is not None:
        return config_path
    # 4. 包自带的配置
    config_path = get_module_config()
    if config_path is not None:
        return config_path


def _parameterized_config_from_template(filename) -> str:
    TEMPLATE_START = '# ----------------------- TEMPLATE BEGINS HERE -----------------------\n'  # noqa

    path = _default_config_file_path(filename)
    with open(path) as fh:
        for line in fh:
            if line != TEMPLATE_START:
                continue
            return parameterized_config(fh.read().strip())
    raise RuntimeError(f"Template marker not found in {path!r}")


def parameterized_config(template):
    """
    Generates a configuration from the provided template + variables defined in
    current scope

    :param template: a config content templated with {{variables}}
    """
    all_vars = {k: v for d in [globals(), locals()] for k, v in d.items()}
    return template.format(**all_vars)


def initialize_config():
    """
    Load the App config files.

    Called for you automatically as part of the App boot process.
    """
    global FERNET_KEY, APP_HOME

    # default_config = _parameterized_config_from_template(
    #     'default_app_cfg.toml')

    conf = AppConfig()
    # conf.default_config.read_str(default_config)

    # Load normal config
    # if not os.path.isfile(APP_CONFIG):
    #     # from cryptography.fernet import Fernet
    #
    #     log.info('Creating new App config file in: %s', APP_HOME)
    #     pathlib.Path(APP_HOME).mkdir(parents=True, exist_ok=True)
    #
    #     # FERNET_KEY = Fernet.generate_key().decode()
    #
    #     with open(APP_CONFIG, 'w') as file:
    #         file.write(default_config)

    log.info("Reading the config from %s", APP_CONFIG)

    conf.read(APP_CONFIG)
    if FERNET_KEY:
        conf.init_fernet(FERNET_KEY)
    else:
        FERNET_KEY = conf.get("encrypt.fernet_key")
        conf.init_fernet(FERNET_KEY)
    conf.decrypt_secrets()

    return conf


APP_CONFIG = get_config_path()
FERNET_KEY = get_fernet_key()

conf = initialize_config()
conf.validate()
