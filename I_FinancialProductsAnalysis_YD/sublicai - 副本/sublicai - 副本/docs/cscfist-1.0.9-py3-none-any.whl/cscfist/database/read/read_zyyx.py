# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/3/17 14:32
# @Author  : wangxybjs
# @File    : read_zyyx.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------
import datetime
from typing import Optional

from sqlalchemy import DATE

from cscfist.database.connection.oracle_con import get_default_zyyx_connection
from cscfist.database.data_field.zyyx.zyyx_field_bak import CON_FORECAST_STK
from cscfist.database.data_field.zyyx_field import *
from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.model.db_model.rdb_model.rdb_operator_base import RdbBaseReader
from cscfist.tools.product_code_transfer import transfer_code, transfer_stock_code


class ZYYXReader(RdbBaseReader):
    def __init__(self, zyyx_connection: Optional[RdbConnectionBase] = None):
        """
        Args:
            zyyx_connection: 数据库连接。如果为None则使用默认配置连接
        """
        if zyyx_connection is None:
            zyyx_connection = get_default_zyyx_connection()
        super().__init__(db_connection=zyyx_connection)

    def get_der_prob_excess_stock(self, information_code=None, begin_date=None, end_date=None, trade_date=None,
                                  stock_code=None):
        """
        读取可能超预期信息提示表
        """
        table_name = DER_PROB_EXCESS_STOCK
        query = self.query(table_name)
        if information_code is not None:
            if isinstance(information_code, str):
                query = query.filter(table_name.INFORMATION_CODE == information_code)
            else:
                query = query.filter(table_name.INFORMATION_CODE.in_(information_code))
        df = self.batch_query(query, table_name.STOCK_CODE, stock_code)
        df["DECLARE_DATE"] = df["DECLARE_DATE"].apply(lambda x: x.strftime("%Y%m%d"))
        df["STOCK_CODE"] = df["STOCK_CODE"].apply(lambda x: transfer_code(x))
        if begin_date is not None:
            df = df[df["DECLARE_DATE"] >= begin_date]
        if end_date is not None:
            df = df[df["DECLARE_DATE"] <= end_date]
        if trade_date is not None:
            df = df[df["DECLARE_DATE"] == trade_date]
        return df

    def get_der_prob_below_stock(self, information_code=None, begin_date=None, end_date=None, trade_date=None,
                                 stock_code=None):
        """
        读取可能低预期信息提示表
        """
        table_name = DER_PROB_BELOW_STOCK
        query = self.query(table_name)
        if information_code is not None:
            if isinstance(information_code, str):
                query = query.filter(table_name.INFORMATION_CODE == information_code)
            else:
                query = query.filter(table_name.INFORMATION_CODE.in_(information_code))
        df = self.batch_query(query, table_name.STOCK_CODE, stock_code)
        df["DECLARE_DATE"] = df["DECLARE_DATE"].apply(lambda x: x.strftime("%Y%m%d"))
        df["STOCK_CODE"] = df["STOCK_CODE"].apply(lambda x: transfer_code(x))
        if begin_date is not None:
            df = df[df["DECLARE_DATE"] >= begin_date]
        if end_date is not None:
            df = df[df["DECLARE_DATE"] <= end_date]
        if trade_date is not None:
            df = df[df["DECLARE_DATE"] == trade_date]
        return df

    def get_rpt_rating_adjust(self, begin_date, end_date, stock_code=None):
        table_name = RPT_RATING_ADJUST
        if begin_date is not None:
            begin_date = datetime.datetime.strptime(begin_date, "%Y%m%d")
        if end_date is not None:
            end_date = datetime.datetime.strptime(end_date, "%Y%m%d")
        query = self.query(table_name)
        if stock_code is not None:
            stock_code = transfer_stock_code(stock_code, to="zyyx")
            query = query.filter(table_name.STOCK_CODE == stock_code)
        query = self.filter_date(query, table_name.CURRENT_CREATE_DATE, begin_date, end_date, date_type=DATE)
        df = self.read_sql(query)
        df["CURRENT_CREATE_DATE"] = df["CURRENT_CREATE_DATE"].apply(lambda x: x.strftime("%Y%m%d"))
        df["STOCK_CODE"] = df["STOCK_CODE"].apply(lambda x: transfer_code(x))
        return df

    def get_rpt_earnings_adjust(self, begin_date, end_date):
        table_name = RPT_EARNINGS_ADJUST
        if begin_date is not None:
            begin_date = datetime.datetime.strptime(begin_date, "%Y%m%d")
        if end_date is not None:
            end_date = datetime.datetime.strptime(end_date, "%Y%m%d")
        query = self.query(table_name)
        query = self.filter_date(query, table_name.CURRENT_CREATE_DATE, begin_date, end_date, date_type=DATE)
        df = self.read_sql(query)
        df["CURRENT_CREATE_DATE"] = df["CURRENT_CREATE_DATE"].apply(lambda x: x.strftime("%Y%m%d"))
        df["STOCK_CODE"] = df["STOCK_CODE"].apply(lambda x: transfer_code(x))
        return df

    def get_con_forecast_stk(self, begin_date=None, end_date=None, trade_date=None, stock_code=None):
        table_name = CON_FORECAST_STK
        if begin_date is not None:
            begin_date = datetime.datetime.strptime(begin_date, "%Y%m%d")
        if end_date is not None:
            end_date = datetime.datetime.strptime(end_date, "%Y%m%d")
        if trade_date is not None:
            trade_date = datetime.datetime.strptime(trade_date, "%Y%m%d")
        query = self.query(table_name)
        query = self.filter_date(query, table_name.CON_DATE, begin_date, end_date, trade_date, date_type=DATE)
        df = self.batch_query(query, table_name.STOCK_CODE, stock_code)
        df["CON_DATE"] = df["CON_DATE"].apply(lambda x: x.strftime("%Y%m%d"))
        df["STOCK_CODE"] = df["STOCK_CODE"].apply(lambda x: transfer_code(x))
        return df


if __name__ == '__main__':
    print(ZYYXReader().get_der_prob_excess_stock("213"))
