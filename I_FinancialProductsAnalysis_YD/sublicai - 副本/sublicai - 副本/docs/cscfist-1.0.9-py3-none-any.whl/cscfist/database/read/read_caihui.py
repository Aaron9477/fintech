# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2023/3/30 10:53
# @Author  : wangxybjs
# @File    : read_caihui.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from typing import Optional, Union

from cscfist.database.data_field.caihui_field import *
from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.model.db_model.rdb_model.rdb_operator_base import RdbBaseReader


class CaiHuiReader(RdbBaseReader):
    def __init__(self, ch_connection: Optional[RdbConnectionBase] = None):
        """
        Args:
            ch_connection: 数据库连接。如果为None则使用默认配置连接
        """
        if ch_connection is None:
            from cscfist.database.connection.oracle_con import get_default_caihui_connection
            ch_connection = get_default_caihui_connection()
        super().__init__(db_connection=ch_connection)

    def get_tq_qt_index(self, index_code: Union[str, list, None] = None, index_name: Union[str, list, None] = None,
                        begin_date: str = None, end_date: str = None, price_date: str = None, columns=None):
        """
        获取指数行情表TQ_QT_INDEX
        """
        table_name = TQ_QT_INDEX
        query = self.query(table_name, columns)
        query = self.filter_date(query, table_name.TRADEDATE, begin_date, end_date, price_date)
        if index_code is not None:
            df = self.batch_query(query, table_name.SECODE, index_code)
        else:
            df = self.batch_query(query, table_name.INDEXNAME, index_name)
        return df

    def get_tq_qt_indexestimate(self, index_code: Union[str, list, None] = None,
                                index_name: Union[str, list, None] = None, begin_date: str = None, end_date: str = None,
                                price_date: str = None, columns=None):
        """
        获取指数估值指标表TQ_QT_INDEXESTIMATE
        """
        table_name = TQ_QT_INDEXESTIMATE
        query = self.query(table_name, columns)
        query = self.filter_date(query, table_name.TRADEDATE, begin_date, end_date, price_date)
        if index_code is not None:
            df = self.batch_query(query, table_name.SECODE, index_code)
        else:
            df = self.batch_query(query, table_name.INDEXNAME, index_name)
        return df

    def get_tq_oa_stcode_by_sename(self, sename=None, columns=None):
        """根据证券全称获取证券内码表"""
        table_name = TQ_OA_STCODE
        query = self.query(table_name, columns)
        df = self.batch_query(query, table_name.SENAME, sename)
        return df

    def get_tq_oa_stcode_by_symbol(self, symbol=None, columns=None):
        """根据证券代码获取证券内码表"""
        table_name = TQ_OA_STCODE
        query = self.query(table_name, columns)
        df = self.batch_query(query, table_name.SYMBOL, symbol)
        return df

    def get_tq_qt_sgegpqt(self, se_code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
        """上金所基准价格行情表"""
        table_name = TQ_QT_SGEGPQT
        query = self.query(table_name, columns)
        query = self.filter_date(query, table_name.TRADEDATE, begin_date, end_date, trade_date)
        df = self.batch_query(query, table_name.SECODE, se_code)
        return df


if __name__ == '__main__':
    c = CaiHuiReader()
    print(c.get_tq_oa_stcode_by_sename("劲嘉股份"))
    print(c.get_tq_oa_stcode_by_symbol("200055"))
    print(c.get_tq_qt_sgegpqt("2060001407"))
