# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/9/13 13:36
# @Author  : wangxybjs
# @File    : redis_factory.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
import datetime
import json
from typing import Optional, Union, List, Dict

import numpy as np
import pandas as pd
from redis import Redis

from cscfist.config.redis_config import REDIS_DTYPE_DICT
from cscfist.tools.date_util import TradeDateUtils
from cscfist.tools.decorators import assure_redis_connection


class RedisFactoryMixin(object):
    def __init__(self, trade_date_list_func, redis_master: Optional[Redis] = None):
        if redis_master is None:
            from cscfist.database.connection.redis_con import get_default_redis_session
            redis_master = get_default_redis_session().redis_master
        self.r = redis_master
        self.get_trade_date_list_func = trade_date_list_func

    """
    +--------------+
    |   工具类函数   | 
    +--------------+
    """

    @assure_redis_connection
    def hset_with_expire(self, name: str, key: Optional[str] = None, value=None, mapping: Dict = None,
                         expire_time='22:00:00'):
        """
        redis存储, 设置有效时长为0点
        Args:
            name: Redis名称
            key: Redis的Key
            value: Redis的Value
            mapping: 需要保存的字典, 如果传入该参数, 则key和value参数失效
            expire_time: 失效时间, 设置为从当前时间开始经过下次该时点时失效. None则为不失效

        """
        self.r.hset(name, key, value, mapping)
        self.expire(name, expire_time=expire_time)

    @assure_redis_connection
    def expire(self, name, expire_time='22:00:00'):
        if expire_time is not None:
            expire_date_time = datetime.datetime.combine(datetime.date.today(),
                                                         datetime.datetime.strptime(expire_time, '%H:%M:%S').time())
            if expire_date_time < datetime.datetime.now():
                expire_date_time = expire_date_time + datetime.timedelta(days=1)
            expire_seconds = (expire_date_time - datetime.datetime.now()).total_seconds()
            self.r.expire(name, int(expire_seconds))

    @assure_redis_connection
    def exists(self, name) -> np.ndarray:
        if isinstance(name, str):
            res = self.r.exists(name)
        else:
            res = []
            for n in name:
                res.append(self.r.exists(n))
        return np.array(res).astype(bool)

    @assure_redis_connection
    def hexists(self, name, key):
        if isinstance(key, str):
            res = self.r.hexists(name, key)
        else:
            exist_keys = self.r.hkeys(name)
            res = np.isin(key, exist_keys)
        return np.array(res).astype(bool)

    @assure_redis_connection
    def hkeys(self, name) -> np.ndarray:
        return np.array(self.r.hkeys(name))

    @assure_redis_connection
    def hmget(self, name, keys):
        if keys is None:
            keys = self.r.hkeys(name)
        if isinstance(keys, str):
            res = [self.r.hget(name, keys)]
        else:
            res = []
            for i in range(0, len(keys), 100):
                batch = keys[i:i + 100]
                single_res = self.r.hmget(name, batch)
                res.extend(single_res)
        res = [json.loads(line) for line in res if line is not None]
        return res

    @assure_redis_connection
    def hget(self, name, key):
        return self.r.hget(name=name, key=key)

    @assure_redis_connection
    def hgetall(self, name):
        return self.r.hgetall(name)

    @assure_redis_connection
    def get_z_max_score(self, name) -> str:
        """
        获取name的最大得分, 注意返回str类型
        """
        max_score_list = self.r.zrevrange(name, 0, 0, withscores=True, score_cast_func=int)
        score_max = None
        if len(max_score_list) > 0:
            score_max = str(max_score_list[0][1])
        return score_max

    @assure_redis_connection
    def delete(self, name):
        return self.r.delete(name)

    @assure_redis_connection
    def zadd(self, name, mapping):
        return self.r.zadd(name, mapping)

    @assure_redis_connection
    def zrangebyscore(self, name, begin_date, end_date, withscores=True):
        return self.r.zrangebyscore(name, begin_date, end_date, withscores=withscores)

    """
    +-------------+
    |  时间序列工厂 | 
    +-------------+
    """

    def get_flag(self, redis_name):
        flag_name = f"{redis_name}:flag"
        res = self.hgetall(flag_name)
        return res

    def update_redis_data_time_series(self, redis_name: str, code_col: str, date_col: str, get_info_func, code=None,
                                      get_code_func=None, flag_expire_time='00:00:00', res_expire_time='00:00:00',
                                      is_del=False):
        """
        更新时间序列类型的redis内容为最新
        """
        flag_name = f"{redis_name}:flag"
        res_prefix = f"{redis_name}:res"
        dtype_dict = REDIS_DTYPE_DICT[redis_name]
        columns = list(dtype_dict.keys())

        # 取所有code
        if code is None:
            code = get_code_func()
        elif isinstance(code, str):
            code = [code]
        code = np.array(code).astype(object)
        # 判断code是否需要保存
        # 若flag存在, res存在, 则表示不需要保存
        # 若flag不存在, 或flag存在但是res不存在, 则需要补充
        res_names = [f"{redis_name}:res:{c}" for c in code]
        res_exists_list = self.exists(res_names)
        flag_exists_list = self.hkeys(flag_name)
        save_code_list = []
        # Case 1. 若res不存在: 当flag存在, 表示数据不同步, 需要全量查询, 当flag不存在, 表示首次保存, 需要全量查询
        # 因此只要res不存在, 都需要全量查询
        save_code_list.extend(code[~res_exists_list].tolist())
        # Case2. 若flag不存在, res存在, 也需要全量查询
        code_list_res_exists = code[res_exists_list]
        code_list_flag_not_exists = list(set(code) - set(flag_exists_list))
        save_code_list.extend(list(set(code_list_res_exists) & set(code_list_flag_not_exists)))
        # 都需要全量查询
        if len(save_code_list) > 0:
            df = get_info_func(code=save_code_list)
            if len(df) > 0:
                df = df[columns]
                for code, grouped in df.groupby(code_col):
                    res_name = f"{res_prefix}:{code}"
                    res_dict = grouped.set_index(date_col, drop=False).to_dict('index')
                    # res_dict = grouped.groupby(date_col).apply(lambda x: x.to_dict('records'))
                    # 序列化
                    mapping = {json.dumps(v, ensure_ascii=False): int(k) for k, v in res_dict.items()}
                    if is_del:
                        self.delete(res_name)
                    if len(mapping) > 0:
                        self.zadd(res_name, mapping)
                    self.hset_with_expire(flag_name, code, datetime.datetime.now().strftime("%Y%m%d"),
                                          expire_time=flag_expire_time)
                    self.expire(res_name, expire_time=res_expire_time)

    def get_redis_data_time_series(self, redis_name, code, begin_date, end_date, trade_date, get_code_func=None):
        """
        从Redis中取数据
        """
        # 处理code
        if code is None:
            code = get_code_func()
        elif isinstance(code, str):
            code = [code]
        # 处理日期
        if trade_date is not None:
            begin_date = trade_date
            end_date = trade_date
        if begin_date is None:
            begin_date = '19900101'
        if end_date is None:
            end_date = '99991231'

        dtype_dict = REDIS_DTYPE_DICT[redis_name]
        columns = list(dtype_dict.keys())

        df_res = pd.DataFrame(columns=columns)
        for c in code:
            res_name = f"{redis_name}:res:{c}"
            if not self.exists(res_name):
                continue
            redis_res = self.zrangebyscore(res_name, begin_date, end_date, withscores=True)
            if redis_res is None or len(redis_res) == 0:
                continue
            # 解析json格式
            res_dict = {str(int(time_tag)): json.loads(price) for price, time_tag in redis_res}
            df = pd.DataFrame(res_dict).T.reset_index(drop=True)
            # df = pd.DataFrame(reduce(lambda x, y: x + y, [json.loads(redis_res[i][0]) for i in range(len(redis_res))]))
            df_res = df_res.append(df)
            # 取数据类型
        df_res = df_res.astype(dtype_dict)
        return df_res

    def _get_time_series_factory_cache(self, redis_name, code_col, date_col, get_info_func, code=None, begin_date=None,
                                       end_date=None, trade_date=None, get_code_func=None, flag_expire_time='00:00:00',
                                       res_expire_time='00:00:00', is_del=False):
        """
        取时间序列形式Redis结果的工厂函数

        存储结果形式:
            存储flag, res三部分, 分别表示是否最新、存储结果
            flag是Key:Value形式, Key是代码, Value是保存时间. 当前已存结果每日0点自动清除
            res是Value:Score形式, Value是保存字符串, Score是日期

        执行逻辑:
            查看dtype是否已存, 未存则按照数据类型参考表判断数据类型, 已存则直接取.
            查看code是否在flag中, 若存在则表示redis已存最新, 若不存在则表示redis未存最新或从未存储
            对于未存最新的code, 进行补充, 取Redis已存最大值, 从Wind取最大值下一个交易日
            对于从未存储的code_list, 全量查询, 保存到Redis中
            完成以上补充或全量查询步骤后, 最后从Redis取所有的数据

        Args:
            redis_name: Redis保存的名称
            code_col: 代码对应的列
            date_col: 日期对应的列
            get_info_func: 取数据的函数, 参数必须是code形式, 返回必须有代码列和日期列
            code: 查询的代码
            begin_date: 以开始时间查询
            end_date: 以结束时间查询
            trade_date: 以单日查询
            get_code_func: 取distinct代码函数, 当传入code为None时生效

        Returns:
            DataFrame, 列与配置文件中一致
        """
        self.update_redis_data_time_series(redis_name, code_col, date_col, get_info_func, code, get_code_func,
                                           flag_expire_time=flag_expire_time, res_expire_time=res_expire_time,
                                           is_del=is_del)
        res = self.get_redis_data_time_series(redis_name, code, begin_date, end_date, trade_date, get_code_func)
        return res

    """
    +--------------+
    |   横截面工厂   | 
    +--------------+
    """

    def update_redis_data_cross_sectional(self, redis_name: str, code_col: str, get_info_func,
                                          code: Union[str, list, None] = None, get_code_func=None):
        dtype_dict = REDIS_DTYPE_DICT[redis_name]
        columns = list(dtype_dict.keys())
        if code is None:
            code = get_code_func()
        elif isinstance(code, str):
            code = [code]
        exist_list = self.hexists(redis_name, code)
        query_code_list = np.array(code)[~exist_list].tolist()
        if len(query_code_list) > 0:
            # 批量查询, 存储到Redis
            df = get_info_func(query_code_list)
            df = df[columns]
            res_mapping = {}
            for code, grouped in df.groupby(code_col):
                res_mapping[code] = json.dumps(grouped.to_dict('records'), ensure_ascii=False)
            res_mapping = {k: json.dumps(v, ensure_ascii=False) for k, v in res_mapping.items()}
            if len(res_mapping) > 0:
                self.hset_with_expire(redis_name, mapping=res_mapping)

    def get_redis_data_cross_sectional(self, redis_name: str, code: Union[str, list, None] = None, get_code_func=None):
        dtype_dict = REDIS_DTYPE_DICT[redis_name]
        if code is None:
            code = get_code_func()
        elif isinstance(code, str):
            code = [code]
        res = self.hmget(redis_name, code)
        res_list = []
        for line in res:
            res_list.extend(json.loads(line))
        df = pd.DataFrame(res_list, columns=dtype_dict.keys()).astype(dtype_dict)
        return df

    def _get_cross_sectional_factory(self, redis_name: str, code_col: str, get_info_func,
                                     code: Union[str, list, None], get_code_func=None):
        """
        横截面型Redis工厂函数
        Key为代码, Value为该代码对应的结果

        Args:
            redis_name: Redis保存的名称
            code_col: 代码对应列
            get_info_func: 取数据函数
            code: 查询的代码

        Returns:
            DataFrame, 列与columns一致
        """
        self.update_redis_data_cross_sectional(redis_name, code_col, get_info_func, code, get_code_func)
        res = self.get_redis_data_cross_sectional(redis_name, code, get_code_func)
        return res

    """
    +---------------+
    |  进入退出型工厂  | 
    +---------------+
    """

    def _get_entry_exit_factory(self, redis_name: str, code_col: str, begin_date_col: str,
                                end_date_col: str, get_info_func,
                                code: Union[str, List, None] = None,
                                begin_date: Optional[str] = None, end_date: Optional[str] = None,
                                trade_date: Optional[str] = None, is_cur: bool = True, get_code_func=None):
        """
        进入、退出类型Redis工厂函数

        Args:
            redis_name: Redis保存的名称
            code_col: 代码对应列
            begin_date_col: 进入日期列
            end_date_col: 退出日期列
            get_info_func: 取数据函数
            code: 查询代码
            begin_date: 开始日期
            end_date: 结束日期
            trade_date: 交易日期
            is_cur: 是否取最新, 如果为True, 则取最新状态, begin_date, end_date, trade_date失效
            get_code_func: 获取代码函数

        Returns:
            DataFrame, 列与columns一致
        """
        self.update_redis_data_cross_sectional(redis_name, code_col, get_info_func, code, get_code_func)
        df_res = self.get_redis_data_cross_sectional(redis_name, code, get_code_func)
        df_res.replace('nan', np.nan, inplace=True)
        df_res.replace('None', np.nan, inplace=True)
        df_res.dropna(subset=[begin_date_col], inplace=True)
        df_res[begin_date_col] = df_res[begin_date_col].astype(object)
        df_res[end_date_col] = df_res[end_date_col].astype(object)
        if begin_date is not None or end_date is not None or trade_date is not None:
            is_cur = False
        if is_cur:
            df_res = df_res[df_res[end_date_col].isna()]
        else:
            if begin_date is not None:
                df_res = df_res[df_res[begin_date_col] >= begin_date]
            if end_date is not None:
                df_res = df_res[(df_res[end_date_col] <= end_date) | (df_res[end_date_col].isna())]
            if trade_date is not None:
                df_res = df_res[(df_res[begin_date_col] <= trade_date) & (
                        (df_res[end_date_col].isna()) | (df_res[end_date_col] >= trade_date))]

        return df_res

    """
    +--------------+
    |  时间列表工厂  | 
    +--------------+
    """

    def update_redis_data_time_list(self, redis_name: str, code: str, get_info_func, get_code_func=None):
        """
        更新时间列表类型的redis内容为最新
        要求get_info_func当传入str时, 返回list
        """
        flag_name = f"{redis_name}:flag"
        res_prefix = f"{redis_name}:res"

        # 取所有code
        if code is None:
            code = get_code_func()
        elif isinstance(code, str):
            code = [code]
        code = np.array(code).astype(object)
        # 判断code是否需要保存
        # 若flag存在, res存在, 则表示不需要保存
        # 若flag不存在, res存在, 需要补充
        res_names = [f"{redis_name}:res:{c}" for c in code]
        res_exists_list = self.exists(res_names)
        flag_exists_list = self.hkeys(flag_name)
        # Case 1. 若res不存在: 当flag存在, 表示数据不同步, 需要全量查询, 当flag不存在, 表示首次保存, 需要全量查询
        # 因此只要res不存在, 都需要全量查询
        query_all_code_list = code[~res_exists_list].tolist()  # 需要全量查询的代码
        # Case2. 若flag不存在, res存在, 需要补充
        code_list_res_exists = code[res_exists_list]
        code_list_flag_not_exists = list(set(code) - set(flag_exists_list))
        supplement_code_list = list(set(code_list_res_exists) & set(code_list_flag_not_exists))
        # 全量查询
        if len(query_all_code_list) > 0:
            date_list_dict = get_info_func(code=query_all_code_list)
            if len(date_list_dict) > 0:
                for code, date_list in date_list_dict.items():
                    res_name = f"{res_prefix}:{code}"
                    # 序列化
                    mapping = {d: int(d) for d in date_list}
                    if len(mapping) > 0:
                        self.zadd(res_name, mapping)
                    self.hset_with_expire(flag_name, code, datetime.datetime.now().strftime("%Y%m%d"))
                    self.expire(res_name)

        # 增量补充
        for code in supplement_code_list:
            res_name = f"{res_prefix}:{code}"
            cur_max_date = self.get_z_max_score(res_name)
            query_begin_date = TradeDateUtils(self.get_trade_date_list_func()).get_next_trading_date(cur_max_date)
            date_list = get_info_func(code=code, begin_date=query_begin_date)
            if len(date_list) > 0:
                mapping = {d: int(d) for d in date_list}
                self.zadd(res_name, mapping)
            self.hset_with_expire(flag_name, code, datetime.datetime.now().strftime("%Y%m%d"))
            self.expire(res_name)

    def get_redis_data_time_list(self, redis_name, code, begin_date, end_date, get_code_func=None):
        """
        从Redis中取数据
        """
        # 处理code
        if code is None:
            code = get_code_func()
        elif isinstance(code, str):
            code = [code]
        # 处理日期
        if begin_date is None:
            begin_date = '19900101'
        if end_date is None:
            end_date = '99991231'

        res_dict = {}
        for c in code:
            res_name = f"{redis_name}:res:{c}"
            redis_res = self.zrangebyscore(res_name, begin_date, end_date, withscores=False)
            res_dict[c] = redis_res

        return res_dict

    def _get_time_list_factory_cache(self, redis_name, get_info_func, code=None, begin_date=None,
                                     end_date=None, get_code_func=None) -> Union[Dict, List]:
        """
        取时间序列形式Redis结果的工厂函数

        存储结果形式:
            存储flag, res三部分, 分别表示是否最新、存储结果
            flag是Key:Value形式, Key是代码, Value是保存时间. 当前已存结果每日0点自动清除
            res是Value:Score形式, Value是保存字符串, Score是日期

        执行逻辑:
            查看dtype是否已存, 未存则按照数据类型参考表判断数据类型, 已存则直接取.
            查看code是否在flag中, 若存在则表示redis已存最新, 若不存在则表示redis未存最新或从未存储
            对于未存最新的code, 进行补充, 取Redis已存最大值, 从Wind取最大值下一个交易日
            对于从未存储的code_list, 全量查询, 保存到Redis中
            完成以上补充或全量查询步骤后, 最后从Redis取所有的数据

        Args:
            redis_name: Redis保存的名称
            get_info_func: 取数据的函数
            code: 查询的代码
            begin_date: 以开始时间查询
            end_date: 以结束时间查询
            get_code_func: 取distinct代码函数, 当传入code为None时生效

        Returns:
            DataFrame, 列与配置文件中一致
        """
        self.update_redis_data_time_list(redis_name, code, get_info_func, get_code_func)
        res = self.get_redis_data_time_list(redis_name, code, begin_date, end_date, get_code_func)
        if isinstance(code, str):
            if len(res) > 0:
                return res[code]
            else:
                return []
        else:
            return res

    """
    +--------------+
    |  时间集合工厂  | 
    +--------------+
    例如基金的持股组合, 股票的财务报告等
    键为日期, HASH中key为代码, Value为代码在该日期对应数据
    """

    def update_redis_data_time_list_cross_sectional(self, redis_name: str, code_col, get_info_func, date: str = None,
                                                    get_date_func=None):
        dtype_dict = REDIS_DTYPE_DICT[redis_name]
        columns = list(dtype_dict.keys())
        # 1. 获取所有date
        if date is None:
            date = get_date_func()
        elif isinstance(date, str):
            date = [date]
        # 2. 取应该保存的date
        date_list_to_save = []
        for d in date:
            res_name = f'{redis_name}:{d}'
            if not self.exists(res_name):
                date_list_to_save.append(d)
        # 3. 保存
        for d in date_list_to_save:
            res_name = f'{redis_name}:{d}'
            df = get_info_func(d)
            df = df[columns]
            res_mapping = {}
            for code, grouped in df.groupby(code_col):
                res_mapping[code] = json.dumps(grouped.to_dict('records'), ensure_ascii=False)
            res_mapping = {k: json.dumps(v, ensure_ascii=False) for k, v in res_mapping.items()}
            if len(res_mapping) > 0:
                self.hset_with_expire(res_name, mapping=res_mapping)

    def get_redis_data_time_list_cross_sectional(self, redis_name, date, code=None, get_date_func=None):
        dtype_dict = REDIS_DTYPE_DICT[redis_name]
        if isinstance(code, str):
            code = [code]
        if date is None:
            date = get_date_func()
        if isinstance(date, str):
            date = [date]
        res_list = []
        for d in date:
            res_name = f'{redis_name}:{d}'
            res = self.hmget(res_name, code)
            for line in res:
                res_list.extend(json.loads(line))
        df = pd.DataFrame(res_list, columns=dtype_dict.keys()).astype(dtype_dict)
        return df

    def _get_time_list_cross_sectional_factory_cache(self, redis_name, code_col, get_info_func, date=None,
                                                     get_date_func=None, code=None):
        """
        取时间列表横截面形式Redis结果的工厂函数, 例如基金的持股组合, 股票的财务报告等
        键为日期, HASH中key为代码, Value为代码在该日期对应数据

        Args:
            redis_name: Redis保存的名称
            code_col: 代码列
            get_info_func: 取数据的函数
            date: 日期
            get_date_func: 获取日期函数
            code: 查询的代码

        Returns:
            DataFrame, 列与配置文件中一致
        """
        self.update_redis_data_time_list_cross_sectional(redis_name, code_col, get_info_func, date, get_date_func)
        res = self.get_redis_data_time_list_cross_sectional(redis_name, date, code, get_date_func)
        if isinstance(code, str):
            if len(res) > 0:
                return res[code]
            else:
                return []
        else:
            return res
