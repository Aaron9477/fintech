# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/9/14 13:33
# @Author  : wangxybjs
# @File    : get_ht_data.py
# @Project : workspaces_jjpg
# @Function: 
# @Version : V0.0.1
# ------------------------------
from typing import Optional, Union, List
import pandas as pd

from cscfist.database.connection.mysql_con import get_default_sf_connection
from cscfist.database.data_field.stock_factor.basic_info import *
from cscfist.database.data_field.stock_factor.factor_calculate import *
from cscfist.database.data_field.stock_factor.factor_summary import *
from cscfist.database.data_field.stock_factor.factor_test import *
from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.model.db_model.rdb_model.rdb_operator_base import RdbBaseReader


class StockFactorReader(RdbBaseReader):
    def __init__(self, sf_connection: Optional[RdbConnectionBase] = None):
        """
        Args:
            sf_connection: 数据库连接。如果为None则使用默认配置连接
        """
        if sf_connection is None:
            sf_connection = get_default_sf_connection()
        super().__init__(db_connection=sf_connection)

    def get_distinct_factor_dates(self, factor_id):
        table = FactorValue
        query = self.session.query(table)
        df = self.batch_query(query, table.factor_id, factor_id)
        date_list = df['trade_date'].tolist()
        date_list.sort()
        return date_list

    def get_factor_basic_info(self, factor_id=None, is_calc=None, is_cross_stat=None, is_examine=None):
        table = FactorBasic
        query = self.session.query(table)
        if is_calc is not None:
            query = query.filter(table.is_calc == is_calc)
        if is_cross_stat is not None:
            query = query.filter(table.is_cross_stat == is_cross_stat)
        if is_examine is not None:
            query = query.filter(table.is_examine == is_examine)
        df = self.batch_query(query, table.factor_id, factor_id)
        return df

    def get_factor_cal_date(self, factor_id, date):
        table = FactorCalFinishDate
        query = self.session.query(table).filter(table.factor_id == factor_id)
        df = self.batch_query(query, batch_column=table.trade_date, batch_value=date)
        res = []
        if len(df) > 0:
            res = df['trade_date'].tolist()
        return res

    def get_factor_value(self, factor_id: str, begin_date: Optional[str] = None, end_date: Optional[str] = None,
                         trade_date: Optional[str] = None, stock_code: Union[str, list, None] = None) -> pd.DataFrame:
        """
        获取因子值

        Args:
            factor_id: 因子ID
            begin_date: 开始时间
            end_date: 结束时间
            trade_date: 交易日期
            stock_code: 股票代码

        Returns:
            pd.DataFrame, index为日期, column为股票代码, value为因子值
        """
        table = FactorValue
        query = self.query(table).filter(table.factor_id == factor_id)
        query = self.filter_date(query, table.trade_date, begin_date, end_date, trade_date)
        df = self.batch_query(query, table.stock_code, stock_code)
        return df.pivot(index="trade_date", columns="stock_code", values="factor_value")

    def get_raw_factor_value(self, factor_id: str, begin_date: Optional[str] = None, end_date: Optional[str] = None,
                             trade_date: Optional[str] = None,
                             stock_code: Union[str, list, None] = None) -> pd.DataFrame:
        """
        获取因子值

        Args:
            factor_id: 因子ID
            begin_date: 开始时间
            end_date: 结束时间
            trade_date: 交易日期
            stock_code: 股票代码

        Returns:
            pd.DataFrame, index为日期, column为股票代码, value为因子值
        """
        table = RawFactorValue
        query = self.query(table).filter(table.factor_id == factor_id)
        query = self.filter_date(query, table.trade_date, begin_date, end_date, trade_date)
        df = self.batch_query(query, table.stock_code, stock_code)
        return df.pivot(index="trade_date", columns="stock_code", values="factor_value")

    def get_factor_cross_statistics(self, factor_id: str, pool_id: Optional[str] = None,
                                    begin_date: Optional[str] = None, end_date: Optional[str] = None,
                                    trade_date: Optional[str] = None):
        """
        因子截面描述性统计
        Args:
            factor_id: 因子ID
            pool_id:  股票池ID
            begin_date: 开始时间
            end_date: 结束时间
            trade_date: 交易日期

        Returns:

        """
        table = FactorCrossStatistics
        query = self.query(table).filter(table.factor_id == factor_id)
        if pool_id is not None:
            query = query.filter(table.pool_id == pool_id)
        query = self.filter_date(query, table.trade_date, begin_date, end_date, trade_date)
        df = self.read_sql(query)
        return df

    def get_factor_ic_test_daily(self, factor_id: str, pool_id: Optional[str] = None, period: Optional[str] = None,
                                 begin_date: Optional[str] = None, end_date: Optional[str] = None,
                                 trade_date: Optional[str] = None, is_accumulative_return: Union[int, str] = None):
        """
        获取IC值
        Args:
            factor_id: 因子ID
            pool_id: 因子ID
            period: 周期
            begin_date: 开始时间
            end_date: 结束时间
            trade_date: 交易日期
            is_accumulative_return: 收益率是否累积

        Returns:
            pd.DataFrame()
        """
        table = FactorIcTestDaily
        query = self.query(table).filter(table.factor_id == factor_id)
        if pool_id is not None:
            query = query.filter(table.pool_id == pool_id)
        if period is not None:
            query = query.filter(table.period == period)
        if is_accumulative_return is not None:
            query = query.filter(table.is_accumulative_return == is_accumulative_return)
        query = self.filter_date(query, table.trade_date, begin_date, end_date, trade_date)
        df = self.read_sql(query)
        return df

    def get_factor_ic_test_stat(self, factor_id: Union[str, List, None] = None, pool_id: Optional[str] = None,
                                period: Optional[str] = None,
                                interval: Optional[str] = None, begin_date: Optional[str] = None,
                                end_date: Optional[str] = None):
        """

        """
        table = FactorIcTestStat
        query = self.query(table)
        if pool_id is not None:
            query = query.filter(table.pool_id == pool_id)
        if period is not None:
            query = query.filter(table.period == period)
        if interval is not None:
            query = query.filter(table.interval == interval)
        if begin_date is not None:
            query = query.filter(table.begin_date >= begin_date)
        if end_date is not None:
            query = query.filter(table.end_date <= end_date)
        df = self.batch_query(query, table.factor_id, factor_id)
        # df = self.read_sql(query)
        return df

    def get_group_backtest_daily(self, factor_id: str, pool_id: str, begin_date: Optional[str] = None,
                                 end_date: Optional[str] = None,
                                 trade_date: Optional[str] = None, stock_group: Optional[str] = None,
                                 factor_group: Optional[str] = None):

        table = GroupBackTestDaily
        query = self.query(table).filter(table.factor_id == factor_id,
                                         table.pool_id == pool_id)
        if stock_group is not None:
            query = query.fiter(table.stock_group == stock_group)
        if factor_group is not None:
            query = query.filter(table.factor_group == factor_group)
        query = self.filter_date(query, table.trade_date, begin_date, end_date, trade_date)
        df = self.read_sql(query)
        return df

    def get_group_benchmark_backtest_daily(self, benchmark_code: str, begin_date: Optional[str] = None,
                                           end_date: Optional[str] = None,
                                           trade_date: Optional[str] = None):

        table = GroupBenchmarkBackTestDaily
        query = self.query(table).filter(table.benchmark_code == benchmark_code)
        query = self.filter_date(query, table.trade_date, begin_date, end_date, trade_date)
        df = self.read_sql(query)
        return df

    def get_group_backtest_accumulative_return(self, factor_id: str, pool_id: str,
                                               begin_date: Optional[str] = None, end_date: Optional[str] = None,
                                               trade_date: Optional[str] = None, stock_group: Optional[str] = None,
                                               factor_group: Optional[str] = None):
        """
        获取累积收益率
        Args:
            factor_id: 因子id
            pool_id: 回测条件ID
            begin_date: 开始时间
            end_date: 结束时间
            trade_date: 交易日期
            stock_group: 股票分组
            factor_group: 因子分组

        Returns:

        """
        table = GroupBackTestAccumulativeReturn
        query = self.query(table).filter(table.factor_id == factor_id,
                                         table.pool_id == pool_id)
        if stock_group is not None:
            query = query.fiter(table.stock_group == stock_group)
        if factor_group is not None:
            query = query.filter(table.factor_group == factor_group)
        query = self.filter_date(query, table.trade_date, begin_date, end_date, trade_date)
        df = self.read_sql(query)
        return df

    def get_group_bm_backtest_accumulative_return(self, benchmark_code: str, begin_date: Optional[str] = None,
                                                  end_date: Optional[str] = None,
                                                  trade_date: Optional[str] = None):
        """
        获取基准累积收益率
        Args:
            benchmark_code: 基准代码
            begin_date: 开始时间
            end_date: 结束时间
            trade_date: 交易日期

        Returns:

        """
        table = GroupBackTestBenchmarkAccumulativeReturn
        query = self.query(table).filter(table.benchmark_code == benchmark_code)
        query = self.filter_date(query, table.trade_date, begin_date, end_date, trade_date)
        df = self.read_sql(query)
        return df

    def get_group_backtest_result_stat(self, factor_id: Union[str, List, None] = None, benchmark_code: str = None,
                                       pool_id: Optional[str] = None, interval: Optional[str] = None,
                                       period: Optional[str] = 1, group_num: Optional[str] = None,
                                       begin_date: Optional[str] = None, end_date: Optional[str] = None):
        """"""
        table = GroupBackTestResultStat
        query = self.query(table)
        if benchmark_code is not None:
            query = query.filter(table.benchmark_code == benchmark_code)
        if pool_id is not None:
            query = query.filter(table.pool_id == pool_id)
        if interval is not None:
            query = query.filter(table.interval == interval)
        if period is not None:
            query = query.filter(table.period == period)
        if group_num is not None:
            query = query.filter(table.group_num == group_num)
        if begin_date is not None:
            query = query.filter(table.begin_date >= begin_date)
        if end_date is not None:
            query = query.filter(table.end_date <= end_date)
        df = self.batch_query(query, table.factor_id, factor_id)
        return df

    def get_factor_regress_test_daily(self, factor_id: str, pool_id: Optional[str] = None, period: Optional[str] = None,
                                      begin_date: Optional[str] = None, end_date: Optional[str] = None,
                                      trade_date: Optional[str] = None, regress_method: Optional[str] = None):

        table = FactorRegressTestDaily
        query = self.query(table).filter(table.factor_id == factor_id)
        if pool_id is not None:
            query = query.filter(table.pool_id == pool_id)
        if period is not None:
            query = query.filter(table.period == period)
        if regress_method is not None:
            query = query.filter(table.regress_method == regress_method)
        query = self.filter_date(query, table.trade_date, begin_date, end_date, trade_date)
        df = self.read_sql(query)
        return df

    def get_factor_regress_test_stat(self, factor_id: Union[str, List, None] = None, pool_id: Optional[str] = None,
                                     period: Optional[str] = None, interval: Optional[str] = None,
                                     regress_method: Optional[str] = None, begin_date: Optional[str] = None,
                                     end_date: Optional[str] = None):
        """

        """
        table = FactorRegressTestStat
        query = self.query(table)
        if pool_id is not None:
            query = query.filter(table.pool_id == pool_id)
        if period is not None:
            query = query.filter(table.period == period)
        if interval is not None:
            query = query.filter(table.interval == interval)
        if regress_method is not None:
            query = query.filter(table.regress_method == regress_method)
        if begin_date is not None:
            query = query.filter(table.begin_date >= begin_date)
        if end_date is not None:
            query = query.filter(table.end_date <= end_date)
        df = self.batch_query(query, table.factor_id, factor_id)
        return df

    def get_factor_turnover_rate_daily(self, factor_id: str, pool_id: Optional[str] = None,
                                       period: Optional[str] = None,
                                       factor_group: Optional[str] = None, begin_date: Optional[str] = None,
                                       end_date: Optional[str] = None, trade_date: Optional[str] = None):
        table = FactorTurnoverRateDaily
        query = self.query(table).filter(table.factor_id == factor_id)
        if pool_id is not None:
            query = query.filter(table.pool_id == pool_id)
        if period is not None:
            query = query.filter(table.period == period)
        if factor_group is not None:
            query = query.filter(table.factor_group == factor_group)
        query = self.filter_date(query, table.trade_date, begin_date, end_date, trade_date)
        df = self.read_sql(query)
        return df


if __name__ == '__main__':
    # factor_id_list = ['log_total_market_value', 'momentum_5', 'momentum_5_preprocess']
    df_basic = StockFactorReader().get_factor_basic_info(is_examine=1)
    df_basic['periods'] = df_basic['periods'].apply(lambda x: x.split(',') if x is not None else [])
    factor_period_dict = df_basic.set_index('factor_id')['periods'].to_dict()
    factor_period_dict = {k: [int(i) for i in v] for k, v in factor_period_dict.items()}
    print(factor_period_dict)
