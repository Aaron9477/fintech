# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2023/3/30 9:57
# @Author  : wangxybjs
# @File    : read_smpp.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
import datetime
from typing import Optional, Union

from cscfist.database.data_field.smpp_field import PFundNav
from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.model.db_model.rdb_model.rdb_operator_base import RdbBaseReader


class SMPPReader(RdbBaseReader):
    def __init__(self, smpp_connection: Optional[RdbConnectionBase] = None):
        """
        Args:
            smpp_connection: 数据库连接。如果为None则使用默认配置连接
        """
        if smpp_connection is None:
            from cscfist.database.connection.oracle_con import get_default_smpp_connection
            smpp_connection = get_default_smpp_connection()
        super().__init__(db_connection=smpp_connection)

    def get_pfund_nav(self, fund_code: Union[str, list, None] = None, price_date: str = None, begin_date: str = None,
                      end_date: str = None, batch=500):
        """
        获取私募基金净值表PVN_NAV
        :param fund_code: 基金代码, 单个基金代码或基金代码列表或空
        :param price_date: 净值日期
        :param begin_date: 净值起始日期
        :param end_date: 净值结束日期
        :param batch: 取基金代码列表批量查询时单次查询的数量
        :return 净值DataFrame
        +---------------------------+------------------------------+-------------+------------+
        |            字段           |             含义             |     类型    |    示例    |
        +---------------------------+------------------------------+-------------+------------+
        |          FUND_ID          |            基金id            |     str     | HF0000000A |
        |         PRICE_DATE        |           净值日期           |   str(已转)   |  20210602  |
        |            NAV            |           单位净值           | float |    0.94    |
        |       CUMULATIVE_NAV      | 考虑分红再投资的单位累计净值 |    float    |    0.93    |
        | CUMULATIVE_NAV_WITHDRAWAL |   分红不投资的单位累计净值   |    float    |    0.95    |
        +---------------------------+------------------------------+-------------+------------+
        """
        table_name = PFundNav
        query = self.session.query(table_name).filter(table_name.ISVALID == 1)
        if price_date is not None:
            price_date = datetime.datetime.strptime(price_date, "%Y%m%d")
        if begin_date is not None:
            begin_date = datetime.datetime.strptime(begin_date, "%Y%m%d")
        if end_date is not None:
            end_date = datetime.datetime.strptime(end_date, "%Y%m%d")
        query = self.filter_date(query, table_name.PRICE_DATE, begin_date, end_date, price_date)
        df = self.batch_query(query, table_name.FUND_ID, fund_code, batch_size=batch)
        df["PRICE_DATE"] = df["PRICE_DATE"].apply(lambda x: x.strftime("%Y%m%d"))
        df.sort_values(by="PRICE_DATE", inplace=True)
        del df["ID"]
        return df
