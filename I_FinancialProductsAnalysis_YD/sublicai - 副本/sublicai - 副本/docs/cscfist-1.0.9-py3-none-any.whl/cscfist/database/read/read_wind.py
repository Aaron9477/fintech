# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/8/5 9:24
# @Author  : lisl3
# @File    : wind_reader.py
# @Project : cscfist
# @Function: 获取wind数据接口
# @Version : V0.0.1
# ------------------------------
import datetime
from typing import Dict, List, Optional, Union

import numpy as np
import pandas as pd
from sqlalchemy import or_, func, distinct

from cscfist.config.index_eod_quick_table_find import INDEX_EOD_TABLE
from cscfist.config.industry_type_config import INDUSTRY_DICT
from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.database.data_field.wind_field import *
from cscfist.model.db_model.rdb_model.rdb_operator_base import RdbBaseReader
from cscfist.tools.date_util import TradeDateUtils


class WindReader(RdbBaseReader):
    def __init__(self, wind_connection: Optional[RdbConnectionBase] = None):
        """
        Args:
            wind_connection: 数据库连接。如果为None则使用默认配置连接
        """
        if wind_connection is None:
            from cscfist.database.connection.sql_server_con import get_default_wind_connection
            wind_connection = get_default_wind_connection()
        super().__init__(db_connection=wind_connection)

    if 'A stock':
        def get_min_date_index_member(self, index_code):
            table_name = AINDEXMEMBERS
            query = self.session.query(func.min(table_name.S_CON_INDATE)).filter(
                table_name.S_INFO_WINDCODE == index_code)
            return pd.read_sql(query.statement, self.engine).iloc[0, 0]

        def get_a_share_placement_details_count(self, begin_date=None, end_date=None, holder_name=None):
            """
            获取中国A股网下配售机构获配明细计数

            Examples:
                >>> WindReader().get_a_share_placement_details_count("20220101", "20230101")
                711
            """
            table_name = ASHAREPLACEMENTDETAILS
            query = self.query(func.count(distinct(table_name.S_INFO_WINDCODE)))
            if holder_name is not None:
                query = query.filter(table_name.S_HOLDER_NAME == holder_name)
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date)
            df = query.scalar()
            return df

        def get_a_share_placement_details(self, begin_date=None, end_date=None, columns=None):
            """
            获取中国A股网下配售机构获配明细

            Examples:
                >>> WindReader().get_a_share_placement_details("20221230", "20230101").shape
                (21, 20)
            """
            table_name = ASHAREPLACEMENTDETAILS
            query = self.query(table_name, columns)
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date)
            df = self.read_sql(query)
            return df

        def get_ipo_inquiry_details_count(self, begin_date=None, end_date=None, issue_target=None):
            """
            获取中国A股网下配售机构获配明细计数

            Examples:
                >>> WindReader().get_ipo_inquiry_details_count("20220101", "20230101")
                296
            """
            table_name = IPOINQUIRYDETAILS
            query = self.query(func.count(distinct(table_name.S_INFO_WINDCODE)))
            if issue_target is not None:
                query = query.filter(table_name.ISSUETARGET == issue_target)
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date)
            df = query.scalar()
            return df

        def get_ipo_inquiry_details(self, begin_date=None, end_date=None, columns=None):
            """
            获取IPO询价数据
            """
            table_name = IPOINQUIRYDETAILS
            query = self.query(table_name, columns)
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date)
            df = self.read_sql(query)
            return df

        def get_a_shareis_participant(self, institution_name=None, institution_code=None, institution_type=None,
                                      analyst_name=None, columns=None):
            table_name = ASHAREISPARTICIPANT
            query = self.query(table_name, columns)
            if institution_name is not None:
                query = query.filter(table_name.S_INSTITUTIONNAME == institution_name)
            if institution_code is not None:
                query = query.filter(table_name.S_INSTITUTIONCODE == institution_code)
            if institution_type is not None:
                query = query.filter(table_name.S_INSTITUTIONTYPE == institution_type)
            df = self.batch_query(query, table_name.S_ANALYSTNAME, analyst_name)
            return df

        def get_a_shareis_activity(self, event_id=None, stock_code=None, begin_date=None, end_date=None, columns=None):
            """
            中国A股机构调研活动
            """
            table_name = ASHAREISACTIVITY
            query = self.query(table_name, columns)
            if stock_code is not None:
                query = query.filter(table_name.S_INFO_WINDCODE == stock_code)
            query = self.filter_date(query, table_name.S_SURVEYDATE, begin_date, end_date)
            df = self.batch_query(query, table_name.EVENT_ID, event_id)
            return df

        def get_a_share_sec_industries_class(self, stock_code=None, begin_date=None, end_date=None, trade_date=None,
                                             columns=None):
            table_name = ASHARESECINDUSTRIESCLASS
            query = self.query(table_name, columns)
            if trade_date is not None:
                query = query.filter(table_name.ENTRY_DT <= trade_date).filter(
                    or_(table_name.REMOVE_DT >= trade_date, table_name.REMOVE_DT.is_(None)))
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, stock_code)
            return df

        def get_a_share_secn_industries_class(self, stock_code=None, begin_date=None, end_date=None, trade_date=None,
                                              columns=None):
            table_name = ASHARESECNINDUSTRIESCLASS
            query = self.query(table_name, columns)
            if trade_date is not None:
                query = query.filter(table_name.ENTRY_DT <= trade_date).filter(
                    or_(table_name.REMOVE_DT >= trade_date, table_name.REMOVE_DT.is_(None)))
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, stock_code)
            return df

        # 股票相关
        def get_a_share_eod_prices(self,
                                   code: Union[None, str, list] = None,
                                   begin_date: Optional[str] = None,
                                   end_date: Optional[str] = None,
                                   trade_date: Optional[str] = None,
                                   columns: Optional[list] = None) -> pd.DataFrame:
            """查询A股行情"""
            table_name = ASHAREEODPRICES
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            if 'TRADE_DT' in df.columns:
                df.sort_values(by='TRADE_DT', inplace=True)
            return df

        def get_a_share_issuing_date_predict(self, code, watch_date=None):
            """
            获取中国A股定期报告披露日期

            Args:
                code: 股票代码
                watch_date: 观察日, 若非None则筛选财报公布日早于该日期
            """
            table_name = ASHAREISSUINGDATEPREDICT
            query = self.session.query(table_name)
            if watch_date is not None:
                query = query.filter(table_name.S_STM_ACTUAL_ISSUINGDATE <= watch_date)
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_description(self, code=None, columns=None):
            """中国A股基本资料"""
            table_name = ASHAREDESCRIPTION
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_existing_a_share_code(self, date=None) -> list:
            """
            获取存续的股票列表

            Args:
                date: 日期, 如果传入None, 则为获取最新股票列表

            Returns:
                存续的股票列表
            """
            table_name = ASHAREDESCRIPTION
            query = self.query(table_name, ['S_INFO_WINDCODE'])
            if date is None:
                date = datetime.datetime.now().strftime('%Y%m%d')
            query = query.filter(table_name.S_INFO_LISTDATE <= date).filter(
                or_(table_name.S_INFO_DELISTDATE >= date,
                    table_name.S_INFO_DELISTDATE.is_(None)))
            existing_stock_list = self.read_sql(query)["S_INFO_WINDCODE"].tolist()
            return existing_stock_list

        def get_a_share_ipo(self, code=None, columns=None):
            """中国A股首次公开发行数据"""
            table_name = ASHAREIPO
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_index_eod_prices(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                   columns=None) -> pd.DataFrame:
            """查询指数行情"""
            table_name = AINDEXEODPRICES
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            if 'TRADE_DT' in df.columns:
                df.sort_values(by='TRADE_DT', inplace=True)
            return df

        def get_a_index_members(self, code=None, begin_date=None, end_date=None, columns=None):
            """中国A股指数成份股"""
            table_name = AINDEXMEMBERS
            query = self.query(table_name, columns)
            # 筛选条件
            if begin_date is not None:
                query = query.filter(or_(table_name.S_CON_OUTDATE >= begin_date, table_name.S_CON_OUTDATE.is_(None)))
            if end_date is not None:
                query = query.filter(table_name.S_CON_INDATE <= end_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_sws_index_eod(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """申万指数行情"""
            table_name = ASWSINDEXEOD
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_index_hs300_close_weight(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                           columns=None):
            """沪深300指数成份股当日收盘权重信息"""
            table_name = AINDEXHS300CLOSEWEIGHT
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_financial_indicator(self, code=None, begin_date=None, end_date=None, report_period=None,
                                            columns=None):
            """中国A股财务指标，根据报告期筛选"""
            table_name = ASHAREFINANCIALINDICATOR
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.REPORT_PERIOD, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_financial_indicator_ann_dt(self, code=None, begin_date=None, end_date=None, report_period=None,
                                                   columns=None):
            """中国A股财务指标，根据公告日期筛选"""
            table_name = ASHAREFINANCIALINDICATOR
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_balance_sheet(self, code=None, begin_date=None, end_date=None, report_period=None,
                                      columns=None, statement_type=None):
            """中国A股资产负债表，根据报告期筛选"""
            table_name = ASHAREBALANCESHEET
            query = self.query(table_name, columns)
            if statement_type is not None:
                query = query.filter(table_name.STATEMENT_TYPE == statement_type)
            # 筛选条件
            query = self.filter_date(query, table_name.REPORT_PERIOD, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_balance_sheet_ann_dt(self, code=None, begin_date=None, end_date=None, report_period=None,
                                             columns=None, statement_type=None):
            """中国A股资产负债表，根据公告日期筛选"""
            table_name = ASHAREBALANCESHEET
            query = self.query(table_name, columns)
            if statement_type is not None:
                query = query.filter(table_name.STATEMENT_TYPE == statement_type)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_non_profit_loss(self, code=None, begin_date=None, end_date=None, report_period=None,
                                        columns=None, statement_type=None):
            """中国A股非经常性损益，根据报告期筛选"""
            table_name = ASHARENONPROFITLOSS
            query = self.query(table_name, columns)
            if statement_type is not None:
                query = query.filter(table_name.STATEMENT_TYPE == statement_type)
            # 筛选条件
            query = self.filter_date(query, table_name.REPORT_PERIOD, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_COMPCODE, code)
            return df

        def get_a_share_non_profit_loss_ann_dt(self, code=None, begin_date=None, end_date=None, report_period=None,
                                               columns=None, statement_type=None):
            """中国A股非经常性损益，根据公告日期筛选"""
            table_name = ASHARENONPROFITLOSS
            query = self.query(table_name, columns)
            if statement_type is not None:
                query = query.filter(table_name.STATEMENT_TYPE == statement_type)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_COMPCODE, code)
            return df

        def get_a_share_pledge_proportion(self, code=None, begin_date=None, end_date=None, report_period=None,
                                          columns=None):
            """中国A股股票质押比例"""
            table_name = ASHAREPLEDGEPROPORTION
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.S_ENDDATE, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_equity_pledge_info(self, code=None, begin_date=None, end_date=None, report_period=None,
                                           columns=None):
            """中国A股股权质押信息"""
            table_name = ASHAREEQUITYPLEDGEINFO
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_inside_holder(self, code=None, begin_date=None, end_date=None, report_period=None,
                                      columns=None):
            """中国A股前十大股东，根据截止日期筛选"""
            table_name = ASHAREINSIDEHOLDER
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.S_HOLDER_ENDDATE, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_inside_holder_ann_dt(self, code=None, begin_date=None, end_date=None, report_period=None,
                                             columns=None):
            """中国A股前十大股东，根据公告日期筛选"""
            table_name = ASHAREINSIDEHOLDER
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_inside_holder_by_holder_name(self, holder_name=None, begin_date=None, end_date=None,
                                                     report_period=None,
                                                     columns=None):
            """中国A股前十大股东，根据公告日期筛选"""
            table_name = ASHAREINSIDEHOLDER
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.REPORT_PERIOD, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_HOLDER_NAME, holder_name)
            return df

        def get_a_share_capitalization(self, code=None, begin_date=None, end_date=None, report_period=None,
                                       columns=None):
            """中国A股股本"""
            table_name = ASHARECAPITALIZATION
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_equ_fro_info(self, code=None, begin_date=None, end_date=None, report_period=None,
                                     columns=None):
            """中国A股股权冻结信息"""
            table_name = ASHAREEQUFROINFO
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DATE, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_COMPCODE, code)
            return df

        def get_a_share_management(self, code=None, begin_date=None, end_date=None, report_period=None,
                                   columns=None):
            """中国A股公司管理层成员"""
            table_name = ASHAREMANAGEMENT
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DATE, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_top_5_by_operating_income(self, code=None, begin_date=None, end_date=None, report_period=None,
                                          columns=None):
            """中国A股营业收入前五名，根据报告期期筛选"""
            table_name = TOP5BYOPERATINGINCOME
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.REPORT_PERIOD, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_top_5_by_operating_income_ann_dt(self, code=None, begin_date=None, end_date=None, report_period=None,
                                                 columns=None):
            """中国A股营业收入前五名，根据公告日期筛选"""
            table_name = TOP5BYOPERATINGINCOME
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_cash_flow(self, code=None, begin_date=None, end_date=None, report_period=None, columns=None):
            """中国A股现金流量表，根据报告期筛选"""
            table_name = ASHARECASHFLOW
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.REPORT_PERIOD, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_cash_flow_ann_dt(self, code=None, begin_date=None, end_date=None, report_period=None,
                                         columns=None):
            """中国A股现金流量表，根据公告日期筛选"""
            table_name = ASHARECASHFLOW
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_equity_relationships(self, code=None, begin_date=None, end_date=None, report_period=None,
                                             columns=None):
            """中国A股股权关系，根据截止日期筛选"""
            table_name = ASHAREEQUITYRELATIONSHIPS
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ENDDATE, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_equity_relationships_flow_ann_dt(self, code=None, begin_date=None, end_date=None,
                                                         report_period=None, columns=None):
            """中国A股股权关系，根据公告日期筛选"""
            table_name = ASHAREEQUITYRELATIONSHIPS
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_related_trade(self, code=None, begin_date=None, end_date=None, report_period=None,
                                      columns=None):
            """中国A股关联交易"""
            table_name = ASHARERALATEDTRADE
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_prosecution(self, code=None, begin_date=None, end_date=None, report_period=None,
                                    columns=None):
            """中国A股诉讼事件"""
            table_name = ASHAREPROSECUTION
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_guarantee_statistics(self, code=None, begin_date=None, end_date=None,
                                             report_period=None, columns=None):
            """中国A股担保统计，根据截止日期筛选"""
            table_name = ASHAREGUARANTEESTATISTICS
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.DEADLINE, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_COMPCODE, code)
            return df

        def get_a_share_guarantee_statistics_ann_dt(self, code=None, begin_date=None, end_date=None,
                                                    report_period=None, columns=None):
            """中国A股担保统计，根据公告日期筛选"""
            table_name = ASHAREGUARANTEESTATISTICS
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DATE, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_COMPCODE, code)
            return df

        def get_a_share_free_float_calendar(self, code=None, begin_date=None, end_date=None,
                                            report_period=None, columns=None):
            """中国A股限售股流通日历，根据上市日期筛选"""
            table_name = ASHAREFREEFLOATCALENDAR
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.S_INFO_LISTDATE, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_free_float_calendar_ann_dt(self, code=None, begin_date=None, end_date=None,
                                                   report_period=None, columns=None):
            """中国A股限售股流通日历，根据公告日期筛选"""
            table_name = ASHAREFREEFLOATCALENDAR
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_mjr_holder_trade(self, code=None, begin_date=None, end_date=None,
                                         report_period=None, columns=None):
            """中国A股重要股东增减持"""
            table_name = ASHAREMJRHOLDERTRADE
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_audit_opinion(self, code=None, begin_date=None, end_date=None, report_period=None,
                                      columns=None):
            """中国A股审计意见，根据报告期筛选"""
            table_name = ASHAREAUDITOPINION
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.REPORT_PERIOD, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_audit_opinion_ann_dt(self, code=None, begin_date=None, end_date=None, report_period=None,
                                             columns=None):
            """中国A股审计意见，根据公告日期筛选"""
            table_name = ASHAREAUDITOPINION
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_income(self, code=None, begin_date=None, end_date=None, report_period=None, columns=None):
            """中国A股利润表，根据报告期筛选"""
            table_name = ASHAREINCOME
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.REPORT_PERIOD, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_income_ann_dt(self, code=None, begin_date=None, end_date=None, report_period=None,
                                      columns=None):
            """中国A股利润表，根据公告日期筛选"""
            table_name = ASHAREINCOME
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_ttm_his(self, code=None, begin_date=None, end_date=None, report_period=None, columns=None,
                                statement_type=None):
            """中国A股TTM指标历史数据，根据报告期筛选"""
            table_name = ASHARETTMHIS
            query = self.query(table_name, columns)
            if statement_type is not None:
                query = query.filter(table_name.STATEMENT_TYPE == statement_type)
            # 筛选条件
            query = self.filter_date(query, table_name.REPORT_PERIOD, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_ttm_his_ann_dt(self, code=None, begin_date=None, end_date=None, report_period=None,
                                       columns=None):
            """中国A股TTM指标历史数据，根据公告日期筛选"""
            table_name = ASHARETTMHIS
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_consensus_data(self, code=None, begin_date=None, end_date=None, report_period=None,
                                       columns=None):
            """中国A股盈利预测汇总，根据预测报告期筛选"""
            table_name = ASHARECONSENSUSDATA
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.EST_REPORT_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_consensus_data_est_dt(self, code=None, begin_date=None, end_date=None, report_period=None,
                                              columns=None):
            """中国A股盈利预测汇总，根据预测日期筛选"""
            table_name = ASHARECONSENSUSDATA
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.EST_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_eod_derivative_indicator(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                                 columns=None):
            """中国A股日行情估值指标"""
            table_name = ASHAREEODDERIVATIVEINDICATOR
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_sw_industries_class(self, code=None, columns=None):
            """申万行业分类"""
            table_name = ASHARESWINDUSTRIESCLASS
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_swn_industries_class(self, stock_code, begin_date=None, end_date=None, trade_date=None,
                                             columns=None):
            """获取SW股票行业分类"""
            table_name = ASHARESWNINDUSTRIESCLASS
            query = self.query(table_name, columns)

            if trade_date is not None:
                query = query.filter(table_name.ENTRY_DT <= trade_date,
                                     or_(table_name.REMOVE_DT >= trade_date, table_name.REMOVE_DT.is_(None)))
            if begin_date is not None and end_date is not None:
                query = query.filter(table_name.ENTRY_DT <= end_date,
                                     or_(table_name.REMOVE_DT >= begin_date, table_name.REMOVE_DT.is_(None)))

            df = self.batch_query(query, table_name.S_INFO_WINDCODE, stock_code)
            return df

        def get_industry_code_name_mapping(self, industry_name=None, level='2', used=None) -> pd.DataFrame:
            """获取行业代码、行业名称、行业指数代码映射关系"""
            code_mapping = {'sw': '76%', 'zx': 'b1%', 'wind': '62%'}
            ind_code_like = code_mapping.get(industry_name, industry_name)
            industry_code = self.get_a_share_industries_code(ind_code_like=ind_code_like, level=level, used=used)
            ind_code = industry_code.INDUSTRIESCODE.apply(lambda x: x.ljust(16, '0')).unique().tolist()
            contrast_sector = self.get_index_contrast_sector(
                ind_code=ind_code, columns=['S_INFO_INDUSTRYCODE', 'S_INFO_INDUSTRYNAME', 'S_INFO_INDEXCODE'])
            if len(contrast_sector) != len(ind_code):
                contrast_sector = industry_code[['INDUSTRIESCODE', 'INDUSTRIESNAME']].rename(
                    columns={'INDUSTRIESCODE': 'S_INFO_INDUSTRYCODE', 'INDUSTRIESNAME': 'S_INFO_INDUSTRYNAME'})
                contrast_sector['S_INFO_INDEXCODE'] = None
            contrast_sector['S_INFO_INDUSTRYCODE'] = contrast_sector['S_INFO_INDUSTRYCODE'].apply(
                lambda x: x[:int(level) * 2])
            return contrast_sector

        def get_a_index_industries_eod_citics(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                              columns=None):
            """中国A股中信行业指数日行情"""
            table_name = AINDEXINDUSTRIESEODCITICS
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_index_wind_industries_eod(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                            columns=None):
            """中国A股Wind行业指数日行情"""
            table_name = AINDEXWINDINDUSTRIESEOD
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_index_valuation(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """中国A股指数估值数据"""
            table_name = AINDEXVALUATION
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_index_description(self, code=None, columns=None):
            """中国A股指数基本资料"""
            table_name = AINDEXDESCRIPTION
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_industries_code(self, ind_code=None, ind_name=None, ind_code_like=None, level=None, used=None,
                                        columns=None):
            """行业代码"""
            table_name = ASHAREINDUSTRIESCODE
            query = self.query(table_name, columns)
            # 筛选条件
            if ind_code is not None:
                if isinstance(ind_code, str):
                    query = query.filter(table_name.INDUSTRIESCODE == ind_code)
                elif isinstance(ind_code, list):
                    query = query.filter(table_name.INDUSTRIESCODE.in_(ind_code))
            if ind_name is not None:
                if isinstance(ind_name, str):
                    query = query.filter(table_name.INDUSTRIESNAME == ind_name)
                elif isinstance(ind_name, list):
                    query = query.filter(table_name.INDUSTRIESNAME.in_(ind_name))
            if ind_code_like is not None:
                query = query.filter(table_name.INDUSTRIESCODE.like(ind_code_like))
            if level is not None:
                query = query.filter(table_name.LEVELNUM == level)
            if used is not None:
                query = query.filter(table_name.USED == used)
            # 查询数据
            df = self.read_sql(query)
            return df

        def get_a_share_industries_code_by_code(self, ind_code=None, ind_code_like=None, level=None, columns=None):
            """根据代码获取行业代码"""
            table_name = ASHAREINDUSTRIESCODE
            query = self.query(table_name, columns)
            # 筛选条件
            if ind_code_like is not None:
                query = query.filter(table_name.INDUSTRIESCODE.like(ind_code_like))
            if level is not None:
                query = query.filter(table_name.LEVELNUM == level)
            # 查询数据
            df = self.batch_query(query, table_name.INDUSTRIESCODE, ind_code)
            return df

        def get_a_share_industries_code_by_name(self, ind_name=None, ind_code_like=None, level=None, columns=None):
            """根据名称获取行业代码"""
            table_name = ASHAREINDUSTRIESCODE
            query = self.query(table_name, columns)
            # 筛选条件
            if ind_code_like is not None:
                query = query.filter(table_name.INDUSTRIESCODE.like(ind_code_like))
            if level is not None:
                query = query.filter(table_name.LEVELNUM == level)
            # 查询数据
            df = self.batch_query(query, table_name.INDUSTRIESNAME, ind_name)
            return df

        def get_a_index_hs300_free_weight(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                          columns=None):
            """沪深300免费指数权重"""
            table_name = AINDEXHS300FREEWEIGHT
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_calendar(self, market='SSE', begin_date=None, end_date=None):
            """中国A股交易日历表"""
            table_name = ASHARECALENDAR
            query = self.query(table_name).filter(table_name.S_INFO_EXCHMARKET == market)
            query = self.filter_date(query, table_name.TRADE_DAYS, begin_date, end_date)
            query = query.order_by(table_name.TRADE_DAYS)
            # 查询数据
            df = self.read_sql(query)
            return df

        def get_all_index_close(self, code, begin_date=None, end_date=None, trade_date=None):
            """
            从全部指数行情表中获取数据
            """

            def _query_table(table):
                query = self.query(table, columns=['S_INFO_WINDCODE', 'TRADE_DT', 'S_DQ_CLOSE']).filter(
                    table.S_INFO_WINDCODE == c)
                if begin_date is not None:
                    query = query.filter(table.TRADE_DT >= begin_date)
                if end_date is not None:
                    query = query.filter(table.TRADE_DT <= end_date)
                if trade_date is not None:
                    query = query.filter(table.TRADE_DT == trade_date)
                df = self.read_sql(query)
                if 'TRADE_DT' in df.columns:
                    df.sort_values(by='TRADE_DT', inplace=True)
                return df

            table_list = [AINDEXEODPRICES, ASWSINDEXEOD, CBINDEXEODPRICES, AINDEXWINDINDUSTRIESEOD, CMFINDEXEOD,
                          GLOBALINDEXEOD, AINDEXINDUSTRIESEODCITICS, HKINDEXEODPRICES, CBINDEXEODPRICESWIND]
            table_str_object_dict = {
                "AINDEXEODPRICES": AINDEXEODPRICES,
                "ASWSINDEXEOD": ASWSINDEXEOD,
                "CBINDEXEODPRICES": CBINDEXEODPRICES,
                "AINDEXWINDINDUSTRIESEOD": AINDEXWINDINDUSTRIESEOD,
                "CMFINDEXEOD": CMFINDEXEOD,
                "GLOBALINDEXEOD": GLOBALINDEXEOD,
                "AINDEXINDUSTRIESEODCITICS": AINDEXINDUSTRIESEODCITICS,
                "HKINDEXEODPRICES": HKINDEXEODPRICES
            }
            if isinstance(code, str):
                code = [code]
            df_all = pd.DataFrame()
            for c in code:
                if c in INDEX_EOD_TABLE:  # 在快速查找名单中, 可以直接定位是哪个表
                    table = table_str_object_dict[INDEX_EOD_TABLE[c]]
                    df = _query_table(table)
                    df_all = df_all.append(df)
                else:
                    for table in table_list:
                        df = _query_table(table)
                        if len(df) > 0:
                            df_all = df_all.append(df)
                            break

            return df_all

        def get_a_share_conception(self, code=None, columns=None):
            """中国A股Wind概念板块"""
            table_name = ASHARECONSEPTION
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_industries_class_citics(self, code=None, columns=None):
            """中国A股中信行业分类"""
            table_name = ASHAREINDUSTRIESCLASSCITICS
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_dividend(self, code=None, columns=None):
            """中国A股分红"""
            table_name = ASHAREDIVIDEND
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_right_issue(self, code=None, columns=None):
            """中国A股配股"""
            table_name = ASHARERIGHTISSUE
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_money_flow(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                   columns=None):
            """中国A股资金流向数据"""
            table_name = ASHAREMONEYFLOW
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_sh_sc_members(self, code=None, columns=None):
            """沪股通成分股"""
            table_name = SHSCMEMBERS
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_sz_sc_members(self, code=None, columns=None):
            """深股通成分股"""
            table_name = SZSCMEMBERS
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_sh_sc_channel_holdings(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                       columns=None, market=None):
            """陆港通通道持股数量统计(中央结算系统)"""
            table_name = SHSCCHANNELHOLDINGS
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            if market is not None:
                query = query.filter(table_name.S_INFO_EXCHMARKETNAME == market)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_sh_sc_daily_statistics(self, begin_date=None, end_date=None, trade_date=None,
                                       columns=None, market=None, item_code=None):
            """陆港通日交易统计"""
            table_name = SHSCDAILYSTATISTICS
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            if market is not None:
                query = query.filter(table_name.S_INFO_EXCHMARKET == market)
            if item_code is not None:
                query = query.filter(table_name.ITEM_CODE == item_code)
            # 查询数据
            df = self.read_sql(query)
            return df

        def get_financial_statement_indicator(self, indicator, date_code_dict):
            table = indicator.class_
            res_df = pd.DataFrame()
            for report_period, code_list in date_code_dict.items():
                query = self.session.query(table.REPORT_PERIOD, table.S_INFO_WINDCODE,
                                           indicator.label("res")).filter(table.REPORT_PERIOD == report_period)
                if table.__tablename__ in ["ASHAREBALANCESHEET"]:  # 三大报表需要筛选报表类型
                    query = query.filter(table.STATEMENT_TYPE == '408001000')
                elif table.__tablename__ in ["ASHAREINCOME", "ASHARECASHFLOW"]:
                    query = query.filter(table.STATEMENT_TYPE == '408002000')  # 流量表需要用单季度
                df = self.batch_query(query, table.S_INFO_WINDCODE, code_list)
                res_df = res_df.append(df)
            return res_df

        def get_a_share_stock_repo(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """中国A股回购"""
            table_name = ASHARESTOCKREPO
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_ashare_trading_suspension(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                          columns=None):
            """中国A股停复牌信息"""
            table_name = ASHARETRADINGSUSPENSION
            query = self.query(table_name, columns)
            query = self.filter_date(query, table_name.S_DQ_SUSPENDDATE, begin_date, end_date, trade_date)
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_ashare_previous_name(self, code=None, begin_date=None, end_date=None, columns=None):
            """中国A股证券曾用名"""
            table_name = ASHAREPREVIOUSNAME
            query = self.query(table_name, columns)
            if begin_date is not None:
                query = query.filter(or_(table_name.ENDDATE >= begin_date, table_name.ENDDATE.is_(None)))
            if end_date is not None:
                query = query.filter(table_name.BEGINDATE <= end_date)
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

    if 'HK stock':
        # 港股
        def get_hk_share_eod_prices(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """香港股票日行情"""
            table_name = HKSHAREEODPRICES
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            if 'TRADE_DT' in df.columns:
                df.sort_values(by='TRADE_DT', inplace=True)
            return df

        def get_hk_share_description(self, code=None, columns=None, is_stock=True):
            """香港股票基本资料"""
            table_name = HKSHAREDESCRIPTION
            query = self.query(table_name, columns)
            if is_stock:
                query = query.filter(table_name.SECURITYSUBCLASS.in_(["100001001", "100001002"]))
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_hk_index_eod_prices(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """香港股票指数日行情"""
            table_name = HKINDEXEODPRICES
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_global_index_eod(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """全球指数行情"""
            table_name = GLOBALINDEXEOD
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_hk_share_sw_industries_class(self, code=None, columns=None):
            """港股申万行业分类"""
            table_name = HKSHARESWINDUSTRIESCLASS
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_hk_stock_wind_industries_members(self, code=None, trade_date=None, columns=None):
            """港股代码wind行业对应表"""
            table_name = HKSTOCKWINDINDUSTRIESMEMBERS
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_hk_stock_index_members(self, code=None, columns=None):
            """香港股票指数成份股"""
            table_name = HKSTOCKINDEXMEMBERS
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_hk_share_eod_derivative_index(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                              columns=None):
            """香港股票日行情估值指标"""
            table_name = HKSHAREEODDERIVATIVEINDEX
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.FINANCIAL_TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_hk_sc_members(self, code=None, columns=None):
            """香港港股通成分股"""
            table_name = HKSCMEMBERS
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_hk_share_swn_industries_class(self, code=None, columns=None):
            """港股申万行业分类(2021版)"""
            table_name = HKSHARESWNINDUSTRIESCLASS
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_hk_financial_indicator(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """香港股票财务指标"""
            table_name = HKFINANCIALINDICATOR
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_COMPCODE, code)
            return df

        def get_hk_share_financial_derivative(self, code=None, begin_fiscal_year=None, end_fiscal_year=None,
                                              fiscal_year=None, report_type=None, columns=None,
                                              begin_report_period=None, end_report_peropd=None, report_period=None):
            """
            香港股票财务衍生指标表

            Args:
                code: 公司ID, str, list or None
                begin_fiscal_year: 开始会计年度, str or None，如：2016
                end_fiscal_year: 结束会计年度, str or None，如：2017
                fiscal_year: 指定会计年度, str or None，如：2018
                report_type: 报告类型, str, list or None，只能是 一季报、中报、三季报、年报
                columns: 指定输出的字段
            """
            table_name = HKSHAREFINANCIALDERIVATIVE
            query = self.query(table_name, columns)
            # 会计年度筛选条件
            query = self.filter_date(query, table_name.FISCALYEAR, begin_fiscal_year, end_fiscal_year, fiscal_year)
            query = self.filter_date(query, table_name.ENDDATE, begin_report_period, end_report_peropd, report_period)
            # 报告类型筛选
            if isinstance(report_type, str):
                query = query.filter(table_name.REPORT_TYPE == report_type)
            elif isinstance(report_type, list):
                query = query.filter(table_name.REPORT_TYPE.in_(report_type))
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_COMPCODE, code)
            return df

        def get_hk_index_valuation(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """香港股票指数估值数据"""
            table_name = HKINDEXVALUATION
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_ttm_and_mrq(self, stock_code=None, begin_date=None, end_date=None, report_period=None,
                                    statement_type=None, columns=None):
            table_name = ASHARETTMANDMRQ
            query = self.query(table_name, columns)
            if statement_type is not None:
                query = query.filter(table_name.STATEMENT_TYPE == statement_type)
            query = self.filter_date(query, table_name.REPORT_PERIOD, begin_date, end_date, report_period)
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, stock_code)
            return df

        def get_hk_share_ttm_and_mrq(self, company_code=None, begin_date=None, end_date=None, report_period=None,
                                     statement_type=None, columns=None):
            table_name = HKSHARETTMANDMRQ
            query = self.query(table_name, columns)
            if statement_type is not None:
                query = query.filter(table_name.STATEMENT_TYPE == statement_type)
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, report_period)
            df = self.batch_query(query, table_name.S_INFO_COMPCODE, company_code)
            return df

        def get_a_share_consensus_rolling_data(self, stock_code=None, rolling_type=None, begin_date=None, end_date=None,
                                               est_dt=None, columns=None):
            table_name = ASHARECONSENSUSROLLINGDATA
            query = self.query(table_name, columns)
            if rolling_type is not None:
                query = query.filter(table_name.ROLLING_TYPE == rolling_type)
            query = self.filter_date(query, table_name.EST_DT, begin_date, end_date, est_dt)
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, stock_code)
            return df

    if 'fund':
        def get_c_fund_portfolio_changes(self, fund_code=None, begin_date=None, end_date=None, report_period=None,
                                         columns=None):
            table_name = CFUNDPORTFOLIOCHANGES
            query = self.query(table_name, columns)
            query = self.filter_date(query, table_name.REPORT_PERIOD, begin_date, end_date, report_period)
            df = self.batch_query(query, table_name.F_INFO_WINDCODE, fund_code)
            return df

        def get_min_date_china_mutual_fund_nav_date(self, fund_code):
            table_name = CHINAMUTUALFUNDNAV
            query = self.session.query(func.min(table_name.PRICE_DATE)).filter(
                table_name.F_INFO_WINDCODE == fund_code)
            return pd.read_sql(query.statement, self.engine).iloc[0, 0]

        # 基金相关
        def get_cmf_proportion_of_inve_obj(self, fund_code):
            table_name = CMFPROPORTIONOFINVEOBJ
            query = self.query(table_name)
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, fund_code)
            return df

        def get_composite_benchmark(self, bm_dict: Dict, begin_date: str = None, end_date: str = None):
            """
            根据指数代码及权重，获取联合基准

            Args:
                bm_dict: 指数权重字典 {指数代码： 所占权重}, 例： {'000005.SH': 0.4, '0.000007.SH': 0.6}
                begin_date: 开始时间
                end_date: 截至时间

            Returns:
                联合基准净值序列
            """
            benchmark_nav = pd.Series([])
            benchmark_dict = {}
            for code, value in bm_dict.items():
                df_single = self.get_all_index_close(code, begin_date, end_date).sort_values(
                    'TRADE_DT').set_index('TRADE_DT')['S_DQ_CLOSE']
                df_single = df_single.rename(code)
                df_pct_chg = df_single.pct_change().fillna(0)
                df_pct_chg = df_pct_chg * value
                benchmark_dict[code] = df_pct_chg
                if len(benchmark_nav) == 0:
                    benchmark_nav = df_pct_chg
                else:
                    benchmark_nav = benchmark_nav + df_pct_chg
            return (benchmark_nav + 1).cumprod()

        def get_cmf_issuing_date_predict(self, start_date=None, end_date=None, cal_date=None, columns=None):
            """中国共同基金定期报告披露日期"""
            table_name = CMFISSUINGDATEPREDICT
            query = self.query(table_name, columns)
            if start_date is not None:
                query = query.filter(table_name.START_DT == start_date)
            if end_date is not None:
                query = query.filter(table_name.END_DT == end_date)
            if cal_date is not None:
                query = query.filter(table_name.S_STM_ACTUAL_ISSUINGDATE <= cal_date)
            df = self.read_sql(query)
            return df

        def get_existing_china_mutual_fund_code(self, date=None) -> list:
            """
            获取存续的基金列表

            Args:
                date: 日期, 如果传入None, 则为获取最新基金列表

            Returns:
                存续的基金列表
            """
            table_name = CHINAMUTUALFUNDDESCRIPTION
            query = self.query(table_name, ['F_INFO_WINDCODE'])
            if date is None:
                date = datetime.datetime.now().strftime('%Y%m%d')
            query = query.filter(table_name.F_INFO_SETUPDATE <= date).filter(
                or_(table_name.F_INFO_MATURITYDATE >= date,
                    table_name.F_INFO_MATURITYDATE.is_(None)))
            existing_fund_list = self.read_sql(query)["F_INFO_WINDCODE"].tolist()
            return existing_fund_list

        def get_all_fund_list(self) -> list:
            """
            获取全部的基金列表
            """
            table_name = CHINAMUTUALFUNDDESCRIPTION
            query = self.query(table_name, columns=['F_INFO_WINDCODE'])
            all_fund_list = self.read_sql(query)["F_INFO_WINDCODE"].tolist()
            return all_fund_list

        def get_existing_manager_list(self, date=None):
            """
            获取当前管理存续基金的基金经理
            """
            table_name = CHINAMUTUALFUNDMANAGER
            query = self.query(table_name, columns=['F_INFO_FUNDMANAGER_ID'])
            if date is None:
                date = datetime.datetime.now()
            query = query.filter(table_name.F_INFO_MANAGER_STARTDATE <= date).filter(
                or_(table_name.F_INFO_MANAGER_LEAVEDATE >= date,
                    table_name.F_INFO_MANAGER_LEAVEDATE.is_(None)))
            existing_manager_list = self.read_sql(query)["F_INFO_FUNDMANAGER_ID"].unique().tolist()
            return existing_manager_list

        def get_china_mutual_fund_nav_net_asset_total(self, code=None, begin_date=None, end_date=None, trade_date=None):
            """获取基金总资产"""
            table_name = CHINAMUTUALFUNDNAV
            query = self.query(table_name, ['F_INFO_WINDCODE', 'PRICE_DATE', 'NETASSET_TOTAL'])
            query = query.filter(table_name.NETASSET_TOTAL.isnot(None))
            # 筛选条件
            query = self.filter_date(query, table_name.PRICE_DATE, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.F_INFO_WINDCODE, code)
            return df

        def get_china_mutual_fund_nav_f_prt_net_asset(self, code=None, begin_date=None, end_date=None, trade_date=None):
            """获取基金净资产"""
            table_name = CHINAMUTUALFUNDNAV
            query = self.query(table_name, ['F_INFO_WINDCODE', 'PRICE_DATE', 'F_PRT_NETASSET'])
            query = query.filter(table_name.F_PRT_NETASSET.isnot(None))
            # 筛选条件
            query = self.filter_date(query, table_name.PRICE_DATE, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.F_INFO_WINDCODE, code)
            return df

        def get_compound_fund_benchmark(self, code, begin_date=None, end_date=None, trade_date=None):
            """获取基金复合基准收盘价"""
            if isinstance(code, str):
                code = [code]
            df_res = pd.DataFrame()
            for c in code:
                # 1. 获取基金自身净值
                fund_nav_date = self.get_distinct_china_mutual_fund_nav_date(c, begin_date, end_date, trade_date)
                # 2. 根据类型获取市场基准， 取市场基准大于自身净值最小日期的部分
                fund_sector = self.get_fund_wind_sector_name(c)
                stock_fund_type = ['普通股票型基金', '被动指数型基金', '增强指数型基金', '偏股混合型基金',
                                   '平衡混合型基金',
                                   '灵活配置型基金', '国际(QDII)股票型基金', '国际(QDII)混合型基金']
                # 市场基准
                if fund_sector in stock_fund_type:
                    index_close_df = self.get_a_index_eod_prices("000300.SH", begin_date, end_date, trade_date)
                else:
                    index_close_df = self.get_cb_index_eod_prices("h11001.CSI", begin_date, end_date, trade_date)
                index_close_series = index_close_df.set_index(['TRADE_DT'])['S_DQ_CLOSE']
                # 3. 获取基金自身基准
                benchmark_df = self.get_china_mutual_fund_benchmark_eod(c, begin_date, end_date, trade_date)
                if len(benchmark_df) > 0:
                    benchmark_series = benchmark_df.set_index(['TRADE_DT'])['S_DQ_CLOSE']
                else:
                    benchmark_series = pd.Series()
                # 4. 市场基准与自身基准分别求收益率，二者做连接，以自身基准为准
                index_pct_change = index_close_series.pct_change().dropna()
                bm_pct_change = benchmark_series.pct_change().dropna()
                diff_pct_change = index_pct_change.reindex(index_pct_change.index.difference(bm_pct_change.index))
                final_pct_change = pd.concat([diff_pct_change, bm_pct_change], axis=0)
                final_pct_change = final_pct_change.reindex(fund_nav_date).fillna(0)
                # 5. 收益率还原为指数，初始值为1
                final_nav = (final_pct_change + 1).cumprod()
                df = pd.DataFrame({"TRADE_DT": final_nav.index, "S_DQ_CLOSE": final_nav.values})
                df["S_INFO_WINDCODE"] = c
                if begin_date is not None:
                    df = df[df['TRADE_DT'] >= begin_date]
                if end_date is not None:
                    df = df[df['TRADE_DT'] <= end_date]
                if trade_date is not None:
                    df = df[df['TRADE_DT'] == trade_date]
                df_res = df_res.append(df)
            return df_res

        def _get_distinct_china_mutual_fund_nav_date(self, code: str, begin_date: Optional[str] = None,
                                                     end_date: Optional[str] = None,
                                                     trade_date: Optional[str] = None) -> List[str]:
            """
            查询净值distinct的日期

            Args:
                code: 基金代码
                begin_date: 开始日期
                end_date: 结束日期
                trade_date: 交易日期

            Returns:
                date_list: 根据日期筛选出的Distinct日期
            """
            table_name = CHINAMUTUALFUNDNAV
            query = self.query(func_query=distinct(table_name.PRICE_DATE)).filter(table_name.F_INFO_WINDCODE == code)
            # 筛选日期
            query = self.filter_date(query, table_name.PRICE_DATE, begin_date, end_date, trade_date)
            df = self.read_sql(query)
            date_list = df.iloc[:, 0].tolist()
            date_list.sort()
            return date_list

        def get_distinct_china_mutual_fund_nav_date(self, code: Union[str, List[str]], begin_date: Optional[str] = None,
                                                    end_date: Optional[str] = None,
                                                    trade_date: Optional[str] = None) -> Union[Dict, List[str]]:
            """
            查询净值distinct的日期

            Args:
                code: 基金代码
                begin_date: 开始日期
                end_date: 结束日期
                trade_date: 交易日期

            Returns:
                code_list: 根据日期筛选出的Distinct日期
            """
            if isinstance(code, str):
                date_list = self._get_distinct_china_mutual_fund_nav_date(code, begin_date, end_date, trade_date)
                return date_list
            if isinstance(code, list):
                res_dict = {}
                for c in code:
                    res_dict[c] = self._get_distinct_china_mutual_fund_nav_date(c, begin_date, end_date, trade_date)
                return res_dict

        def get_china_mutual_fund_nav(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                      columns=None) -> pd.DataFrame:
            """查询基金行情"""
            table_name = CHINAMUTUALFUNDNAV
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.PRICE_DATE, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.F_INFO_WINDCODE, code)
            if 'F_INFO_WINDCODE' in df.columns and 'PRICE_DATE' in df.columns:
                df.sort_values(by=['F_INFO_WINDCODE', 'PRICE_DATE'], inplace=True)
            elif 'PRICE_DATE' in df.columns:
                df.sort_values(by='PRICE_DATE', inplace=True)
            return df

        def get_china_mutual_fund_nav_continuous(self, code: Union[str, List], begin_date=None, end_date=None,
                                                 trade_date=None, columns=None) -> pd.DataFrame:
            """
            查询基金行情, 对于中间缺失按交易日向下填充
            """

            def _fill_nav(df: pd.DataFrame, trade_date_list):
                df = df.set_index("PRICE_DATE").reindex(trade_date_list).fillna(method='pad').reset_index(drop=False)
                return df

            table_name = CHINAMUTUALFUNDNAV
            trade_date_list_all = self.get_a_index_eod_prices('000001.SH')['TRADE_DT'].values
            if isinstance(code, str):
                code = [code]
            df_res = pd.DataFrame()
            for c in code:
                query = self.query(table_name, columns)
                trade_date_list = trade_date_list_all.copy()
                date_list = np.array(self.get_distinct_china_mutual_fund_nav_date(c))
                # 取该基金最小净值以后的交易日
                if len(date_list) == 0:
                    continue
                trade_date_list = trade_date_list[trade_date_list >= date_list[0]]
                if begin_date is not None:
                    begin_date_pre_nav_date = TradeDateUtils(date_list).get_previous_trading_date(begin_date)
                    query = query.filter(table_name.PRICE_DATE >= begin_date_pre_nav_date)
                    trade_date_list = trade_date_list[trade_date_list >= begin_date]
                if end_date is not None:
                    query = query.filter(table_name.PRICE_DATE <= end_date)
                    trade_date_list = trade_date_list[trade_date_list <= end_date]
                if trade_date is not None:
                    query = query.filter(table_name.PRICE_DATE == trade_date)
                    trade_date_list = trade_date_list[trade_date_list == trade_date]
                query = query.filter(table_name.F_INFO_WINDCODE == c)
                df = self.read_sql(query)
                df = _fill_nav(df, trade_date_list)
                df.sort_values(by='PRICE_DATE', inplace=True)
                df_res = df_res.append(df)
            return df_res

        def get_china_mutual_fund_nav_pct_chg(self, code: Union[str, List], begin_date=None, end_date=None,
                                              trade_date=None) -> pd.DataFrame:
            """
            查询基金行情, 返回收益率
            """
            table_name = CHINAMUTUALFUNDNAV
            query = self.query(table_name, ['F_INFO_WINDCODE', 'PRICE_DATE', 'F_NAV_ADJUSTED'])
            if isinstance(code, str):
                code = [code]
            df_res = pd.DataFrame()
            for c in code:
                date_list = np.array(self.get_distinct_china_mutual_fund_nav_date(c))
                # 取该基金最小净值以后的交易日
                if begin_date is not None:
                    begin_date_pre_nav_date = TradeDateUtils(date_list).get_previous_trading_date(begin_date)
                    query = query.filter(table_name.PRICE_DATE >= begin_date_pre_nav_date)
                if end_date is not None:
                    query = query.filter(table_name.PRICE_DATE <= end_date)
                if trade_date is not None:
                    query = query.filter(table_name.PRICE_DATE == trade_date)
                query = query.filter(table_name.F_INFO_WINDCODE == c)
                df = self.read_sql(query)
                df.sort_values(by='PRICE_DATE', inplace=True)
                df['PCT_CHG'] = df["F_NAV_ADJUSTED"].pct_change()
                df_res = df_res.append(df[['F_INFO_WINDCODE', 'PRICE_DATE', 'PCT_CHG']].iloc[1:])
            return df_res

        def get_china_mutual_fund_nav_max_date(self, code: Union[str, List, None] = None, batch_size=500
                                               ) -> Union[str, Dict[str, str], None]:
            """
            查询公募基金行情最大日期

            Args:
                code: 基金代码
                batch_size: 当code为list时, 单次取数据库时基金代码数

            Returns:
                若code为str, 则返回该基金最大日期, 否则返回字典, Key为基金代码, Value为对应基金的最大日期
            """
            table_name = CHINAMUTUALFUNDNAV
            query = self.query(table_name, ['F_INFO_WINDCODE'], func.max(table_name.PRICE_DATE)).group_by(
                table_name.F_INFO_WINDCODE)
            # 查询数据
            df = self.batch_query(query, table_name.F_INFO_WINDCODE, code, batch_size=batch_size)
            if isinstance(code, str):
                if len(df) > 0:
                    return df.values[0][1]
                else:
                    return None
            else:
                return df.set_index("F_INFO_WINDCODE").iloc[:, 0].to_dict()

        def get_china_mf_performance(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                     columns=None) -> pd.DataFrame:
            """中国共同基金业绩表现"""
            table_name = CHINAMFPERFORMANCE
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_china_mfm_performance(self, manager_id=None, begin_date=None, end_date=None,
                                      trade_date=None, columns=None) -> pd.DataFrame:
            """中国共同基金基金经理业绩表现"""
            table_name = CHINAMFMPERFORMANCE
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DATE, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.FUNDMANAGER_ID, manager_id)
            return df

        def get_china_mutual_fund_description(self, code=None, company_id=None, columns=None):
            """查询中国共同基金基本资料"""
            table_name = CHINAMUTUALFUNDDESCRIPTION
            query = self.query(table_name, columns)
            if company_id is not None:
                query = query.filter(table_name.F_INFO_CORP_FUNDMANAGEMENTID == company_id)
            # 查询数据
            df = self.batch_query(query, table_name.F_INFO_WINDCODE, code)
            return df

        def get_distinct_china_mutual_fund_description(self):
            """获取所有共同基金代码"""
            table_name = CHINAMUTUALFUNDDESCRIPTION
            query = self.query(func_query=distinct(table_name.F_INFO_WINDCODE))
            df = self.read_sql(query)
            code_list = list(df.iloc[:, 0])
            return code_list

        def get_distinct_date_a_share_eod_prices(self):
            """获取ASHAREEODPRICES所有日期"""
            table_name = ASHAREEODPRICES
            query = self.query(func_query=distinct(table_name.TRADE_DT))
            df = self.read_sql(query)
            code_list = list(df.iloc[:, 0])
            return code_list

        def get_distinct_date_a_share_eod_derivative_indicator(self):
            """获取ASHAREEODDERIVATIVEINDICATOR所有日期"""
            table_name = ASHAREEODDERIVATIVEINDICATOR
            query = self.query(func_query=distinct(table_name.TRADE_DT))
            df = self.read_sql(query)
            code_list = list(df.iloc[:, 0])
            return code_list

        def get_china_in_house_fund_description(self, code=None, columns=None):
            """中国券商理财基本资料"""
            table_name = CHINAINHOUSEFUNDDESCRIPTION
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.F_INFO_WINDCODE, code)
            return df

        def get_cmf_index_eod(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """中国共同基金指数行情"""
            table_name = CMFINDEXEOD
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_cmf_financial_indicator(self, code=None, begin_date=None, end_date=None, report_period=None,
                                        columns=None):
            """中国共同基金财务指标(报告期)"""
            table_name = CMFFINANCIALINDICATOR
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.REPORT_PERIOD, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_china_mutual_fund_manager(self, code=None, manager_id=None, columns=None):
            """中国共同基金基金经理"""
            table_name = CHINAMUTUALFUNDMANAGER
            query = self.query(table_name, columns)
            # 筛选条件
            if code is not None:
                if isinstance(code, str):
                    query = query.filter(table_name.F_INFO_WINDCODE == code)
                elif isinstance(code, list):
                    query = query.filter(table_name.F_INFO_WINDCODE.in_(code))
            if manager_id is not None:
                if isinstance(manager_id, str):
                    query = query.filter(table_name.F_INFO_FUNDMANAGER_ID == manager_id)
                elif isinstance(manager_id, list):
                    query = query.filter(table_name.F_INFO_FUNDMANAGER_ID.in_(manager_id))
            # 查询数据
            df = self.read_sql(query)
            return df

        def get_china_mutual_fund_manager_by_fund(self, code=None, columns=None):
            """中国共同基金基金经理"""
            table_name = CHINAMUTUALFUNDMANAGER
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.F_INFO_WINDCODE, code)
            return df

        def get_china_mutual_fund_manager_by_manager(self, manager_id=None, columns=None):
            """中国共同基金基金经理"""
            table_name = CHINAMUTUALFUNDMANAGER
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.F_INFO_FUNDMANAGER_ID, manager_id)
            return df

        def get_china_mutual_fund_sector(self, code=None, cur_sign=None, columns=None, sector_like=None):
            """中国Wind基金分类"""
            table_name = CHINAMUTUALFUNDSECTOR
            query = self.query(table_name, columns)
            # 筛选条件
            if cur_sign is not None:
                query = query.filter(table_name.CUR_SIGN == cur_sign)
            if sector_like is not None:
                query = query.filter(table_name.S_INFO_SECTOR.like(sector_like))
            # 查询数据
            df = self.batch_query(query, table_name.F_INFO_WINDCODE, code)
            return df

        def get_china_mutual_fund_sector_by_invest_type(self, code=None, columns=None):
            """中国Wind基金分类"""
            return self.get_china_mutual_fund_sector(code=code, columns=columns, sector_like='2001010%')

        def get_fund_benchmark_mapping_code_bm(self, fund_code: Union[str, list, None] = None) -> Dict[str, str]:
            """
            获取基金本身代码->基金基准行情代码的映射

            Args:
                fund_code: 基金代码

            Returns:
                映射字典, Key为基金代码, Value为基准的代码

            Examples:
                >>> WindReader().get_fund_benchmark_mapping_code_bm('110011.OF')
                {'110011.OF': '110011BI.WI'}
            """
            table_name = CHINAMUTUALFUNDDESCRIPTION
            query = self.query(table_name, columns=['F_INFO_WINDCODE'])
            # 查询数据
            df = self.batch_query(query, table_name.F_INFO_WINDCODE, fund_code)
            df["bm"] = df['F_INFO_WINDCODE'].apply(lambda x: x.split('.')[0] + 'BI.WI')
            res_dict = df.set_index('F_INFO_WINDCODE')['bm'].to_dict()
            return res_dict

        def get_fund_benchmark_mapping_bm_code(self, fund_code: Union[str, list, None] = None) -> Dict[str, str]:
            """
            获取基金基准行情代码->基金本身代码的映射

            Args:
                fund_code: 基金代码

            Returns:
                映射字典, Key为基准代码, Value为基金代码

            Examples:
                >>> WindReader().get_fund_benchmark_mapping_bm_code('110011.OF')
                {'110011BI.WI': '110011.OF'}
            """
            res_dict = self.get_fund_benchmark_mapping_code_bm(fund_code)
            return {v: k for k, v in res_dict.items()}

        def _get_china_mutual_fund_benchmark_eod(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                                 columns=None):
            """中国共同基金业绩比较基准行情"""
            table_name = CHINAMUTUALFUNDBENCHMARKEOD
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            code_bm = None
            if isinstance(code, str):
                code_bm = code[:6] + 'BI.WI'
            elif isinstance(code, list):
                code_bm = list(set([i[:6] + 'BI.WI' for i in code]))
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code_bm)
            # 根据基金代码与基准代码的映射表, 将基准代码转换成基金代码
            bm_code_mapping = self.get_fund_benchmark_mapping_bm_code(code)
            df['S_INFO_WINDCODE'] = df['S_INFO_WINDCODE'].map(bm_code_mapping)
            if 'S_INFO_WINDCODE' in df.columns and 'TRADE_DT' in df.columns:
                df.sort_values(by=['S_INFO_WINDCODE', 'TRADE_DT'], inplace=True)
            elif 'TRADE_DT' in df.columns:
                df.sort_values(by='TRADE_DT', inplace=True)
            return df

        def get_china_mutual_fund_benchmark_eod(self, code=None, begin_date=None, end_date=None, trade_date=None):
            """中国共同基金业绩比较基准行情"""
            df = self._get_china_mutual_fund_benchmark_eod(code, begin_date, end_date, trade_date)
            # 根据基金代码与基准代码的映射表, 将基准代码转换成基金代码
            bm_code_mapping = self.get_fund_benchmark_mapping_bm_code(code)
            df['S_INFO_WINDCODE'] = df['S_INFO_WINDCODE'].map(bm_code_mapping)
            return df

        def get_china_mutual_fund_share(self, code=None, begin_date=None, end_date=None, report_period=None,
                                        columns=None):
            """中国共同基金份额"""
            table_name = CHINAMUTUALFUNDSHARE
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.CHANGE_DATE, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.F_INFO_WINDCODE, code)
            return df

        def get_cmf_holder_structure(self, code=None, begin_date=None, end_date=None, report_period=None, columns=None):
            """中国共同基金持有人结构"""
            table_name = CMFHOLDERSTRUCTURE
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.END_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def _get_distinct_cmf_holder_structure_date(self, code: str, begin_date: Optional[str] = None,
                                                    end_date: Optional[str] = None,
                                                    trade_date: Optional[str] = None) -> List[str]:
            """
            查询cmf_holder_structure的distinct日期

            Args:
                code: 基金代码
                begin_date: 开始日期
                end_date: 结束日期
                trade_date: 交易日期

            Returns:
                code_list: 根据日期筛选出的Distinct日期
            """
            table_name = CMFHOLDERSTRUCTURE
            query = self.query(func_query=distinct(table_name.END_DT)).filter(table_name.S_INFO_WINDCODE == code)
            query = self.filter_date(query, table_name.END_DT, begin_date, end_date, trade_date)

            df = self.read_sql(query)
            code_list = df.iloc[:, 0].tolist()
            code_list.sort()
            return code_list

        def get_distinct_cmf_holder_structure_date(self, code: Union[str, List[str]], begin_date: Optional[str] = None,
                                                   end_date: Optional[str] = None,
                                                   trade_date: Optional[str] = None) -> Union[Dict, List[str]]:
            """
            查询净值distinct的日期

            Args:
                code: 基金代码
                begin_date: 开始日期
                end_date: 结束日期
                trade_date: 交易日期

            Returns:
                code_list: 根据日期筛选出的Distinct日期
            """
            if isinstance(code, str):
                date_list = self._get_distinct_cmf_holder_structure_date(code, begin_date, end_date, trade_date)
                return date_list
            if isinstance(code, list):
                res_dict = {}
                for c in code:
                    res_dict[c] = self._get_distinct_cmf_holder_structure_date(c, begin_date, end_date, trade_date)
                return res_dict

        def get_c_fund_introduction(self, company_short_name=None, company_id=None, columns=None):
            """中国基金公司简介"""
            table_name = CFUNDINTRODUCTION
            query = self.query(table_name, columns)
            if company_short_name is not None:
                if isinstance(company_short_name, str):
                    query = query.filter(table_name.COMP_SNAME == company_short_name)
                elif isinstance(company_short_name, list):
                    query = query.filter(table_name.COMP_SNAME.in_(company_short_name))
            if company_id is not None:
                if isinstance(company_id, str):
                    query = query.filter(table_name.COMP_ID == company_id)
                elif isinstance(company_id, list):
                    query = query.filter(table_name.COMP_ID.in_(company_id))
            # 查询数据
            df = self.read_sql(query)
            return df

        def get_china_mutual_fund_asset_portfolio(self, code=None, begin_date=None, end_date=None, report_period=None,
                                                  columns=None):
            """中国共同基金投资组合-资产配置"""
            table_name = CHINAMUTUALFUNDASSETPORTFOLIO
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.F_PRT_ENDDATE, begin_date, end_date, report_period, if_cast=True)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_china_mutual_fund_stock_portfolio(self, code=None, begin_date=None, end_date=None, report_period=None,
                                                  is_top10=False, columns=None):
            """中国共同基金投资组合——持股明细"""
            table_name = CHINAMUTUALFUNDSTOCKPORTFOLIO
            query = self.query(table_name, columns)
            query = self.filter_date(query, table_name.F_PRT_ENDDATE, begin_date, end_date, report_period)
            df_portfolio_all = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            if not is_top10:
                df_portfolio = df_portfolio_all
            else:
                df_portfolio = pd.DataFrame()
                for _, grouped in df_portfolio_all.groupby(['F_PRT_ENDDATE', 'S_INFO_WINDCODE']):
                    grouped['rank'] = grouped['F_PRT_STKVALUE'].rank(method='min', ascending=False)
                    df_portfolio = df_portfolio.append(grouped[grouped['rank'] <= 10])  # 排名一致则都取出
            return df_portfolio

        def get_china_mutual_fund_stock_portfolio_by_date(self, report_period, is_top10=False, cal_date=None):
            """
            基金的股票投资组合
            """
            df_portfolio_all = self.get_china_mutual_fund_stock_portfolio(report_period=report_period)
            # 公告日期比计算日期早
            if cal_date is not None:
                df_portfolio_all = df_portfolio_all.loc[df_portfolio_all['ANN_DATE'] <= cal_date]

            if is_top10:
                df_portfolio = pd.DataFrame()
                for fund_code, grouped in df_portfolio_all.groupby('S_INFO_WINDCODE'):
                    grouped['rank'] = grouped['F_PRT_STKVALUE'].rank(method='min')
                    df_portfolio = df_portfolio.append(grouped[grouped['rank'] <= 10])  # 并列第10名有多个则都取出
            else:
                # 取全部持仓, 则从公告日期表找出已有半年报/年报的基金
                start_date = report_period[:4] + '0101'
                df_issue_date = self.get_cmf_issuing_date_predict(start_date=start_date, end_date=report_period,
                                                                  cal_date=cal_date)
                code_list = df_issue_date['S_INFO_WINDCODE'].tolist()
                df_portfolio = df_portfolio_all.loc[df_portfolio_all['S_INFO_WINDCODE'].isin(code_list)]
            return df_portfolio

        def get_china_mutual_fund_ind_portfolio(self, code=None, begin_date=None, end_date=None, report_period=None,
                                                columns=None):
            """中国共同基金投资组合——行业配置"""
            table_name = CHINAMUTUALFUNDINDPORTFOLIO
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.F_PRT_ENDDATE, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_china_mutual_fund_bond_portfolio(self, code=None, begin_date=None, end_date=None, report_period=None,
                                                 columns=None):
            """中国共同基金投资组合-持券明细"""
            table_name = CHINAMUTUALFUNDBONDPORTFOLIO
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.F_PRT_ENDDATE, begin_date, end_date, report_period, if_cast=True)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_cmf_other_portfolio(self, code=None, begin_date=None, end_date=None, report_period=None, columns=None):
            """中国共同基金投资组合——其他证券"""
            table_name = CMFOTHERPORTFOLIO
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.END_DT, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_china_mutual_fund_issue(self, code=None, columns=None):
            """中国共同基金发行"""
            table_name = CHINAMUTUALFUNDISSUE
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_china_mutual_fund_suspend_pch_redm(self, code=None, columns=None):
            """中国共同基金暂停申购赎回"""
            table_name = CHINAMUTUALFUNDSUSPENDPCHREDM
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_china_mutual_fund_pch_redm(self, code=None, columns=None):
            """中国共同基金申购赎回"""
            table_name = CHINAMUTUALFUNDPCHREDM
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_lof_pch_redm(self, code=None, columns=None):
            """中国开放式基金场内申购赎回"""
            table_name = LOFPCHREDM
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_etf_pch_redm(self, code=None, columns=None):
            """中国ETF申购赎回"""
            table_name = ETFPCHREDM
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_etf_pch_redm_members(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """中国ETF申购赎回成份"""
            table_name = CHINAETFPCHREDMMEMBERS
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_china_etf_pch_redm_list(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """中国ETF申购赎回清单"""
            table_name = CHINAETFPCHREDMLIST
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_closed_fund_pch_redm(self, code=None, columns=None):
            """中国封闭式基金场内申购赎回"""
            table_name = CLOSEDFUNDPCHREDM
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_cmf_subred_fee(self, code=None, columns=None):
            """中国开放式基金费率表"""
            table_name = CMFSUBREDFEE
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_china_mf_dividend(self, code=None, columns=None):
            """中国共同基金分红"""
            table_name = CHINAMFDIVIDEND
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_c_fund_pch_redm(self, code=None, columns=None):
            """中国共同基金申购赎回天数"""
            table_name = CFUNDPCHREDM
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.F_INFO_WINDCODE, code)
            return df

        def get_cm_fund_split(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """中国共同基金基金份额拆分与折算"""
            table_name = CMFUNDSPLIT
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.F_INFO_SHARETRANSDATE, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_china_mutual_fund_tracking_index(self, code=None, columns=None):
            """中国共同基金被动型基金跟踪指数"""
            table_name = CHINAMUTUALFUNDTRACKINGINDEX
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_c_fund_rate_sensitive(self, code=None, begin_date=None, end_date=None, report_period=None,
                                      columns=None):
            """中国共同基金利率敏感分析"""
            table_name = CFUNDRATESENSITIVE
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.REPORT_PERIOD, begin_date, end_date, report_period)
            # 查询数据
            df = self.batch_query(query, table_name.F_INFO_WINDCODE, code)
            return df

        def get_china_mutual_fund_transformation(self, pre_code=None, post_code=None, columns=None):
            """中国共同基金转型"""
            table_name = CHINAMUTUALFUNDTRANSFORMATION
            query = self.query(table_name, columns)
            # 筛选条件
            if pre_code is not None:
                if isinstance(pre_code, str):
                    query = query.filter(table_name.PREWINDCODE == pre_code)
                elif isinstance(pre_code, list):
                    query = query.filter(table_name.PREWINDCODE.in_(pre_code))
            if post_code is not None:
                if isinstance(post_code, str):
                    query = query.filter(table_name.POSTWINDCODE == post_code)
                elif isinstance(post_code, list):
                    query = query.filter(table_name.POSTWINDCODE.in_(post_code))
            # 查询数据
            df = self.read_sql(query)
            return df

        def get_cmf_code_and_s_name(self, code=None, columns=None):
            """中国共同基金业务代码及简称"""
            table_name = CMFCODEANDSNAME
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_c_money_market_daily_f_income(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                              columns=None):
            """中国货币式基金日收益(拆分)"""
            table_name = CMONEYMARKETDAILYFINCOME
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.F_INFO_ENDDATE, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_cmm_quarterly_data(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """中国货币式基金日收益(拆分)"""
            table_name = CMMQUARTERLYDATA
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.F_INFO_ENDDATE, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_china_closed_fund_eod_price(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                            columns=None):
            """中国上市基金日行情"""
            table_name = CHINACLOSEDFUNDEODPRICE
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def _get_distinct_china_closed_fund_eod_price_date(self, code: str, begin_date: Optional[str] = None,
                                                           end_date: Optional[str] = None,
                                                           trade_date: Optional[str] = None) -> List[str]:
            """
            查询cmf_holder_structure的distinct日期

            Args:
                code: 基金代码
                begin_date: 开始日期
                end_date: 结束日期
                trade_date: 交易日期

            Returns:
                code_list: 根据日期筛选出的Distinct日期
            """
            table_name = CHINACLOSEDFUNDEODPRICE
            query = self.query(func_query=distinct(table_name.TRADE_DT)).filter(table_name.S_INFO_WINDCODE == code)
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            df = self.read_sql(query)
            code_list = df.iloc[:, 0].tolist()
            code_list.sort()
            return code_list

        def get_distinct_china_closed_fund_eod_price_date(self, code: Union[str, List[str]],
                                                          begin_date: Optional[str] = None,
                                                          end_date: Optional[str] = None,
                                                          trade_date: Optional[str] = None) -> Union[Dict, List[str]]:
            """
            查询distinct的日期

            Args:
                code: 基金代码
                begin_date: 开始日期
                end_date: 结束日期
                trade_date: 交易日期

            Returns:
                code_list: 根据日期筛选出的Distinct日期
            """
            if isinstance(code, str):
                date_list = self._get_distinct_china_closed_fund_eod_price_date(code, begin_date, end_date, trade_date)
                return date_list
            if isinstance(code, list):
                res_dict = {}
                for c in code:
                    res_dict[c] = self._get_distinct_china_closed_fund_eod_price_date(c, begin_date, end_date,
                                                                                      trade_date)
                return res_dict

        def get_china_mutual_fund_float_share(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                              columns=None):
            """中国共同基金场内流通份额"""
            table_name = CHINAMUTUALFUNDFLOATSHARE
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_wind_industry_map_code_name(self, level=None):
            """
            获取行业代码与行业名称映射

            Returns
            -------
            """
            if level is not None:
                level = level + 3
            df_industry_code = self.get_a_share_industries_code(ind_code_like="200101%", level=level)
            industry_map = df_industry_code.set_index("INDUSTRIESCODE")["INDUSTRIESNAME"].to_dict()
            industry_map = {k: v for k, v in industry_map.items() if not k.startswith("20010105")}  # 20010105已废弃
            if level == 2 + 3:  # 货币市场型基金无二级分类
                industry_map["2001010400000000"] = "货币市场型基金"
            return industry_map

        def get_cc_bond_conversion(self, fund_code=None, begin_date=None, end_date=None, trade_date=None):
            table_name = CCBONDCONVERSION
            query = self.query(table_name)
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, trade_date)
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, fund_code)
            return df

        def get_cc_bond_valuation(self, fund_code=None, begin_date=None, end_date=None, trade_date=None):
            table_name = CCBONDVALUATION
            query = self.query(table_name)
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, fund_code)
            return df

        def get_cmf_proportion_of_inve_obj(self, fund_code):
            table_name = CMFPROPORTIONOFINVEOBJ
            query = self.query(table_name)
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, fund_code)
            return df

        def get_wind_industry_map_name_code(self, level=None) -> Dict[str, str]:
            """
            获取行业名称与行业代码的映射
            """
            res_dict = self.get_wind_industry_map_code_name(level)
            return {v: k for k, v in res_dict.items()}

        def get_fund_wind_sector_name(self, fund_code: Union[str, List[str], None] = None,
                                      date: Optional[str] = None, level=2):
            """获取基金的Wind分类名称"""
            res = self.get_fund_wind_sector_code(fund_code, date, level)
            wind_industry_map = self.get_wind_industry_map_code_name()
            if isinstance(fund_code, str):
                if res not in wind_industry_map:
                    return "其他"
                else:
                    return wind_industry_map[res]
            else:
                return pd.Series(res).map(wind_industry_map).fillna("其他").to_dict()

        def get_fund_wind_sector_code(self, fund_code: Union[str, List[str], None] = None,
                                      date: Optional[str] = None, level=2):
            """
            获取基金的Wind分类

            Args:
                fund_code: 基金代码
                date: 日期, 默认为None, 若为None表示最新日期
                level: 分类层级, 默认二级分类

            Returns:
                若传入的基金代码是str, 则返回基金分类
                若传入的基金代码是None或list, 则返回基金分类字典
            """
            table_name = CHINAMUTUALFUNDSECTOR
            query = self.query(table_name).filter(table_name.S_INFO_SECTOR.like("200101%"))
            if date is not None:
                query = query.filter(table_name.S_INFO_SECTORENTRYDT <= date).filter(
                    or_(table_name.S_INFO_SECTOREXITDT >= date,
                        table_name.S_INFO_SECTOREXITDT.is_(None)))
            else:
                query = query.filter(table_name.S_INFO_SECTOREXITDT.is_(None))
            # 查询数据
            df = self.batch_query(query, table_name.F_INFO_WINDCODE, fund_code)
            if level == 1:
                # Wind一级分类, 8位代码 + 8个0, 如2001010100000000代表股票型基金
                df["S_INFO_SECTOR"] = df["S_INFO_SECTOR"].apply(lambda x: x[:8] + '0' * 8)
            elif level == 2:
                # Wind二级分类, 10位代码 + 6个0, 如2001010101000000代表普通股票型基金
                df["S_INFO_SECTOR"] = df["S_INFO_SECTOR"].apply(lambda x: x[:10] + '0' * 6)
            elif level == 3:
                # Wind三级分类, 12位代码+4个0, 如2001010801010000代表国际(QDII)普通股票型基金
                # 注意只有国际(QDII)基金、FOF基金存在三级分类
                df["S_INFO_SECTOR"] = df["S_INFO_SECTOR"].apply(lambda x: x[:12] + '0' * 4)

            df["S_INFO_SECTOR"] = df["S_INFO_SECTOR"].fillna("其他")
            if fund_code is not None and isinstance(fund_code, str):
                if len(df["S_INFO_SECTOR"]) > 0:
                    return df["S_INFO_SECTOR"].values[0]
                else:
                    return "其他"
            else:
                return df.set_index("F_INFO_WINDCODE")["S_INFO_SECTOR"].to_dict()

        def get_fund_code_by_wind_sector(self, sector_code):
            """
            根据类型获取基金代码列表
            """
            df_fund_sector = self.get_china_mutual_fund_sector(cur_sign=1, sector_like=sector_code)
            code_list = df_fund_sector['F_INFO_WINDCODE'].unique().tolist()
            return code_list

        def get_parent_code(self, fund_code: str):
            """
            查看母基金代码
            """
            table_name = CHINAMUTUALFUNDDESCRIPTION
            query = self.query(table_name).filter(table_name.F_INFO_WINDCODE == fund_code)
            df = self.read_sql(query)
            if len(df) > 0:
                is_initial = df["F_INFO_ISINITIAL"].tolist()[0]
                if is_initial == 1:
                    return None
                full_name = df['F_INFO_FULLNAME'].tolist()[0]
                query = self.query(table_name).filter(table_name.F_INFO_FULLNAME == full_name,
                                                      table_name.F_INFO_ISINITIAL == 1)
                df_parent = self.read_sql(query)
                parent_code_list = df_parent['F_INFO_WINDCODE'].tolist()
                parent_code_list = [v for v in parent_code_list if "!" not in v]
                if len(parent_code_list) > 0:
                    parent_code = parent_code_list[0]
                    if parent_code == fund_code:
                        return None
                    else:
                        return parent_code
            return None

        def get_china_mutual_fund_issue_name(self, fund_code: str):
            """获取共同基金发行名称"""
            table_name = CHINAMUTUALFUNDISSUE
            query = self.query(table_name, columns=['S_INFO_WINDCODE', 'F_INFO_SHORTNAME']).filter(
                table_name.S_INFO_WINDCODE == fund_code)
            df = self.read_sql(query)
            if len(df) > 0:
                return df['F_INFO_SHORTNAME'].values.tolist()[0]
            else:
                return None

        def get_manager_manage_fund_list(self, manager_id: str, date: Optional[str] = None) -> List:
            """
            获取基金经理管理基金列表

            Args:
                manager_id: 基金经理ID
                date: 日期, 默认为None, 表示最新日期, 若为"all"表示管理的全部基金, 若为日期则表示当时在管的基金

            Returns:
                该基金经理管理的基金列表
            """
            table_name = CHINAMUTUALFUNDMANAGER
            query = self.query(table_name).filter(table_name.F_INFO_FUNDMANAGER_ID == manager_id)
            if date is None:
                query = query.filter(table_name.F_INFO_MANAGER_LEAVEDATE.is_(None))
            elif date.upper() != "ALL":
                query = query.filter(table_name.F_INFO_MANAGER_STARTDATE >= date).filter(
                    or_(table_name.F_INFO_MANAGER_LEAVEDATE <= date,
                        table_name.F_INFO_MANAGER_LEAVEDATE.is_(None)))
            df = self.read_sql(query)
            return df["F_INFO_WINDCODE"].unique().tolist()

        def get_fund_ann_inf(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """基金公告信息"""
            table_name = FUNDANNINF
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.ANN_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

    if 'bond':
        # 债券相关
        def get_c_bond_amount(self, bond_code, columns=None):
            """中国债券份额变动"""
            table_name = CBONDAMOUNT
            query = self.query(table_name, columns).filter(table_name.S_INFO_WINDCODE == bond_code)
            df = self.read_sql(query)
            return df

        def get_c_bond_eod_prices(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """沪深交易所债券的行情数据"""
            table_name = CBONDEODPRICES
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_cb_index_eod_prices(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """债券指数的日收盘行情"""
            table_name = CBINDEXEODPRICES
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            if 'TRADE_DT' in df.columns:
                df.sort_values(by='TRADE_DT', inplace=True)
            return df

        def get_c_bond_index_eod_cnbd(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            table_name = CBONDINDEXEODCNBD
            query = self.query(table_name, columns)
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_c_bond_industry_wind(self, code=None, columns=None):
            """中国债券Wind分类板块"""
            table_name = CBONDINDUSTRYWIND
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_c_bond_rating(self, code=None, columns=None):
            """中国债券信用评级"""
            table_name = CBONDRATING
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_c_bond_description(self, code=None, columns=None):
            """中国债券基本资料"""
            table_name = CBONDDESCRIPTION
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_c_bond_issuer_rating(self, code=None, columns=None):
            """中国债券发行主体信用评级"""
            table_name = CBONDISSUERRATING
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_COMPCODE, code)
            return df

        def get_c_bond_curve_cnbd(self, begin_date=None, end_date=None, trade_date=None,
                                  curve_number: Union[int, str, None] = None, curve_type: Optional[str] = None,
                                  curve_term: Optional[float] = None, columns: Optional[list] = None) -> pd.DataFrame:
            """
            中债登债券收益率曲线

            Args:
                begin_date: str, 开始日期；
                end_date: str, 结束日期；
                trade_date: str, 交易日期；
                curve_number: int, 曲线编号；
                curve_type: str, 曲线类型;
                curve_term: float, 标准期限(年)；
                columns: list, 查询字段。

            Returns:
                pd.DataFrame
            """
            table_name = CBONDCURVECNBD
            query = self.query(table_name, columns)
            # 筛选条件
            if begin_date is not None:
                query = query.filter(table_name.TRADE_DT >= begin_date)
            if end_date is not None:
                query = query.filter(table_name.TRADE_DT <= end_date)
            if trade_date is not None:
                query = query.filter(table_name.TRADE_DT == trade_date)
            if curve_number is not None:
                if isinstance(curve_number, list):
                    query = query.filter(table_name.B_ANAL_CURVENUMBER.in_(curve_number))
                else:
                    query = query.filter(table_name.B_ANAL_CURVENUMBER == curve_number)

            if curve_type is not None:
                query = query.filter(table_name.B_ANAL_CURVETYPE == curve_type)
            if curve_term is not None:
                query = query.filter(table_name.B_ANAL_CURVETERM == curve_term)
            # 查询数据
            df = self.read_sql(query)
            return df

        def get_c_bond_valuation(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            """中国债券衍生指标"""
            table_name = CBONDVALUATION
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_cc_bond_issuance(self, code=None, columns=None):
            """中国可转债发行"""
            table_name = CCBONDISSUANCE
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_cc_bond_conversion(self, bond_code=None, conv_start_date=None, conv_end_date=None, columns=None):
            table_name = CCBONDCONVERSION
            query = self.query(table_name, columns)
            query = self.filter_date(query, table_name.CONV_STARTDATE,
                                     end_date=conv_start_date)  # CONV_STARTDATE <= conv_start_date
            query = self.filter_date(query, table_name.CONV_ENDDATE,
                                     begin_date=conv_end_date)  # CONV_ENDDATE >= conv_end_date
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, bond_code)
            return df

        def get_cc_bond_valuation(self, bond_code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
            table_name = CCBONDVALUATION
            query = self.query(table_name, columns)
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, bond_code)
            return df

        def get_sec_code_cnbd(self, bond_code=None, columns=None):
            table_name = SECCODECNBD
            query = self.query(table_name, columns)
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, bond_code)
            return df

        def get_same_name_bond_code(self, bond_code=None):
            """查看中国债券基本资料同名债卷"""
            table_name = CBONDDESCRIPTION
            query = self.query(table_name).filter(table_name.S_INFO_WINDCODE == bond_code)
            # 查询数据
            df = self.read_sql(query)
            if len(df) == 0:
                return None
            else:
                full_name = df['B_INFO_FULLNAME'].values[0]
                query = self.query(table_name).filter(table_name.B_INFO_FULLNAME == full_name)
                df_full_name = self.read_sql(query)
                bond_code_list = df_full_name['S_INFO_WINDCODE'].tolist()
                return bond_code_list

        def get_bond_analysis_cnbd(self, bond_code, begin_date=None, end_date=None, trade_date=None, columns=None):
            df_cnbd_table = self.get_sec_code_cnbd(bond_code)
            df_cnbd_table.dropna(subset=["TABNAME"], inplace=True)
            if len(df_cnbd_table) == 0:
                return None
            cnbd_table = df_cnbd_table["TABNAME"].tolist()[0].upper()
            table_map = {"CBONDANALYSISCNBD1": CBONDANALYSISCNBD1,
                         "CBONDANALYSISCNBD2": CBONDANALYSISCNBD2,
                         "CBONDANALYSISCNBD3": CBONDANALYSISCNBD3,
                         "CBONDANALYSISCNBD4": CBONDANALYSISCNBD4,
                         "CBONDANALYSISCNBD5": CBONDANALYSISCNBD5,
                         "CBONDANALYSISCNBD6": CBONDANALYSISCNBD6,
                         "CBONDANALYSISCNBD7": CBONDANALYSISCNBD7,
                         "CBONDANALYSISCNBD8": CBONDANALYSISCNBD8,
                         "CBONDANALYSISCNBD9": CBONDANALYSISCNBD9,
                         }
            table_name = table_map[cnbd_table]
            query = self.query(table_name, columns)
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, bond_code)
            return df

    if 'futures':
        # 期货相关
        def get_distinct_date_china_mutual_fund_asset_portfolio(self, fund_code):
            """
            获取基金的资产配置日期
            """
            table_name = CHINAMUTUALFUNDASSETPORTFOLIO
            query = self.query(func_query=distinct(table_name.F_PRT_ENDDATE)).filter(
                table_name.S_INFO_WINDCODE == fund_code)
            df = self.read_sql(query)
            code_list = df.iloc[:, 0].tolist()
            code_list.sort()
            return code_list

        def get_c_index_futures_eod_prices(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                           columns=None):
            """查询股指期货行情"""
            table_name = CINDEXFUTURESEODPRICES
            query = self.query(table_name, columns)
            # 筛选条件
            query = self.filter_date(query, table_name.TRADE_DT, begin_date, end_date, trade_date)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            if 'S_INFO_WINDCODE' in df.columns and 'TRADE_DT' in df.columns:
                df.sort_values(by=['S_INFO_WINDCODE', 'TRADE_DT'], inplace=True)
            elif 'TRADE_DT' in df.columns:
                df.sort_values(by='TRADE_DT', inplace=True)
            return df

        def get_c_futures_description(self, code=None, columns=None):
            """
            中国期货基本资料
            """
            table_name = CFUTURESDESCRIPTION
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_c_futures_description_distinct_code(self):
            table_name = CFUTURESDESCRIPTION
            query = self.query(func_query=distinct(table_name.S_INFO_WINDCODE))
            df = self.read_sql(query)
            code_list = list(df.iloc[:, 0])
            return code_list

        def get_cmf_income(self, fund_code, report_period=None, columns=None):
            table_name = CMFINCOME
            query = self.query(table_name, columns)
            query = self.filter_date(query, table_name.REPORT_PERIOD, trade_date=report_period)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, fund_code)
            return df

    if 'others':
        # 其他
        def get_related_securities_code(self, code=None, columns=None):
            """证券关系表"""
            table_name = RALATEDSECURITIESCODE
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_wind_custom_code(self, code=None, columns=None):
            """Wind兼容代码"""
            table_name = WINDCUSTOMCODE
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_index_contrast_sector(self, code=None, ind_code=None, columns=None):
            """指数板块对照"""
            table_name = INDEXCONTRASTSECTOR
            query = self.query(table_name, columns)
            if ind_code is not None:
                df = self.batch_query(query, table_name.S_INFO_INDUSTRYCODE, ind_code)
            else:
                # 查询数据
                df = self.batch_query(query, table_name.S_INFO_INDEXCODE, code)
            return df

        def get_a_index_financial_derivative(self, index_code: Union[str, List] = None,
                                             begin_date: Optional[str] = None, end_date: Optional[str] = None,
                                             report_period: Optional = None, columns=None):
            """中国A股指数财务衍生指标"""
            table_name = AINDEXFINANCIALDERIVATIVE
            query = self.query(table_name, columns)
            query = self.filter_date(query, table_name.REPORT_PERIOD, begin_date, end_date, report_period)
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, index_code)
            return df

        def get_hk_index_description(self, code: Union[str, List] = None, columns=None):
            """香港股票指数基本资料"""
            table_name = HKINDEXDESCRIPTION
            query = self.query(table_name, columns)
            # 查询数据
            df = self.batch_query(query, table_name.S_INFO_WINDCODE, code)
            return df

        def get_a_share_profit_express(self, stock_code: str, ann_begin_date=None, ann_end_date=None,
                                       ann_trade_date=None, report_period=None, columns=None):
            table_name = ASHAREPROFITEXPRESS
            query = self.query(table_name, columns).filter(table_name.S_INFO_WINDCODE == stock_code)
            if report_period is not None:
                query = query.filter(table_name.REPORT_PERIOD == report_period)
            query = self.filter_date(query, table_name.ANN_DT, ann_begin_date, ann_end_date, ann_trade_date)
            df = self.read_sql(query)
            return df

        def get_industry_code_from_industry_name(self, industry_name='SW', level=1):
            table_name = ASHAREINDUSTRIESCODE
            query = self.query(table_name).filter(table_name.USED == 1,
                                                  table_name.LEVELNUM == INDUSTRY_DICT[industry_name]['margin'] + level,
                                                  table_name.INDUSTRIESCODE.like(
                                                      f"{INDUSTRY_DICT[industry_name]['prefix']}%"))
            df = self.read_sql(query)
            industry_code_list = df['INDUSTRIESCODE'].unique().tolist()
            return industry_code_list

        def get_index_code_from_industry_code(self, industry_code, columns=None):
            table_name = INDEXCONTRASTSECTOR
            query = self.query(table_name, columns)
            df = self.batch_query(query, table_name.S_INFO_INDUSTRYCODE, industry_code)
            return df

        def get_a_share_industries_class(self, stock_code, begin_date=None, end_date=None, trade_date=None,
                                         columns=None):
            """获取股票行业分类"""
            table_name = ASHAREINDUSTRIESCLASS
            query = self.query(table_name, columns)

            if trade_date is not None:
                query = query.filter(table_name.ENTRY_DT <= trade_date,
                                     or_(table_name.REMOVE_DT >= trade_date, table_name.REMOVE_DT.is_(None)))
            if begin_date is not None and end_date is not None:
                query = query.filter(table_name.ENTRY_DT <= end_date,
                                     or_(table_name.REMOVE_DT >= begin_date, table_name.REMOVE_DT.is_(None)))

            df = self.batch_query(query, table_name.S_INFO_WINDCODE, stock_code)
            return df


if __name__ == '__main__':
    import time

    wind_data_reader = WindReader()
    begin = time.time()
    # res = wind_data_reader.get_a_share_eod_prices(['000166.SZ'])
    # res = wind_data_reader.get_composite_benchmark({'000005.SH': 0.4, '000007.SH': 0.6})
    # print(time.time() - begin)
    # print(res)
    # ss = wind_data_reader.get_a_share_income('000001.SZ', columns={'S_INFO_WINDCODE': 'stock_code'})
    res = wind_data_reader.get_bond_analysis_cnbd("092000011.IB")
    print(res)
