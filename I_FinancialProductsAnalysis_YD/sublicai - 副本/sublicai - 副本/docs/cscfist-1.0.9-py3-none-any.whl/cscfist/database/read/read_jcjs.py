# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/1/4 9:39
# @Author  : lisl3
# @File    : jcjs_reader.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from typing import Optional

import numpy as np
import pandas as pd

from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.database.data_field.jcjs.jcjs_field import *
from cscfist.model.db_model.rdb_model.rdb_operator_base import RdbBaseReader
from cscfist.tools import NatureDateUtils


class JCJSReader(RdbBaseReader):
    def __init__(self, jcjs_connection: Optional[RdbConnectionBase] = None, project_name='barra_cne5_all_wind'):
        if jcjs_connection is None:
            from cscfist.database.connection.oracle_con import get_default_jcjs_connection
            jcjs_connection = get_default_jcjs_connection()
        super().__init__(db_connection=jcjs_connection)
        self.project_name = project_name

    def get_risk_free_rate(self, begin_date=None, end_date=None, trade_date=None, columns=None) -> pd.DataFrame:
        """获取无风险收益率"""
        table_name = RiskFreeRate
        query = self.query(table_name, columns)
        query = self.filter_date(query, table_name.trade_date, begin_date, end_date, trade_date)
        df = self.read_sql(query)
        return df

    def get_stock_morning_star(self, code=None, begin_date=None, end_date=None, trade_date=None,
                               columns=None) -> pd.DataFrame:
        """获取股票晨星风格"""
        table_name = StockMorningStar
        query = self.query(table_name, columns)
        query = self.filter_date(query, table_name.trade_dt, begin_date, end_date, trade_date)
        df = self.batch_query(query, table_name.stock_code, code)
        return df

    def get_stock_value_interval(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                 columns=None) -> pd.DataFrame:
        """获取股票财务指标"""
        table_name = StockValueInterval
        query = self.query(table_name, columns)
        query = self.filter_date(query, table_name.time_tag, begin_date, end_date, trade_date)
        df = self.batch_query(query, table_name.stock_code, code)
        return df

    def get_stock_four_factors(self, freq='day', begin_date=None, end_date=None, trade_date=None,
                               columns=None) -> pd.DataFrame:
        """获取A股四因子"""
        table_name = StockFourFactors
        query = self.query(table_name, columns).filter(table_name.freq == freq)
        query = self.filter_date(query, table_name.trade_dt, begin_date, end_date, trade_date)
        df = self.read_sql(query)
        return df

    def _get_barra_style_factor_expose(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                       project_name=None) -> pd.DataFrame:
        """获取barra风格暴露数据"""
        table_name = BarraStyleFactorExpose
        if project_name is None:
            project_name = self.project_name
        query = self.query(table_name).filter(table_name.project_name == project_name)
        query = self.filter_date(query, table_name.trade_dt, begin_date, end_date, trade_date)
        df = self.batch_query(query, table_name.s_info_windcode, code)
        return df

    def _get_barra_industry_factor_expose(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                          project_name=None) -> pd.DataFrame:
        """获取barra行业暴露数据"""
        table_name = BarraIndustryFactorExpose
        if project_name is None:
            project_name = self.project_name
        query = self.query(table_name).filter(table_name.project_name == project_name)
        query = self.filter_date(query, table_name.trade_dt, begin_date, end_date, trade_date)
        df = self.batch_query(query, table_name.s_info_windcode, code)
        return df

    def get_barra_factor_expose(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                project_name=None) -> pd.DataFrame:
        """获取barra因子暴露"""
        # 风格暴露
        df_style = self._get_barra_style_factor_expose(code, begin_date, end_date, trade_date, project_name)
        # 行业暴露
        df_industry = self._get_barra_industry_factor_expose(code, begin_date, end_date, trade_date, project_name)
        df_barra_expose = df_style.merge(df_industry[['s_info_windcode', 'trade_dt', 'industry']],
                                         how='left', on=['s_info_windcode', 'trade_dt'])
        df_barra_expose = df_barra_expose.join(pd.get_dummies(df_barra_expose['industry']))
        return df_barra_expose

    def _get_barra_style_factor_return(self, begin_date=None, end_date=None, trade_date=None,
                                       project_name=None) -> pd.DataFrame:
        """获取barra风格收益数据"""
        table_name = BarraStyleFactorReturn
        if project_name is None:
            project_name = self.project_name
        query = self.query(table_name).filter(table_name.project_name == project_name)
        query = self.filter_date(query, table_name.trade_dt, begin_date, end_date, trade_date)
        df = self.read_sql(query)
        return df

    def _get_barra_industry_factor_return(self, begin_date=None, end_date=None, trade_date=None,
                                          project_name=None) -> pd.DataFrame:
        """获取barra行业收益数据"""
        table_name = BarraIndustryFactorReturn
        if project_name is None:
            project_name = self.project_name
        query = self.query(table_name).filter(table_name.project_name == project_name)
        query = self.filter_date(query, table_name.trade_dt, begin_date, end_date, trade_date)
        df = self.read_sql(query)
        return df

    def get_barra_factor_return(self, begin_date=None, end_date=None, trade_date=None,
                                project_name=None) -> pd.DataFrame:
        """获取barra因子收益"""
        # 风格因子收益
        df_style = self._get_barra_style_factor_return(begin_date, end_date, trade_date, project_name)
        # 行业因子收益
        df_industry = self._get_barra_industry_factor_return(begin_date, end_date, trade_date, project_name)
        df_barra_return = df_style.merge(df_industry.pivot('trade_dt', 'factor_name', 'factor_return'),
                                         how='left', on='trade_dt').sort_values('trade_dt')
        return df_barra_return

    def get_barra_factor_return_rolling(self, begin_date=None, end_date=None, project_name=None,
                                        rolling=22) -> pd.DataFrame:
        """获取barra因子收益: 累积收益，默认为月收益"""
        begin_date_rolling = begin_date if begin_date is None else NatureDateUtils.date_period_change(
            begin_date, f"-{rolling + 20}d")

        # 获取因子收益并计算累积收益率
        factor_return = self.get_barra_factor_return(begin_date_rolling, end_date, project_name=project_name)
        factor_return = factor_return.set_index('trade_dt').drop(['id', 'project_name', 'cal_date'], axis=1)
        factor_return = factor_return.apply(lambda x: x / 100 + 1)
        factor_return = factor_return.rolling(rolling).apply(lambda x: np.prod(x))
        factor_return = factor_return.dropna().apply(lambda x: (x - 1) * 100)
        if begin_date is not None:
            factor_return = factor_return.loc[factor_return.index >= begin_date]
        return factor_return

    def get_barra_stock_unique_return(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                      columns=None, project_name=None) -> pd.DataFrame:
        """获取Barra因子股票特异性收益率"""
        table_name = BarraStockUniqueReturn
        if project_name is None:
            project_name = self.project_name
        query = self.query(table_name, columns).filter(table_name.project_name == project_name)
        query = self.filter_date(query, table_name.trade_dt, begin_date, end_date, trade_date)
        df = self.batch_query(query, table_name.s_info_windcode, code)
        return df

    def get_barra_factor_covariance(self, begin_date=None, end_date=None, trade_date=None,
                                    columns=None, project_name=None) -> pd.DataFrame:
        """获取Barra因子协方差数据"""
        table_name = BarraFactorCovariance
        if project_name is None:
            project_name = self.project_name
        query = self.query(table_name, columns).filter(table_name.project_name == project_name)
        query = self.filter_date(query, table_name.trade_dt, begin_date, end_date, trade_date)
        df = self.batch_query(query)
        return df

    def get_barra_stock_unique_risk(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                    columns=None, project_name=None) -> pd.DataFrame:
        """获取Barra因子股票特异性风险"""
        table_name = BarraStockUniqueRisk
        if project_name is None:
            project_name = self.project_name
        query = self.query(table_name, columns).filter(table_name.project_name == project_name)
        query = self.filter_date(query, table_name.trade_dt, begin_date, end_date, trade_date)
        df = self.batch_query(query, table_name.s_info_windcode, code)
        return df


if __name__ == '__main__':
    jcjs_reader = JCJSReader()
    barra = jcjs_reader.get_barra_factor_return_rolling(begin_date='20200101', end_date='20210101', rolling=5)
