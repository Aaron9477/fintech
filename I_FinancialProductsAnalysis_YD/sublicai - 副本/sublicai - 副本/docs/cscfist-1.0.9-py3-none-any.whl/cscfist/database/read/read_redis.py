# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/2/8 8:56
# @Author  : wangxybjs
# @File    : redis_reader.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
import datetime

from cscfist.database.data_field.redis_field import AShareEodPricesCache, ChinaMutualFundNavCache, \
    ChinaMutualFundCompoundFundBenchmarkCache, ChinaMutualFundNavContinuousCache, ChinaMutualFundBenchmarkEodCache, \
    AllIndexEodPricesCache, CBondIndexEodCNBDCache, ChinaMutualFundNavNetAssetTotalCache, \
    ChinaMutualFundNavFPRTNetAssetCache, CMoneyMarketDailyFIncomeCache, CMMQuarterlyDataCache, \
    ChinaClosedFundEodPriceCache, ChinaMutualFundFloatShareCache, CBondCurveCNBDChinaBondGovYTM10yCache, \
    HKShareEodPricesCache, ChinaMutualFundDescriptionCache, ChinaMFDividendCache, CFundPCHREDMCache, CMFSubRedFeeCache, \
    ChinaMutualFundManagerCache, ChinaMutualFundWindSectorCodeCache, CMFundSplitCache, ChinaMutualFundRelatedCodeCache, \
    ChinaMutualFundParentCodeCache, AShareIndustriesCodeCache, CMFHolderStructureRatioCache
from cscfist.model.db_model.redis_model.redis_operator_base import RedisBaseReader


class RedisReader(RedisBaseReader):
    def __init__(self, redis_session_inst=None):
        if redis_session_inst is None:
            from cscfist.database.connection.redis_con import get_default_redis_session
            redis_session_inst = get_default_redis_session()
        super().__init__(redis_session_inst)

    def get_a_share_eod_prices_cache(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
        table = AShareEodPricesCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.S_INFO_WINDCODE, code)
        query = self.filter_date(query, table.TRADE_DT, begin_date, end_date, trade_date)
        return query.get()

    def get_china_mutual_fund_nav_cache(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
        table = ChinaMutualFundNavCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.F_INFO_WINDCODE, code)
        query = self.filter_date(query, table.PRICE_DATE, begin_date, end_date, trade_date)
        return query.get()

    def get_china_mutual_fund_compound_fund_benchmark_cache(self, code=None, begin_date=None, end_date=None,
                                                            trade_date=None, columns=None):
        table = ChinaMutualFundCompoundFundBenchmarkCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.S_INFO_WINDCODE, code)
        query = self.filter_date(query, table.TRADE_DT, begin_date, end_date, trade_date)
        return query.get()

    def get_china_mutual_fund_nav_continuous_cache(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                                   columns=None):
        table = ChinaMutualFundNavContinuousCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.F_INFO_WINDCODE, code)
        query = self.filter_date(query, table.PRICE_DATE, begin_date, end_date, trade_date)
        return query.get()

    def get_china_mutual_fund_benchmark_eod_cache(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                                  columns=None):
        table = ChinaMutualFundBenchmarkEodCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.S_INFO_WINDCODE, code)
        query = self.filter_date(query, table.TRADE_DT, begin_date, end_date, trade_date)
        return query.get()

    def get_all_index_eod_prices_cache(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
        table = AllIndexEodPricesCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.S_INFO_WINDCODE, code)
        query = self.filter_date(query, table.TRADE_DT, begin_date, end_date, trade_date)
        return query.get()

    def get_c_bond_index_eod_cnbd_cache(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
        table = CBondIndexEodCNBDCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.S_INFO_WINDCODE, code)
        query = self.filter_date(query, table.TRADE_DT, begin_date, end_date, trade_date)
        return query.get()

    def get_china_mutual_fund_nav_net_asset_total_cache(self, code=None, begin_date=None, end_date=None,
                                                        trade_date=None,
                                                        columns=None):
        table = ChinaMutualFundNavNetAssetTotalCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.F_INFO_WINDCODE, code)
        query = self.filter_date(query, table.PRICE_DATE, begin_date, end_date, trade_date)
        return query.get()

    def get_china_mutual_fund_nav_f_prt_net_asset_cache(self, code=None, begin_date=None, end_date=None,
                                                        trade_date=None,
                                                        columns=None):
        table = ChinaMutualFundNavFPRTNetAssetCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.F_INFO_WINDCODE, code)
        query = self.filter_date(query, table.PRICE_DATE, begin_date, end_date, trade_date)
        return query.get()

    def get_c_money_market_daily_f_income_cache(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                                columns=None):
        table = CMoneyMarketDailyFIncomeCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.S_INFO_WINDCODE, code)
        query = self.filter_date(query, table.F_INFO_ENDDATE, begin_date, end_date, trade_date)
        return query.get()

    def get_cmm_quarterly_data_cache(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
        table = CMMQuarterlyDataCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.S_INFO_WINDCODE, code)
        query = self.filter_date(query, table.F_INFO_ENDDATE, begin_date, end_date, trade_date)
        return query.get()

    def get_china_closed_fund_eod_price_cache(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                              columns=None):
        table = ChinaClosedFundEodPriceCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.S_INFO_WINDCODE, code)
        query = self.filter_date(query, table.TRADE_DT, begin_date, end_date, trade_date)
        return query.get()

    def get_china_mutual_fund_float_share_cache(self, code=None, begin_date=None, end_date=None, trade_date=None,
                                                columns=None):
        table = ChinaMutualFundFloatShareCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.S_INFO_WINDCODE, code)
        query = self.filter_date(query, table.TRADE_DT, begin_date, end_date, trade_date)
        return query.get()

    def get_c_bond_curve_cnbd_china_bond_gov_ytm_10y_cache(self, code=None, begin_date=None, end_date=None,
                                                           trade_date=None,
                                                           columns=None):
        table = CBondCurveCNBDChinaBondGovYTM10yCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.B_ANAL_CURVENUMBER, code)
        query = self.filter_date(query, table.TRADE_DT, begin_date, end_date, trade_date)
        return query.get()

    def get_hk_share_eod_prices_cache(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
        table = HKShareEodPricesCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.S_INFO_WINDCODE, code)
        query = self.filter_date(query, table.TRADE_DT, begin_date, end_date, trade_date)
        return query.get()

    def get_china_mutual_fund_description_cache(self, code=None, date=None):
        table = ChinaMutualFundDescriptionCache
        query = self.session.query(table)
        query = self.filter_code(query, table.F_INFO_WINDCODE, code)
        df = query.get()
        if date is None:
            date = datetime.datetime.now().strftime('%Y%m%d')
        if date == 'all':
            return df
        else:
            df = df[(df['F_INFO_SETUPDATE'] <= date) & (
                    (df['F_INFO_MATURITYDATE'] >= date) | (df['F_INFO_MATURITYDATE'].isna()))]
        return df

    def get_china_mf_dividend_cache(self, code=None, columns=None):
        table = ChinaMFDividendCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.S_INFO_WINDCODE, code)
        return query.get()

    def get_c_fund_pch_redm_cache(self, code=None, columns=None):
        table = CFundPCHREDMCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.F_INFO_WINDCODE, code)
        return query.get()

    def get_cmf_subred_fee_cache(self, code=None, columns=None):
        table = CMFSubRedFeeCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.S_INFO_WINDCODE, code)
        return query.get()

    def get_china_mutual_fund_manager_cache(self, code=None, columns=None):
        table = ChinaMutualFundManagerCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.F_INFO_WINDCODE, code)
        return query.get()

    def get_china_mutual_fund_wind_sector_cache(self, code=None, level=2):
        table = ChinaMutualFundWindSectorCodeCache
        query = self.session.query(table)
        query = self.filter_code(query, table.F_INFO_WINDCODE, code)
        df_res = query.get()
        if level == 1:
            # Wind一级分类, 8位代码 + 8个0, 如2001010100000000代表股票型基金
            df_res["S_INFO_SECTOR"] = df_res["S_INFO_SECTOR"].apply(lambda x: x[:8] + '0' * 8)
        elif level == 2:
            # Wind二级分类, 10位代码 + 6个0, 如2001010101000000代表普通股票型基金
            df_res["S_INFO_SECTOR"] = df_res["S_INFO_SECTOR"].apply(lambda x: x[:10] + '0' * 6)
        elif level == 3:
            # Wind三级分类, 12位代码+4个0, 如2001010801010000代表国际(QDII)普通股票型基金
            # 注意只有国际(QDII)基金、FOF基金存在三级分类
            df_res["S_INFO_SECTOR"] = df_res["S_INFO_SECTOR"].apply(lambda x: x[:12] + '0' * 4)

        df_res["S_INFO_SECTOR"] = df_res["S_INFO_SECTOR"].fillna("其他")
        return query.get()

    def get_cmf_holder_structure_ratio_cache(self, code=None, columns=None):
        table = CMFHolderStructureRatioCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.S_INFO_WINDCODE, code)
        return query.get()

    def get_cmf_fund_split_cache(self, code=None, columns=None):
        table = CMFundSplitCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.S_INFO_WINDCODE, code)
        return query.get()

    def get_china_mutual_fund_related_code_cache(self, code=None, columns=None):
        table = ChinaMutualFundRelatedCodeCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.F_INFO_WINDCODE, code)
        return query.get()

    def get_china_mutual_fund_parent_code_cache(self, code=None, columns=None):
        table = ChinaMutualFundParentCodeCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.F_INFO_WINDCODE, code)
        return query.get()

    def get_a_share_industries_code_cache(self, code=None, columns=None):
        table = AShareIndustriesCodeCache
        query = self.session.query(table, columns)
        query = self.filter_code(query, table.INDUSTRIESCODE, code)
        return query.get()


if __name__ == '__main__':
    df_dividend = RedisReader().get_china_mf_dividend_cache("159816.SZ",
                                                            columns=["EQY_RECORD_DT", "ANN_DATE", "CASH_DVD_PER_SH_TAX",
                                                                     "F_EX_DIV_DT", "PAY_DT"])
    import numpy as np

    DEFAULT_DTYPE = np.dtype([
        ('book_closure_date', np.uint64), ('announcement_date', np.uint64), ('dividend_cash_before_tax', np.float),
        ('ex_dividend_date', np.uint64), ('payable_date', np.uint64), ('round_lot', np.uint64)])
    df_dividend["CASH_DVD_PER_SH_TAX"] *= 10
    df_dividend["round_lot"] = 10
    df_dividend = df_dividend[["EQY_RECORD_DT", "ANN_DATE", "CASH_DVD_PER_SH_TAX", "F_EX_DIV_DT", "PAY_DT", "round_lot"]]
    print(np.array([tuple(line) for line in df_dividend.values.tolist()], dtype=DEFAULT_DTYPE))
