# -*- coding: utf-8 -*-
from typing import Optional

from cscfist.database.connection.mysql_con import get_default_qc_connection
from cscfist.database.data_field.quant_contest.quant_contest_field import StrategyPerformance
from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.model.db_model.rdb_model.rdb_operator_base import RdbBaseReader


class QuantContestReader(RdbBaseReader):
    def __init__(self, qc_connection: Optional[RdbConnectionBase] = None):
        """
        Args:
            qc_connection: 数据库连接。如果为None则使用默认配置连接
        """
        if qc_connection is None:
            qc_connection = get_default_qc_connection()
        super().__init__(db_connection=qc_connection)

    def get_strategy_performance(self, contest_id=None, user_id=None):
        table_name = StrategyPerformance
        query = self.query(table_name)
        if contest_id is not None:
            query = query.filter(table_name.contest_id == contest_id)
        if user_id is not None:
            query = query.filter(table_name.user_id == user_id)

        df = self.read_sql(query)
        return df
