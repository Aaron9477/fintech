# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/9/27 15:29
# @Author  : wangxybjs
# @File    : read_ddb.py
# @Project : fund_analysis_jjpg
# @Function:
# @Version : V0.0.1
# ------------------------------
import pandas as pd

from cscfist.database.connection.ddb_con import get_ddb_session


def transfer_date(date: str):
    return f"{date[:4]}.{date[4:6]}.{date[6:8]}"


class DDBReader(object):
    @classmethod
    def batch_query(cls, s, sql, code_column, code, batch_size=100):
        if code is None:
            df = s.run(sql)
        elif isinstance(code, str):
            sql += f" and {code_column}=`{code}"
            df = s.run(sql)
        else:
            df = []
            for i in range(0, len(code), batch_size):
                batch = code[i:i + batch_size]
                sql1 = sql + f" and {code_column} in ({str(batch)[1:-1]})"
                df_single = s.run(sql1)
                df.append(df_single)
            if len(df) == 0:
                return
            df = pd.concat(df)
        return df

    @classmethod
    def filter_date(cls, sql, date_column, begin_date=None, end_date=None, trade_date=None):
        if begin_date is not None:
            begin_date = transfer_date(begin_date)
            sql += f" and {date_column} >= {begin_date} "
        if end_date is not None:
            end_date = transfer_date(end_date)
            sql += f" and {date_column} <= {end_date} "
        if trade_date is not None:
            trade_date = transfer_date(trade_date)
            sql += f" and {date_column} = {trade_date} "
        return sql

    @classmethod
    def get_a_share_eod_derivative_indicator(cls, stock_code=None, begin_date=None, end_date=None, trade_date=None,
                                             s=None):
        if s is None:
            s = get_ddb_session()
        sql = f"""db=database("dfs://wind/ashareeodderivativeindicator")
    pt=loadTable(db,'ashareeodderivativeindicator')
    select * from pt where 1=1 """
        sql = cls.filter_date(sql, "TRADE_DT", begin_date, end_date, trade_date)
        df = cls.batch_query(s, sql, "S_INFO_WINDCODE", stock_code)
        df["TRADE_DT"] = df["TRADE_DT"].apply(lambda x: x.strftime("%Y%m%d"))
        return df

    @classmethod
    def get_a_share_eod_prices(cls, stock_code=None, begin_date=None, end_date=None, trade_date=None, s=None):
        if s is None:
            s = get_ddb_session()
        sql = f"""db=database("dfs://wind/ashareeodprices")
        pt=loadTable(db,'ashareeodprices')
        select * from pt where 1=1 """
        sql = cls.filter_date(sql, "TRADE_DT", begin_date, end_date, trade_date)
        df = cls.batch_query(s, sql, "S_INFO_WINDCODE", stock_code)
        df["TRADE_DT"] = df["TRADE_DT"].apply(lambda x: x.strftime("%Y%m%d"))
        return df

    @classmethod
    def get_distinct_date_a_share_eod_prices(cls, s=None):
        if s is None:
            s = get_ddb_session()
        sql = f"""db=database("dfs://wind/ashareeodprices")
        pt=loadTable(db,'ashareeodprices')
        select distinct TRADE_DT from pt"""
        df = s.run(sql)
        return [x.strftime("%Y%m%d") for x in df.iloc[:, 0].tolist()]

    @classmethod
    def get_distinct_date_a_share_eod_derivative_indicator(cls, s=None):
        if s is None:
            s = get_ddb_session()
        sql = f"""db=database("dfs://wind/ashareeodderivativeindicator")
            pt=loadTable(db,'ashareeodderivativeindicator')
            select distinct TRADE_DT from pt"""
        df = s.run(sql)
        return [x.strftime("%Y%m%d") for x in df.iloc[:, 0].tolist()]


if __name__ == '__main__':
    from cscfist.database.get_instance.wind_inst import wind_reader
    import time

    begin = time.time()
    df1 = wind_reader.get_a_share_eod_derivative_indicator(trade_date="20230828")
    print(time.time() - begin)

    begin = time.time()
    df2 = DDBReader.get_a_share_eod_derivative_indicator(trade_date="20230828")
    print(time.time() - begin)

    print(len(df1), len(df2))
