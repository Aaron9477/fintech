from typing import Union, List, Dict, Optional

import pandas as pd

from cscfist.database.connection.mysql_con import get_default_qc_connection
from cscfist.database.data_field.quant_contest.quant_contest_field import StrategyPerformance, ProfitHis
from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.model.db_model.rdb_model.rdb_operator_base import RdbBaseSaver, RdbBaseReader


class QuantContestReader(RdbBaseReader):
    def __init__(self, db_connection: Optional[RdbConnectionBase] = None):
        """
        Args:
            db_connection: 数据库连接。如果为None则使用默认配置连接
        """
        if db_connection is None:
            db_connection = get_default_qc_connection()
        super().__init__(db_connection=db_connection)

    def get_strategy_performance(self, contest_id, user_id):
        table = StrategyPerformance
        query = self.query(table).filter(table.contest_id == contest_id, table.user_id == user_id)
        return self.read_sql(query)

    def get_profit_his(self, contest_id, user_id):
        table = ProfitHis
        query = self.query(table).filter(table.contest_id == contest_id, table.user_id == user_id)
        return self.read_sql(query)
