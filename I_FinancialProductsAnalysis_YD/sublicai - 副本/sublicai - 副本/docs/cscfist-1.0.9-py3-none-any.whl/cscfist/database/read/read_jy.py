# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/8/31 13:45
# @Author  : wangxybjs
# @File    : read_jy.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from typing import Optional

from cscfist.database.data_field.jy_field import *
from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.model.db_model.rdb_model.rdb_operator_base import RdbBaseReader
from cscfist.tools.date_util import DateFormatTransfer


class JyReader(RdbBaseReader):
    def __init__(self, jy_connection: Optional[RdbConnectionBase] = None):
        """
        Args:
            jy_connection: 数据库连接。如果为None则使用默认配置连接
        """
        if jy_connection is None:
            from cscfist.database.connection.sql_server_con import get_default_jy_connection
            jy_connection = get_default_jy_connection()
        super().__init__(db_connection=jy_connection)

    def get_secu_main_inner_code(self, secu_code):
        """获取证券主表InnerCode"""
        table_name = SECUMAIN
        query = self.query(table_name).filter(table_name.SecuCode == secu_code).filter(
            table_name.SecuCategory.in_([8, 13]))
        df = self.read_sql(query)
        if len(df) > 0:
            return df["InnerCode"].tolist()[0]

    def get_mf_invest_industry(self, secu_code=None, begin_date=None, end_date=None, report_period=None,
                               inner_code=None):
        """获取公募基金行业投资MF_INVESTINDUSTRY"""
        table_name = MF_INVESTINDUSTRY
        if secu_code is not None:
            inner_code = self.get_secu_main_inner_code(secu_code)
        begin_date = DateFormatTransfer.str2date(begin_date)
        end_date = DateFormatTransfer.str2date(end_date)
        report_period = DateFormatTransfer.str2date(report_period)
        query = self.query(table_name)
        query = self.filter_date(query, table_name.ReportDate, begin_date, end_date, report_period, date_type=Date)
        df = self.batch_query(query, table_name.InnerCode, inner_code)
        df['ReportDate'] = df['ReportDate'].apply(DateFormatTransfer.date2str)
        return df

    def get_ct_system_const(self, lb):
        """获取系统常量表CT_SystemConst"""
        table_name = CT_SystemConst
        query = self.query(table_name).filter(table_name.LB == lb)
        df = self.query(query)
        return df

    def get_qt_index_quote(self, code=None, begin_date=None, end_date=None, trade_date=None, columns=None):
        """指数行情"""
        table_name = QT_IndexQuote
        query = self.query(table_name, columns)
        # 筛选条件
        query = self.filter_date(query, table_name.TradingDay, begin_date, end_date, trade_date)
        # 查询数据
        df = self.batch_query(query, table_name.InnerCode, code)
        return df

    def get_lc_shsc_trade_stat(self, report_period: Optional[int] = None, trading_type: Optional[int] = None,
                               begin_date=None, end_date=None, trade_date=None, columns=None):
        """
        沪港通交易统计

        Args:
            report_period: 27-年, 28-月, 29-日
            trading_type: 1-沪股通, 2-港股通(沪)
            begin_date:开始日期
            end_date:结束日期
            trade_date:等于某个日期
            columns:列名
        """
        table_name = LC_SHSCTradeStat
        query = self.query(table_name, columns)
        if report_period is not None:
            query = query.filter(table_name.ReportPeriod == report_period)
        if trading_type is not None:
            query = query.filter(table_name.TradingType == trading_type)
        # 筛选条件
        query = self.filter_date(query, table_name.EndDate, begin_date, end_date, trade_date)
        # 查询数据
        df = self.read_sql(query)
        return df

    def get_lc_zhsc_trade_stat(self, report_period: Optional[int] = None, trading_type: Optional[int] = None,
                               begin_date=None, end_date=None, trade_date=None, columns=None):
        """
        深港通交易统计

        Args:
            report_period: 27-年, 28-月, 29-日
            trading_type: 3-深股通, 4-港股通（深）
            begin_date:开始日期
            end_date:结束日期
            trade_date:等于某个日期
            columns:列名
        """
        table_name = LC_ZHSCTradeStat
        query = self.query(table_name, columns)
        if report_period is not None:
            query = query.filter(table_name.ReportPeriod == report_period)
        if trading_type is not None:
            query = query.filter(table_name.TradingType == trading_type)
        # 筛选条件
        query = self.filter_date(query, table_name.EndDate, begin_date, end_date, trade_date)
        # 查询数据
        df = self.read_sql(query)
        return df

    def get_ct_industry_type(self, standard: Optional[int] = None, classification: Optional[int] = None,
                             if_effected: Optional[int] = None, columns=None):
        """
        行业类别表

        Args:
            standard: 行业分类标准
            classification: 行业级别
            if_effected: 是否有效
            columns: 列名
        """
        table_name = CT_IndustryType
        query = self.query(table_name, columns)
        if standard is not None:
            query = query.filter(table_name.Standard == standard)
        if classification is not None:
            query = query.filter(table_name.Classification == classification)
        if if_effected is not None:
            query = query.filter(table_name.IfEffected == if_effected)
        df = self.read_sql(query)
        return df

    def get_lc_corr_index_industry(self, index_code=None, industry_standard=None, columns=None):
        """指数与行业对应"""
        table_name = LC_CorrIndexIndustry
        query = self.query(table_name, columns)
        if industry_standard is not None:
            query = query.filter(table_name.IndustryStandard == industry_standard)
        df = self.batch_query(query, table_name.IndustryCode, index_code)
        return df

    def get_mf_income_statement_new(self, secu_code=None, begin_date=None, end_date=None, report_period=None,
                                    inner_code=None):
        if secu_code is not None:
            inner_code = self.get_secu_main_inner_code(secu_code)
            if inner_code is None:
                return
        table_name = MF_IncomeStatementNew
        report_period = DateFormatTransfer.str2date(report_period)
        query = self.query(table_name)
        query = self.filter_date(query, table_name.EndDate, begin_date, end_date, report_period, date_type=Date)
        df = self.batch_query(query, table_name.InnerCode, inner_code)
        df['EndDate'] = df['EndDate'].apply(DateFormatTransfer.date2str)
        return df

    def get_funds_reference(self, secu_code=None, begin_date=None, end_date=None, report_period=None,
                            inner_code=None):
        if secu_code is not None:
            inner_code = self.get_secu_main_inner_code(secu_code)
            if inner_code is None:
                return
        table_name = MF_FundsReference
        report_period = DateFormatTransfer.str2date(report_period)
        query = self.query(table_name)
        query = self.filter_date(query, table_name.EndDate, begin_date, end_date, report_period, date_type=Date)
        df = self.batch_query(query, table_name.InnerCode, inner_code)
        df['EndDate'] = df['EndDate'].apply(DateFormatTransfer.date2str)
        return df

    def get_mf_nv_change(self, secu_code=None, begin_date=None, end_date=None, report_period=None,
                         inner_code=None):
        """获取公募基金净值变动表"""
        table_name = MF_NVChange
        if secu_code is not None:
            inner_code = self.get_secu_main_inner_code(secu_code)
        begin_date = DateFormatTransfer.str2date(begin_date)
        end_date = DateFormatTransfer.str2date(end_date)
        report_period = DateFormatTransfer.str2date(report_period)
        query = self.query(table_name)
        query = self.filter_date(query, table_name.ReportDate, begin_date, end_date, report_period, date_type=Date)
        df = self.batch_query(query, table_name.InnerCode, inner_code)
        df['ReportDate'] = df['ReportDate'].apply(DateFormatTransfer.date2str)
        return df


if __name__ == '__main__':
    j = JyReader()
    d = j.get_mf_invest_industry('005827', report_period='20211231')
    d = d[d["InduStandard"] == 6]
    # 将聚源的行业代码映射到东财
    gics_dfcf_jy_map = {10: "401001", 15: "402002", 20: "402003", 25: "402004", 30: "402005", 35: "402006",
                        40: "402007", 45: "402008", 50: "402009", 55: "402010", 60: "402011"}
    print(d)
