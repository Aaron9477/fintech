# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/11/23 13:34
# @Author  : wangxybjs
# @File    : dfcf_reader.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
import datetime
from typing import Optional, List, Union, Dict

import pandas as pd
from sqlalchemy import or_, distinct

from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.database.data_field.dfcf_field import *
from cscfist.model.db_model.rdb_model.rdb_operator_base import RdbBaseReader
from cscfist.tools import DateFormatTransfer


class DFCFReader(RdbBaseReader):
    def __init__(self, dfcf_connection: Optional[RdbConnectionBase] = None):
        """
        Args:
            dfcf_connection: 数据库连接。如果为None则使用默认配置连接
        """
        if dfcf_connection is None:
            from cscfist.database.connection.oracle_con import get_default_dfcf_connection
            dfcf_connection = get_default_dfcf_connection()
        super().__init__(db_connection=dfcf_connection)

    def _get_fund_adj_nav(self, code=None, begin_date: Optional[datetime.date] = None,
                          end_date: Optional[datetime.date] = None,
                          trade_date: Optional[datetime.date] = None) -> pd.DataFrame:
        """
        查询基金行情原始表
        """
        table_name = FUNDDRFUNDNV
        query = self.session.query(table_name).filter(table_name.EISDEL == 0).filter(
            or_(table_name.IS_PREDICT != 1, table_name.IS_PREDICT.is_(None)))

        query = self.filter_date(query, table_name.ENDDATE, begin_date, end_date, trade_date)

        df_res = self.batch_query(query, table_name.SECURITYCODE, code, batch_size=100)
        df_res.sort_values(by=['SECURITYCODE', 'ENDDATE'], inplace=True)
        return df_res

    def get_fund_adj_nav(self, code=None, begin_date=None, end_date=None, trade_date=None) -> pd.DataFrame:
        """
        查询基金行情封装后
        """
        begin_date = DateFormatTransfer.str2date(begin_date)
        end_date = DateFormatTransfer.str2date(end_date)
        trade_date = DateFormatTransfer.str2date(trade_date)
        df_res = self._get_fund_adj_nav(code, begin_date, end_date, trade_date)
        df_res['ENDDATE'] = df_res['ENDDATE'].apply(DateFormatTransfer.date2str)
        trade_date_list = self.get_trade_date_list()['TRADEDATE'].tolist()
        df_res = df_res[df_res['ENDDATE'].isin(trade_date_list)]
        return df_res

    def _get_distinct_fund_nav_date(self, code: str, begin_date: Optional[str] = None,
                                    end_date: Optional[str] = None,
                                    trade_date: Optional[str] = None) -> List[str]:
        """
        查询净值distinct的日期

        Args:
            code: 基金代码
            begin_date: 开始日期
            end_date: 结束日期
            trade_date: 交易日期

        Returns:
            code_list: 根据日期筛选出的Distinct日期
        """
        table_name = FUNDDRFUNDNV
        query = self.session.query(distinct(table_name.ENDDATE)).filter(table_name.EISDEL == 0).filter(
            or_(table_name.IS_PREDICT != 1, table_name.IS_PREDICT.is_(None)))
        query = query.filter(table_name.SECURITYCODE == code)
        # 筛选条件
        begin_date = DateFormatTransfer.str2date(begin_date)
        end_date = DateFormatTransfer.str2date(end_date)
        trade_date = DateFormatTransfer.str2date(trade_date)
        query = self.filter_date(query, table_name.ENDDATE, begin_date, end_date, trade_date)
        df = self.read_sql(query)
        df['ENDDATE'] = df['ENDDATE'].apply(DateFormatTransfer.date2str)
        code_list = df.iloc[:, 0].tolist()
        code_list.sort()
        return code_list

    def get_distinct_fund_nav_date(self, code: Union[str, List[str]], begin_date: Optional[str] = None,
                                   end_date: Optional[str] = None,
                                   trade_date: Optional[str] = None) -> Union[Dict, List[str]]:
        """
        查询净值distinct的日期

        Args:
            code: 基金代码
            begin_date: 开始日期
            end_date: 结束日期
            trade_date: 交易日期

        Returns:
            code_list: 根据日期筛选出的Distinct日期
        """
        if isinstance(code, str):
            date_list = self._get_distinct_fund_nav_date(code, begin_date, end_date, trade_date)
            return date_list
        if isinstance(code, list):
            res_dict = {}
            for c in code:
                res_dict[c] = self._get_distinct_fund_nav_date(c, begin_date, end_date, trade_date)
            return res_dict

    def get_existing_of_code(self, date=None) -> list:
        """
        获取存续的开放式基金列表

        Args:
            date: 日期, 如果传入None, 则为获取最新基金列表

        Returns:
            存续的基金列表
        """
        table_name = FUNDBSOFINFO
        query = self.session.query(table_name.SECURITYCODE).filter(table_name.EISDEL == 0)
        date = DateFormatTransfer.date2str(date)
        if date is None:
            date = datetime.datetime.now().strftime('%Y%m%d')
        query = query.filter(table_name.FOUNDDATE <= date).filter(
            or_(table_name.ENDDATE >= date,
                table_name.ENDDATE.is_(None)))
        existing_fund_list = pd.read_sql(query.statement, self.engine)["SECURITYCODE"].unique().tolist()
        return existing_fund_list

    def get_expire_of_date(self):
        """
        获取已经终止的开放式基金列表
        """
        table_name = FUNDBSOFINFO
        query = self.session.query(table_name.SECURITYCODE, table_name.ENDDATE).filter(table_name.EISDEL == 0)
        query = query.filter(table_name.ENDDATE.isnot(None))
        df = pd.read_sql(query.statement, self.engine)
        return df

    def get_expire_close_fund(self):
        """
        获取已经终止的封闭式基金列表
        """
        table_name = FUNDBSCBINFO
        query = self.session.query(table_name.SECURITYCODE, table_name.ENDDATE).filter(table_name.EISDEL == 0)
        query = query.filter(table_name.ENDDATE.isnot(None))
        df = pd.read_sql(query.statement, self.engine)
        return df

    def get_expire_fund(self):
        """
        获取所有已经终止的基金
        """
        df_of = self.get_expire_of_date()
        df_close = self.get_expire_close_fund()
        df = df_of.append(df_close)
        return df

    def get_existing_close_fund_code(self, date=None) -> list:
        """
        获取存续的封闭式基金列表
        注意目前老封基已全部退出

        Args:
            date: 日期, 如果传入None, 则为获取最新基金列表

        Returns:
            存续的基金列表
        """
        table_name = FUNDBSCBINFO
        query = self.session.query(table_name.SECURITYCODE).filter(table_name.EISDEL == 0)
        date = DateFormatTransfer.date2str(date)
        if date is None:
            date = datetime.datetime.now().strftime('%Y%m%d')
        query = query.filter(table_name.FOUNDDATE <= date).filter(
            or_(table_name.ENDDATE >= date,
                table_name.ENDDATE.is_(None)))
        existing_fund_list = pd.read_sql(query.statement, self.engine)["SECURITYCODE"].unique().tolist()
        return existing_fund_list

    def get_existing_fund_code(self, date=None) -> list:
        """
        获取日期存续的基金列表

        Args:
            date: 日期, 如果传入None, 则为获取最新基金列表
        """
        list1 = self.get_existing_of_code(date)
        list2 = self.get_existing_close_fund_code(date)
        res = list(set(list1 + list2))
        return res

    def get_trade_date_list(self):
        table_name = TRADTDTDATE
        query = self.session.query(table_name).filter(
            table_name.TRADEMARKETCODE == '069001002').order_by(table_name.TRADEDATE).filter(table_name.EISDEL == 0)
        # 查询数据
        df = self.read_sql(query)
        return df

    def get_fund_manager_change(self, code=None, manager_id=None):
        """
        获取基金经理变更
        """
        table_name = FUNDBSFEXECUTIVE
        query = self.session.query(table_name).filter(table_name.EISDEL == 0)
        # 筛选条件
        if code is not None:
            if isinstance(code, str):
                query = query.filter(table_name.SECURITYCODE == code)
            elif isinstance(code, list):
                query = query.filter(table_name.SECURITYCODE.in_(code))
        if manager_id is not None:
            if isinstance(manager_id, str):
                query = query.filter(table_name.PERSONCODE == manager_id)
            elif isinstance(manager_id, list):
                query = query.filter(table_name.PERSONCODE.in_(manager_id))
        # 查询数据
        df = self.read_sql(query)

        # 由于东财表中退市基金的ENDDATE为空, 所以还需要特殊处理
        df_end_fund = self.get_expire_fund()
        end_date_dict = df_end_fund.set_index('SECURITYCODE')['ENDDATE'].to_dict()
        df['ENDDATE'] = df['ENDDATE'].fillna(df['SECURITYCODE'].map(end_date_dict))
        df['CHANGEDATE'] = df['CHANGEDATE'].apply(DateFormatTransfer.date2str)
        df['ENDDATE'] = df['ENDDATE'].apply(DateFormatTransfer.date2str)
        return df

    def get_fund_type_code_name_dict(self):
        """
        获取基金类型代码与基金类型名称码表
        """
        table_name = CFPPVALUE
        query = self.session.query(table_name).filter(table_name.EISDEL == 0).filter(
            table_name.NIPMID == 138000000412793992).filter(table_name.PARAMCODE.like('102%'))
        df = self.read_sql(query)
        res = df.set_index('PARAMCODE')['PARAMCHNAME'].to_dict()
        return res

    def get_fund_type_name_code_dict(self):
        """
        获取基金类型代码与基金类型名称码表
        """
        code_name_dict = self.get_fund_type_code_name_dict()
        name_code_dict = {v: k for k, v in code_name_dict.items()}
        return name_code_dict

    def get_fund_type_code(self, fund_code) -> pd.DataFrame:
        table_name = FUNDBSATYPE
        query = self.session.query(table_name).filter(table_name.EISDEL == 0).filter(
            table_name.TYPEMETHOD == 102)  # 按照投资对象
        df_res = self.batch_query(query, table_name.SECURITYCODE, fund_code, batch_size=100)
        df_res['CHANGEDATE'] = df_res['CHANGEDATE'].apply(DateFormatTransfer.date2str)
        df_res['ENDDATE'] = df_res['ENDDATE'].apply(DateFormatTransfer.date2str)
        return df_res

    def get_existing_manager_list(self, date=None):
        """
        获取当前管理存续基金的基金经理
        """
        table_name = FUNDBSFEXECUTIVE
        query = self.session.query(table_name.PERSONCODE).filter(table_name.EISDEL == 0)
        date = DateFormatTransfer.str2date(date)
        if date is None:
            date = datetime.datetime.now()
        query = query.filter(table_name.CHANGEDATE <= date).filter(
            or_(table_name.ENDDATE >= date,
                table_name.ENDDATE.is_(None)))
        existing_manager_list = pd.read_sql(query.statement, self.engine)["PERSONCODE"].unique().tolist()
        return existing_manager_list

    def get_fund_total_asset(self, code, begin_date=None, end_date=None, trade_date=None):
        table_name = FUNDNVNAV
        query = self.session.query(table_name.SECURITYCODE, table_name.ENDDATE, table_name.NAV, table_name.ISSTAT,
                                   table_name.ISSUM).filter(
            table_name.EISDEL == 0).filter(table_name.ISSTAT == 1)
        # 筛选条件
        begin_date = DateFormatTransfer.str2date(begin_date)
        end_date = DateFormatTransfer.str2date(end_date)
        trade_date = DateFormatTransfer.str2date(trade_date)
        query = self.filter_date(query, table_name.ENDDATE, begin_date, end_date, trade_date)
        df_res = self.batch_query(query, table_name.SECURITYCODE, code, batch_size=100)
        df_res['ENDDATE'] = df_res['ENDDATE'].apply(DateFormatTransfer.date2str)
        return df_res

    def get_lico_im_inchg(self, ind_type="001", company_code=None, trade_date=None):
        """
        读取行业分类变动
        """
        table_name = LICOIMINCHG
        query = self.query(table_name).filter(table_name.INDTYPE == ind_type)
        df = self.batch_query(query, table_name.COMPANYCODE, company_code, batch_size=100)
        df['CHANGEDATE'] = df['CHANGEDATE'].apply(DateFormatTransfer.date2str)
        df_res = pd.DataFrame()
        if trade_date is not None:
            for company_code, grouped in df.groupby("COMPANYCODE"):
                grouped = grouped.sort_values(by="CHANGEDATE")
                date_list = grouped["CHANGEDATE"].values
                idx = date_list.searchsorted(trade_date, "right") - 1
                if idx != -1:
                    df_res = df_res.append(grouped.iloc[[idx]])
        return df_res

    def get_cdsy_secucode(self, security_code='00700', trade_date=None):
        """
        读取证券代码表
        """
        table_name = CDSYSECUCODE
        query = self.query(table_name)
        if trade_date is not None:
            trade_date = DateFormatTransfer.str2date(trade_date)
            query = query.filter(trade_date >= table_name.LISTDATE).filter(
                or_(trade_date <= table_name.ENDDATE, table_name.ENDDATE.is_(None)))
        df = self.batch_query(query, table_name.SECURITYCODE, security_code, batch_size=100)
        return df

    def get_cdsy_kp_publish_relation(self, original_code=None, publish_code=None, category_code=4):
        """
        读取板块关系对照新表
        """
        table_name = CDSYKPPUBLISHRELATION
        query = self.query(table_name)
        if category_code is not None:
            query = query.filter(table_name.CATEGORYCODE == category_code)
        if original_code is not None:
            df = self.batch_query(query, table_name.ORIGINALCODE, original_code, batch_size=100)
        else:
            df = self.batch_query(query, table_name.PUBLISHCODE, publish_code, batch_size=100)
        return df

    def get_hk_stock_pub_ind_by_security_code(self, security_code, trade_date, level=1):
        """通过证券代码查询行业, 注意某些company对应2个股票代码, 如06196"""
        if isinstance(security_code, str):
            security_code = [security_code]
        df_ind = pd.DataFrame({"security_code": security_code})

        df_company_code = self.get_cdsy_secucode(security_code, trade_date)
        company_secu_code_map = df_company_code.set_index("SECURITYCODE")["COMPANYCODE"].to_dict()
        company_code_list = df_company_code["COMPANYCODE"].tolist()
        df_company_ind = self.get_lico_im_inchg(company_code=company_code_list, trade_date=trade_date)
        company_ind_map = df_company_ind.set_index("COMPANYCODE")["INDCODE"]
        df_ind["company_code"] = df_ind["security_code"].map(company_secu_code_map)
        df_ind["INDCODE"] = df_ind["company_code"].map(company_ind_map)
        df_ind.dropna(inplace=True)
        df_pub_ind = self.get_cdsy_kp_publish_relation(original_code=df_ind["INDCODE"].unique().tolist())
        pub_original_code_map = df_pub_ind.set_index("ORIGINALCODE")["PUBLISHCODE"].to_dict()
        df_ind["ind_code"] = df_ind["INDCODE"].map(pub_original_code_map)
        df_ind.dropna(subset=["ind_code"], inplace=True)
        if level == 1:
            df_ind["ind_code"] = df_ind["ind_code"].apply(lambda x: x[:6] if not x.startswith("402012") else '402009')
        return df_ind

    def get_fund_bs_info_change(self, fund_code, begin_date=None):
        table_name = FUNDBSINFOCHANGE
        query = self.query(table_name)
        begin_date = DateFormatTransfer.str2date(begin_date)
        if begin_date is not None:
            query = self.filter_date(query, table_name.CHANGEDATE, begin_date, None, None)
        df = self.batch_query(query, table_name.SECURITYCODE, fund_code, batch_size=100)

        return df

    def get_fund_info_change_code_name_dict(self):
        """
        获取基金基本信息变动表的代码和中文变动字典
        """
        table_name = CFPPVALUE
        query = self.session.query(table_name).filter(table_name.EISDEL == 0).filter(
            table_name.NIPMID == 127000000842318503)
        df = self.read_sql(query)
        res = df.set_index('PARAMCODE')['PARAMCHNAME'].to_dict()
        return res


if __name__ == '__main__':
    # 腾讯控股的GICS分类
    d = DFCFReader()
    # df_code = d.get_cdsy_secucode('00700')
    # company_code = df_code["COMPANYCODE"].tolist()[0]  # 获取company_code
    # res = DFCFReader().get_lico_im_inchg(company_code=company_code, trade_date="20210331")  # 通过company_code获取GICS分类
    # ind_code = res["INDCODE"].tolist()[0]  # 一级分类
    # publish_code = d.get_cdsy_kp_publish_relation(original_code=ind_code)["PUBLISHCODE"].tolist()[0]
    # print(publish_code[:6])  # 一级代码
    """
    402001:能源:10
    402002:原材料:15
    402003:工业:20
    402004:非日常生活消费品:25
    402005:日常消费品:30
    402006:医疗保健:35
    402007:金融:40
    402008:信息技术:45
    402009:通讯服务:50
    402010:公用事业:55
    402011:房地产:60
    402012:通讯服务:50(已弃用)
    """
    res = d.get_hk_stock_pub_ind_by_security_code(["00700", "03968"], "20210331")
    print(res)
