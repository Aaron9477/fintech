# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/11/23 13:36
# @Author  : wangxybjs
# @File    : market_reader.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
import warnings
from typing import Optional

import numpy as np
import pandas as pd
from sqlalchemy import or_

from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.database.data_field.dfcf_field import FUNDDRFUNDNV
from cscfist.database.read.read_dfcf import DFCFReader
from cscfist.database.read.read_wind import WindReader
from cscfist.tools import TradeDateUtils, DateFormatTransfer
from cscfist.tools.product_code_transfer import transfer_fund_code_wind2dfcf


class MarketReader:
    def __init__(self, wind_connection: Optional[RdbConnectionBase] = None,
                 dfcf_connection: Optional[RdbConnectionBase] = None):
        """
        Args:
            wind_connection: 数据库连接。如果为None则使用默认配置连接
        """
        self.wind_reader = WindReader(wind_connection)
        self.dfcf_reader = DFCFReader(dfcf_connection)

    def get_compound_fund_benchmark(self, code, begin_date=None, end_date=None, trade_date=None):
        if isinstance(code, str):
            code = [code]
        df_res = pd.DataFrame()
        trade_date_list_all = self.wind_reader.get_a_share_calendar()['TRADE_DAYS'].values
        traded_date_utils = TradeDateUtils(trade_date_list_all)
        for c in code:
            # 1. 获取基金自身净值
            code_dfcf = transfer_fund_code_wind2dfcf(c)
            fund_nav_date = self.dfcf_reader.get_distinct_fund_nav_date(code_dfcf)
            benchmark_begin_date = min(fund_nav_date)
            benchmark_end_date = max(fund_nav_date)
            if begin_date is not None:
                benchmark_begin_date = max(benchmark_begin_date, begin_date)
            if end_date is not None:
                benchmark_end_date = min(benchmark_end_date, end_date)
            # 交易日列表
            trade_date_list = traded_date_utils.get_trade_date_list(benchmark_begin_date, benchmark_end_date)
            # 获取基金自身基准
            benchmark_pct_chg = pd.Series()
            index_pct_chg = pd.Series()
            benchmark_df = self.wind_reader.get_china_mutual_fund_benchmark_eod(c, benchmark_begin_date,
                                                                                benchmark_end_date,
                                                                                trade_date)
            benchmark_series = benchmark_df.set_index(['TRADE_DT'])['S_DQ_CLOSE']
            benchmark_date_list = []
            if len(benchmark_series) > 0:
                benchmark_date_list = benchmark_series.index.tolist()

            if set(trade_date_list) <= set(benchmark_date_list):
                benchmark_pct_chg = benchmark_series.pct_change().dropna()
            else:
                # 根据类型获取市场基准， 取市场基准大于自身净值最小日期的部分
                fund_sector = self.wind_reader.get_fund_wind_sector_name(c)
                stock_fund_type = ['普通股票型基金', '被动指数型基金', '增强指数型基金', '偏股混合型基金', '平衡混合型基金',
                                   '灵活配置型基金', '国际(QDII)股票型基金', '国际(QDII)混合型基金']
                # 市场基准
                if fund_sector in stock_fund_type:
                    index_close_df = self.wind_reader.get_a_index_eod_prices("000300.SH", benchmark_begin_date,
                                                                             benchmark_end_date,
                                                                             trade_date)
                else:
                    index_close_df = self.wind_reader.get_cb_index_eod_prices("h11001.CSI", benchmark_begin_date,
                                                                              benchmark_end_date,
                                                                              trade_date)
                index_close_series = index_close_df.set_index(['TRADE_DT'])['S_DQ_CLOSE']
                index_pct_chg = index_close_series.pct_change().dropna()

            # 4. 市场基准与自身基准分别求收益率，二者做连接，以自身基准为准
            diff_pct_change = index_pct_chg.reindex(index_pct_chg.index.difference(benchmark_pct_chg.index))
            final_pct_change = pd.concat([diff_pct_change, benchmark_pct_chg], axis=0)
            final_pct_change = final_pct_change.reindex(trade_date_list).fillna(0)
            # 5. 收益率还原为指数，初始值为1
            final_nav = (final_pct_change + 1).cumprod()
            df = pd.DataFrame({"TRADE_DT": final_nav.index, "S_DQ_CLOSE": final_nav.values})
            df["S_INFO_WINDCODE"] = c
            if begin_date is not None:
                df = df[df['TRADE_DT'] >= begin_date]
            if end_date is not None:
                df = df[df['TRADE_DT'] <= end_date]
            if trade_date is not None:
                df = df[df['TRADE_DT'] == trade_date]
            df_res = df_res.append(df)
        return df_res

    def get_fund_adj_nav_continuous(self, code=None, begin_date=None, end_date=None, trade_date=None) -> pd.DataFrame:
        """
        查询基金行情, 对于中间缺失按交易日向下填充
        """

        def _fill_nav(df: pd.DataFrame, trade_date_list):
            df = df.set_index("ENDDATE").reindex(trade_date_list).fillna(method='pad').reset_index(drop=False)
            return df

        table_name = FUNDDRFUNDNV

        trade_date_list_all = self.wind_reader.get_a_index_eod_prices('000001.SH')['TRADE_DT'].values
        if isinstance(code, str):
            code = [code]
        df_res = pd.DataFrame()
        for c in code:
            query = self.dfcf_reader.session.query(table_name).filter(table_name.EISDEL == 0).filter(
                or_(table_name.IS_PREDICT != 1, table_name.IS_PREDICT.is_(None)))
            trade_date_list = trade_date_list_all
            date_list = np.array(self.dfcf_reader.get_distinct_fund_nav_date(c))
            # 取该基金最小净值以后的交易日
            if len(date_list) == 0:
                continue
            trade_date_list = trade_date_list[trade_date_list >= date_list[0]]
            if begin_date is not None:
                begin_date_pre_nav_date = TradeDateUtils(date_list).get_previous_trading_date(begin_date)
                begin_date_pre_nav_date_ = DateFormatTransfer.str2date(begin_date_pre_nav_date)
                query = query.filter(table_name.ENDDATE >= begin_date_pre_nav_date_)
                trade_date_list = trade_date_list[trade_date_list >= begin_date]
            if end_date is not None:
                end_date_ = DateFormatTransfer.str2date(end_date)
                query = query.filter(table_name.ENDDATE <= end_date_)
                trade_date_list = trade_date_list[trade_date_list <= end_date]
            if trade_date is not None:
                trade_date_ = DateFormatTransfer.str2date(trade_date)
                query = query.filter(table_name.ENDDATE == trade_date_)
                trade_date_list = trade_date_list[trade_date_list == trade_date]
            query = query.filter(table_name.SECURITYCODE == c)
            df = self.dfcf_reader.read_sql(query)
            df['ENDDATE'] = df['ENDDATE'].apply(DateFormatTransfer.date2str)
            df = _fill_nav(df, trade_date_list)
            df.sort_values(by='ENDDATE', inplace=True)
            df_res = df_res.append(df)
        return df_res

    def get_china_mutual_fund_nav(self, *args, **kwargs) -> pd.DataFrame:
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_mutual_fund_nav(*args, **kwargs)

    def get_existing_china_mutual_fund_code(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_existing_china_mutual_fund_code(*args, **kwargs)

    def get_china_mutual_fund_nav_continuous(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_mutual_fund_nav_continuous(*args, **kwargs)

    def get_china_mutual_fund_nav_pct_chg(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_mutual_fund_nav_pct_chg(*args, **kwargs)

    def get_china_mutual_fund_benchmark_eod(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_mutual_fund_benchmark_eod(*args, **kwargs)

    def get_all_index_close(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_all_index_close(*args, **kwargs)

    def get_cb_index_eod_prices(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_cb_index_eod_prices(*args, **kwargs)

    def get_c_bond_index_eod_cnbd(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_c_bond_index_eod_cnbd(*args, **kwargs)

    def get_a_index_eod_prices(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_a_index_eod_prices(*args, **kwargs)

    def get_china_mutual_fund_nav_net_asset_total(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_mutual_fund_nav_net_asset_total(*args, **kwargs)

    def get_parent_code(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_parent_code(*args, **kwargs)

    def get_china_mutual_fund_nav_f_prt_net_asset(self, *args, **kwargs):
        return self.wind_reader.get_china_mutual_fund_nav_f_prt_net_asset(*args, **kwargs)

    def get_a_index_wind_industries_eod(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_a_index_wind_industries_eod(*args, **kwargs)

    def get_a_sws_index_eod(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_a_sws_index_eod(*args, **kwargs)

    def get_c_money_market_daily_f_income(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_c_money_market_daily_f_income(*args, **kwargs)

    def get_cmm_quarterly_data(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_cmm_quarterly_data(*args, **kwargs)

    def get_china_closed_fund_eod_price(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_closed_fund_eod_price(*args, **kwargs)

    def get_china_mutual_fund_float_share(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_mutual_fund_float_share(*args, **kwargs)

    def get_c_bond_curve_cnbd(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_c_bond_curve_cnbd(*args, **kwargs)

    def get_china_mutual_fund_stock_portfolio(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_mutual_fund_stock_portfolio(*args, **kwargs)

    def get_china_mutual_fund_description(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_mutual_fund_description(*args, **kwargs)

    def get_all_fund_list(self):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_all_fund_list()

    def get_china_mf_dividend(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_mf_dividend(*args, **kwargs)

    def get_c_fund_pch_redm(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_c_fund_pch_redm(*args, **kwargs)

    def get_cmf_subred_fee(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_cmf_subred_fee(*args, **kwargs)

    def get_china_mutual_fund_manager_by_fund(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_mutual_fund_manager_by_fund(*args, **kwargs)

    def get_china_mutual_fund_manager_by_manager(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_mutual_fund_manager_by_manager(*args, **kwargs)

    def get_china_mutual_fund_sector_by_invest_type(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_mutual_fund_sector_by_invest_type(*args, **kwargs)

    def get_cmf_holder_structure(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_cmf_holder_structure(*args, **kwargs)

    def get_cm_fund_split(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_cm_fund_split(*args, **kwargs)

    def get_distinct_china_mutual_fund_nav_date(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_distinct_china_mutual_fund_nav_date(*args, **kwargs)

    def get_distinct_cmf_holder_structure_date(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_distinct_cmf_holder_structure_date(*args, **kwargs)

    def get_distinct_china_closed_fund_eod_price_date(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_distinct_china_closed_fund_eod_price_date(*args, **kwargs)

    def get_a_share_calendar(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_a_share_calendar(*args, **kwargs)

    def get_wind_industry_map_code_name(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_wind_industry_map_code_name(*args, **kwargs)

    def get_china_mutual_fund_issue_name(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_mutual_fund_issue_name(*args, **kwargs)

    def get_a_share_eod_prices(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_a_share_eod_prices(*args, **kwargs)

    def get_hk_share_eod_prices(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_hk_share_eod_prices(*args, **kwargs)

    def get_china_mutual_fund_stock_portfolio_by_date(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_china_mutual_fund_stock_portfolio_by_date(*args, **kwargs)

    def get_a_share_eod_derivative_indicator(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_a_share_eod_derivative_indicator(*args, **kwargs)

    def get_hk_share_eod_derivative_index(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use wind_reader", DeprecationWarning)
        return self.wind_reader.get_hk_share_eod_derivative_index(*args, **kwargs)

    def get_fund_adj_nav(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use dfcf_reader", DeprecationWarning)
        return self.dfcf_reader.get_fund_adj_nav(*args, **kwargs)

    def get_existing_fund_code(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use dfcf_reader", DeprecationWarning)
        return self.dfcf_reader.get_existing_fund_code(*args, **kwargs)

    def get_fund_total_asset(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use dfcf_reader", DeprecationWarning)
        return self.dfcf_reader.get_fund_total_asset(*args, **kwargs)

    def get_fund_manager_change(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use dfcf_reader", DeprecationWarning)
        return self.dfcf_reader.get_fund_manager_change(*args, **kwargs)

    def get_fund_type_code(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use dfcf_reader", DeprecationWarning)
        return self.dfcf_reader.get_fund_type_code(*args, **kwargs)

    def get_distinct_fund_nav_date(self, *args, **kwargs):
        warnings.warn("This function will be deprecated, please use dfcf_reader", DeprecationWarning)
        return self.dfcf_reader.get_distinct_fund_nav_date(*args, **kwargs)

    def get_fund_type_code_name_dict(self):
        warnings.warn("This function will be deprecated, please use dfcf_reader", DeprecationWarning)
        return self.dfcf_reader.get_fund_type_code_name_dict()


if __name__ == '__main__':
    m = MarketReader()
    res = m.get_compound_fund_benchmark('000001')
    print(res)
