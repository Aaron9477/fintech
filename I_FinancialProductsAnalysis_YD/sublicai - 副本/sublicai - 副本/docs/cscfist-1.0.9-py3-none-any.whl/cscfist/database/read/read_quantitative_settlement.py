# -*- coding: utf-8 -*-
from typing import Optional

from cscfist.database.connection.mysql_con import get_default_qs_connection
from cscfist.database.data_field.quantitative_settlement.quantitative_settlement_field import *
from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.model.db_model.rdb_model.rdb_operator_base import RdbBaseReader


class QuantitativeSettlementReader(RdbBaseReader):
    def __init__(self, qs_connection: Optional[RdbConnectionBase] = None):
        """
        Args:
            qs_connection: 数据库连接。如果为None则使用默认配置连接
        """
        if qs_connection is None:
            qs_connection = get_default_qs_connection()
        super().__init__(db_connection=qs_connection)

    def get_rqalpha_persist(self, strategy_id=None, save_object=None):
        """
        读取持久化表
        """
        table_name = RqalphaPersist
        query = self.query(table_name)
        if strategy_id is not None:
            query = query.filter(table_name.strategy_id == strategy_id)
        if save_object is not None:
            query = query.filter(table_name.save_object == save_object)

        df = self.read_sql(query)
        return df

    def get_strategy_info(self, strategy_id):
        table_name = StrategyInfo
        query = self.query(table_name)
        query = query.filter(table_name.strategy_id == strategy_id)
        df = self.read_sql(query)
        return df

    def get_strategy_stock_trading_backtest(self, strategy_id):
        table_name = StrategyStockTradingBacktest
        query = self.query(table_name)
        query = query.filter(table_name.strategy_id == strategy_id)
        df = self.read_sql(query)
        return df

    def get_strategy_stock_trading_clearing(self, strategy_id):
        table_name = StrategyStockTradingClearing
        query = self.query(table_name)
        query = query.filter(table_name.strategy_id == strategy_id)
        df = self.read_sql(query)
        return df


if __name__ == '__main__':
    res = QuantitativeSettlementReader().get_rqalpha_persist(11, "universe")
    res = res.sort_values("update_time", ascending=False)["save_value"][0]
    print(res)
