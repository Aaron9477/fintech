# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/11/23 14:28
# @Author  : wangxybjs
# @File    : market_reader_cache.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
import datetime
import json
from functools import partial
from typing import Optional, Union, List, Dict, Tuple

import numpy as np
import pandas as pd
from redis import Redis

from cscfist.config.style_config import STYLE_CONFIG
from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.database.read.read_market import MarketReader
from cscfist.database.read.redis_factory_mixin import RedisFactoryMixin
import warnings


class MarketReaderCache(MarketReader, RedisFactoryMixin):
    """
    基于Wind和DFCF的Redis存储读取API
    """

    def __init__(self, wind_connection: Optional[RdbConnectionBase] = None,
                 dfcf_connection: Optional[RdbConnectionBase] = None, redis_master: Optional[Redis] = None):
        warnings.warn("""In the future MarketReaderCache will be replaced by RedisReader. Add new function to 
        RedisReader if you want""", DeprecationWarning)
        if redis_master is None:
            from cscfist.database.connection.redis_con import get_default_redis_session
            redis_master = get_default_redis_session().redis_master
        RedisFactoryMixin.__init__(self, self.get_trade_date_list_cache, redis_master)
        MarketReader.__init__(self, wind_connection, dfcf_connection)

    """
    +--------------+
    |   时间序列型   | 
    +--------------+
    """

    def update_fund_adj_nav_cache(self, code, is_del=False):
        self.update_redis_data_time_series('dfcf:fund:adj_nav', 'SECURITYCODE', 'ENDDATE',
                                           self.get_fund_adj_nav, code,
                                           self.get_existing_fund_code, flag_expire_time='20:00:00',
                                           res_expire_time=None,
                                           is_del=is_del)

    def update_fund_adj_nav_cache_keep_non_empty(self, code, is_del=True):
        """
        保证redis中一直存在数据
        适用于恒天场景
        """
        self.update_redis_data_time_series('dfcf:fund:adj_nav_keep_non_empty', 'SECURITYCODE', 'ENDDATE',
                                           self.get_fund_adj_nav, code,
                                           self.get_existing_fund_code, flag_expire_time='22:20:00',
                                           res_expire_time=None,
                                           is_del=is_del)

    def get_fund_adj_nav_cache(self, code: Union[str, List, None] = None, begin_date: Optional[str] = None,
                               end_date: Optional[str] = None,
                               trade_date: Optional[str] = None) -> pd.DataFrame:
        """
        获取基金净值

        Args:
            code: 查询的代码
            begin_date: 以开始时间查询
            end_date: 以结束时间查询
            trade_date: 以单日查询

        Returns:
            +--------------+----------+-------+-----------+
            |     字段     |   含义   |  类型 |    示例   |
            +--------------+----------+-------+-----------+
            | SECURITYCODE |   代码   |  str  |  20090103 |
            |   ENDDATE    |   日期   |  str  | 110011.OF |
            |   AANVPER    | 复权净值 | float |    1.04   |
            |  AANVPERL   | 前复权净值 | float |    1.04   |
            +--------------+----------+-------+-----------+
        """
        redis_name = 'dfcf:fund:adj_nav'
        code_col = 'SECURITYCODE'
        date_col = 'ENDDATE'
        get_info_func = self.get_fund_adj_nav
        get_code_func = self.get_existing_fund_code
        res = self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func, code,
                                                  begin_date, end_date, trade_date, get_code_func)
        return res

    def update_fund_adj_nav_continuous_cache(self, code, is_del=False):
        self.update_redis_data_time_series('dfcf:fund:adj_nav_continuous', 'SECURITYCODE', 'ENDDATE',
                                           self.get_fund_adj_nav_continuous, code,
                                           self.get_existing_fund_code, flag_expire_time='20:00:00',
                                           res_expire_time=None,
                                           is_del=is_del)

    def update_fund_adj_nav_continuous_cache_keep_non_empty(self, code, is_del=True):
        """
        保证redis中一直存在数据
        适用于恒天场景
        """
        self.update_redis_data_time_series('dfcf:fund:adj_nav_continuous_keep_non_empty', 'SECURITYCODE', 'ENDDATE',
                                           self.get_fund_adj_nav_continuous, code,
                                           self.get_existing_fund_code, flag_expire_time='22:20:00',
                                           res_expire_time=None,
                                           is_del=is_del)

    def get_fund_adj_nav_continuous_cache(self, code: Union[str, List, None] = None, begin_date: Optional[str] = None,
                                          end_date: Optional[str] = None,
                                          trade_date: Optional[str] = None) -> pd.DataFrame:
        """
        获取基金连续的净值

        Args:
            code: 查询的代码
            begin_date: 以开始时间查询
            end_date: 以结束时间查询
            trade_date: 以单日查询

        Returns:
            +--------------+----------+-------+-----------+
            |     字段     |   含义   |  类型 |    示例   |
            +--------------+----------+-------+-----------+
            | SECURITYCODE |   代码   |  str  |  20090103 |
            |   ENDDATE    |   日期   |  str  | 110011.OF |
            |   AANVPER    | 复权净值 | float |    1.04   |
            +--------------+----------+-------+-----------+
        """
        redis_name = 'dfcf:fund:adj_nav_continuous'
        code_col = 'SECURITYCODE'
        date_col = 'ENDDATE'
        get_info_func = self.get_fund_adj_nav_continuous
        get_code_func = self.get_existing_fund_code
        res = self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func, code,
                                                  begin_date, end_date, trade_date, get_code_func)
        return res

    def get_fund_total_asset_df_cache(self, fund_code: Union[str, list, None]):
        """
        传入日期, 获取基金总资产表

        Args:
            fund_code: 基金代码
        """
        redis_name = 'dfcf:fund:fund_asset'
        code_col = 'SECURITYCODE'
        date_col = 'ENDDATE'
        get_info_func = self.get_fund_total_asset
        df = self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func,
                                                 fund_code, begin_date=None, end_date=None, trade_date=None)
        return df

    def get_fund_total_asset_cache(self, fund_code, date=None):
        """
        获取基金单份额总资产
        """
        df_res = self.get_fund_total_asset_df_cache(fund_code)
        df_res = df_res[df_res['ISSTAT'] == 1]
        if isinstance(fund_code, str):
            df_res = df_res[df_res['ENDDATE'] <= date]
            if len(df_res) > 0:
                code, date, nav, _, _ = df_res.sort_values(by='ENDDATE').values[0]
                return date, nav
        res_dict = {}
        for code, grouped in df_res.groupby('SECURITYCODE'):
            if len(grouped) > 0:
                code, date, nav, _, _ = grouped.sort_values(by='ENDDATE', ascending=False).values[0]
                res_dict[code] = [date, nav]
        return res_dict

    def update_china_mutual_fund_nav_cache(self, code):
        """
        用于多因子选基更新净值, 每日0点开始运行, 因此失效时间设置为0点
        """
        self.update_redis_data_time_series('china_mutual_fund:nav', 'F_INFO_WINDCODE', 'PRICE_DATE',
                                           self.get_china_mutual_fund_nav, code,
                                           self.get_existing_china_mutual_fund_code, flag_expire_time='00:00:00',
                                           res_expire_time='00:00:00')

    def update_china_mutual_fund_nav_continuous_cache(self, code):
        """
        用于多因子选基更新净值, 每日0点开始运行, 因此失效时间设置为0点
        """
        self.update_redis_data_time_series('china_mutual_fund:nav_continuous', 'F_INFO_WINDCODE', 'PRICE_DATE',
                                           self.get_china_mutual_fund_nav_continuous, code,
                                           self.get_existing_china_mutual_fund_code, flag_expire_time='00:00:00',
                                           res_expire_time='00:00:00')

    def update_china_mutual_fund_nav_pct_chg_cache(self, code):
        """
        用于多因子选基更新净值, 每日0点开始运行, 因此失效时间设置为0点
        """
        self.update_redis_data_time_series('china_mutual_fund:nav_pct_chg', 'F_INFO_WINDCODE', 'PRICE_DATE',
                                           self.get_china_mutual_fund_nav_pct_chg, code,
                                           self.get_existing_china_mutual_fund_code, flag_expire_time='00:00:00',
                                           res_expire_time='00:00:00')

    def get_china_mutual_fund_nav_cache(self, code: Union[str, List, None] = None, begin_date: Optional[str] = None,
                                        end_date: Optional[str] = None,
                                        trade_date: Optional[str] = None) -> pd.DataFrame:
        """
        获取基金净值

        Args:
            code: 查询的代码
            begin_date: 以开始时间查询
            end_date: 以结束时间查询
            trade_date: 以单日查询

        Returns:
            +-------------------+--------------+-------+-----------+
            |        字段       |     含义     |  类型 |    示例   |
            +-------------------+--------------+-------+-----------+
            |  F_INFO_WINDCODE  |   Wind代码   |  str  | 110011.OF |
            |     PRICE_DATE    |   交易日期   |  str  |  20090414 |
            |     F_NAV_UNIT    |   单位净值   | float |    1.07   |
            | F_NAV_ACCUMULATED |   累计净值   | float |    1.08   |
            |   F_PRT_NETASSET  | 单份额净资产 | float |    5000   |
            |   NETASSET_TOTAL  |   总净资产   | float |    6000   |
            |   F_NAV_ADJUSTED  |   复权净值   | float |    1.07   |
            +-------------------+--------------+-------+-----------+
        """
        redis_name = 'china_mutual_fund:nav'
        code_col = 'F_INFO_WINDCODE'
        date_col = 'PRICE_DATE'
        get_info_func = self.get_china_mutual_fund_nav
        get_code_func = self.get_existing_china_mutual_fund_code
        res = self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func, code,
                                                  begin_date, end_date, trade_date, get_code_func)
        return res

    def get_china_mutual_fund_nav_cache_continuous(self, code: Union[str, List, None] = None,
                                                   begin_date: Optional[str] = None,
                                                   end_date: Optional[str] = None,
                                                   trade_date: Optional[str] = None) -> pd.DataFrame:
        """
        获取基金净值, 对于非每日公布的基金, 向下填充

        Args:
            code: 查询的代码
            begin_date: 以开始时间查询
            end_date: 以结束时间查询
            trade_date: 以单日查询

        Returns:
            +-------------------+--------------+-------+-----------+
            |        字段       |     含义     |  类型 |    示例   |
            +-------------------+--------------+-------+-----------+
            |  F_INFO_WINDCODE  |   Wind代码   |  str  | 110011.OF |
            |     PRICE_DATE    |   交易日期   |  str  |  20090414 |
            |     F_NAV_UNIT    |   单位净值   | float |    1.07   |
            | F_NAV_ACCUMULATED |   累计净值   | float |    1.08   |
            |   F_PRT_NETASSET  | 单份额净资产 | float |    5000   |
            |   NETASSET_TOTAL  |   总净资产   | float |    6000   |
            |   F_NAV_ADJUSTED  |   复权净值   | float |    1.07   |
            +-------------------+--------------+-------+-----------+
        """
        redis_name = 'china_mutual_fund:nav_continuous'
        get_info_func = self.get_china_mutual_fund_nav_continuous
        get_code_func = self.get_existing_china_mutual_fund_code
        return self._get_time_series_factory_cache(redis_name, 'F_INFO_WINDCODE',
                                                   'PRICE_DATE', get_info_func, code, begin_date, end_date,
                                                   trade_date, get_code_func)

    def get_china_mutual_fund_benchmark_eod_cache(self, code: Union[str, List, None] = None,
                                                  begin_date: Optional[str] = None,
                                                  end_date: Optional[str] = None,
                                                  trade_date: Optional[str] = None) -> pd.DataFrame:
        """
        获取基金基准行情

        Args:
            code: 查询的代码
            begin_date: 以开始时间查询
            end_date: 以结束时间查询
            trade_date: 以单日查询

        Returns:
            +-------------------+--------------+-------+-----------+
            |        字段       |     含义     |  类型 |    示例   |
            +-------------------+--------------+-------+-----------+
            |  F_INFO_WINDCODE  |   Wind代码   |  str  | 110011.OF |
            |     PRICE_DATE    |   交易日期   |  str  |  20090414 |
            |     F_NAV_UNIT    |   单位净值   | float |    1.07   |
            | F_NAV_ACCUMULATED |   累计净值   | float |    1.08   |
            |   F_PRT_NETASSET  | 单份额净资产 | float |    5000   |
            |   NETASSET_TOTAL  |   总净资产   | float |    6000   |
            |   F_NAV_ADJUSTED  |   复权净值   | float |    1.07   |
            +-------------------+--------------+-------+-----------+
        """
        redis_name = 'china_mutual_fund:benchmark_eod'
        get_price_func = self.get_china_mutual_fund_benchmark_eod
        get_code_func = self.get_existing_china_mutual_fund_code
        return self._get_time_series_factory_cache(redis_name, 'S_INFO_WINDCODE', 'TRADE_DT', get_price_func, code,
                                                   begin_date, end_date, trade_date, get_code_func)

    def get_all_index_eod_cache(self, code: Union[str, List, None] = None, begin_date: Optional[str] = None,
                                end_date: Optional[str] = None,
                                trade_date: Optional[str] = None) -> pd.DataFrame:
        """
        遍历相关指数表, 获取指数行情
        指数表包括: [CMFINDEXEOD, ASWSINDEXEOD, GLOBALINDEXEOD, AINDEXEODPRICES, AINDEXINDUSTRIESEODCITICS,
        AINDEXWINDINDUSTRIESEOD, CBINDEXEODPRICES, HKINDEXEODPRICES]

        Args:
            code: 指数代码
            begin_date: 开始日期
            end_date: 结束日期
            trade_date: 交易日期

        Returns:
            +-----------------+----------+-------+-----------+
            |       字段      |   含义   |  类型 |    示例   |
            +-----------------+----------+-------+-----------+
            | S_INFO_WINDCODE | Wind代码 |  str  | 000300.SH |
            |     TRADE_DT    | 交易日期 |  str  |  20090414 |
            |    S_DQ_CLOSE   |  收盘价  | float |    1010   |
            +-----------------+----------+-------+-----------+
        """
        redis_name = 'all_index:eod_prices'
        get_price_func = self.get_all_index_close
        return self._get_time_series_factory_cache(redis_name, 'S_INFO_WINDCODE', 'TRADE_DT', get_price_func, code,
                                                   begin_date, end_date, trade_date)

    def get_cb_index_eod_prices_cache(self, code: Union[str, List, None] = None, begin_date: Optional[str] = None,
                                      end_date: Optional[str] = None,
                                      trade_date: Optional[str] = None) -> pd.DataFrame:
        """
        获取债券指数行情

        Args:
            code: 指数代码
            begin_date: 开始日期
            end_date: 结束日期
            trade_date: 交易日期

        Returns:
            +-----------------+----------+-------+------------+
            |       字段      |   含义   |  类型 |    示例    |
            +-----------------+----------+-------+------------+
            | S_INFO_WINDCODE | Wind代码 |  str  | h11001.CSI |
            |     TRADE_DT    | 交易日期 |  str  |  20090414  |
            |    S_DQ_CLOSE   |  收盘价  | float |    1010    |
            |  S_DQ_PCTCHANGE |  涨跌幅  | float |    0.05    |
            +-----------------+----------+-------+------------+
        """
        redis_name = 'cb_index:eod_prices'
        get_price_func = self.get_cb_index_eod_prices
        return self._get_time_series_factory_cache(redis_name, 'S_INFO_WINDCODE', 'TRADE_DT', get_price_func, code,
                                                   begin_date, end_date, trade_date)

    def get_c_bond_index_eod_cnbd_cache(self, code: Union[str, List, None] = None, begin_date: Optional[str] = None,
                                        end_date: Optional[str] = None,
                                        trade_date: Optional[str] = None) -> pd.DataFrame:
        redis_name = 'c_bond:index_eod_cnbd'
        get_info_func = self.get_c_bond_index_eod_cnbd
        return self._get_time_series_factory_cache(redis_name, 'S_INFO_WINDCODE', 'TRADE_DT', get_info_func, code,
                                                   begin_date, end_date, trade_date)

    def get_a_index_eod_prices_cache(self, code: Union[str, List, None] = None, begin_date: Optional[str] = None,
                                     end_date: Optional[str] = None,
                                     trade_date: Optional[str] = None) -> pd.DataFrame:
        redis_name = 'a_index:eod_prices'
        get_info_func = self.get_a_index_eod_prices
        return self._get_time_series_factory_cache(redis_name, 'S_INFO_WINDCODE', 'TRADE_DT', get_info_func, code,
                                                   begin_date, end_date, trade_date)

    def get_china_mutual_fund_nav_pct_chg_cache(self, code: Union[str, List, None] = None,
                                                begin_date: Optional[str] = None,
                                                end_date: Optional[str] = None,
                                                trade_date: Optional[str] = None) -> pd.DataFrame:
        """
        获取基金收益率

        Args:
            code: 查询的代码
            begin_date: 以开始时间查询
            end_date: 以结束时间查询
            trade_date: 以单日查询

        Returns:
            +-------------------+--------------+-------+-----------+
            |        字段       |     含义     |  类型 |    示例   |
            +-------------------+--------------+-------+-----------+
            |  F_INFO_WINDCODE  |   Wind代码   |  str  | 110011.OF |
            |     PRICE_DATE    |   交易日期   |  str  |  20090414 |
            |     F_NAV_UNIT    |   单位净值   | float |    1.07   |
            | F_NAV_ACCUMULATED |   累计净值   | float |    1.08   |
            |   F_PRT_NETASSET  | 单份额净资产 | float |    5000   |
            |   NETASSET_TOTAL  |   总净资产   | float |    6000   |
            |   F_NAV_ADJUSTED  |   复权净值   | float |    1.07   |
            +-------------------+--------------+-------+-----------+
        """
        redis_name = 'china_mutual_fund:nav_pct_chg'
        get_price_func = self.get_china_mutual_fund_nav_pct_chg
        return self._get_time_series_factory_cache(redis_name, 'F_INFO_WINDCODE', 'PRICE_DATE', get_price_func,
                                                   code, begin_date, end_date, trade_date)

    def get_compound_fund_benchmark_cache(self, code, begin_date=None, end_date=None, trade_date=None):
        """
        获取复合基准, 即对于自身基准空的日期按市场基准填充
        股票类基金采用沪深300, 债券类基金采用中证全债指数

        Args:
            code: 基金代码
            begin_date: 开始日期
            end_date: 结束日期
            trade_date: 交易日期

        Returns:
            +-----------------+----------+-------+-----------+----------------------+
            |       字段      |   含义   |  类型 |    示例   |         备注         |
            +-----------------+----------+-------+-----------+----------------------+
            | S_INFO_WINDCODE | Wind代码 |  str  | 110011.OF | 等同于传入的基金代码 |
            |     TRADE_DT    | 交易日期 |  str  |  20090414 |                      |
            |    S_DQ_CLOSE   |  收盘价  | float |    1.07   |                      |
            +-----------------+----------+-------+-----------+----------------------+
        """
        redis_name = 'china_mutual_fund:compound_benchmark_eod'
        get_info_func = self.get_compound_fund_benchmark

        return self._get_time_series_factory_cache(redis_name, 'S_INFO_WINDCODE', 'TRADE_DT', get_info_func, code,
                                                   begin_date, end_date, trade_date)

    def get_china_mutual_fund_nav_net_asset_total_df_cache(self, fund_code: Union[str, list, None],
                                                           begin_date: Optional[str] = None,
                                                           end_date: Optional[str] = None,
                                                           trade_date: Optional[str] = None) -> pd.DataFrame:
        redis_name = 'china_mutual_fund:nav_net_asset_total'
        code_col = 'F_INFO_WINDCODE'
        date_col = 'PRICE_DATE'
        get_price_func = self.get_china_mutual_fund_nav_net_asset_total
        df = self._get_time_series_factory_cache(redis_name, code_col, date_col, get_price_func,
                                                 fund_code, begin_date=begin_date, end_date=end_date,
                                                 trade_date=trade_date)
        return df

    def get_china_mutual_fund_nav_net_asset_total_cache(self, fund_code: Union[str, list, None],
                                                        date: Optional[str] = None) -> Union[None, List, Dict]:
        """
        传入日期, 获取当时最新的基金总净资产
        注意若该基金不是主份额, 则返回为空. 获取基金对应的主份额函数为
        >>> self.get_parent_code(fund_code)

        Args:
            fund_code: 基金代码
            date: 日期

        Returns:
            若传入fund_code为str, 则返回最新净资产日期和该基金的所有份额总资产
            否则返回字典, Key为fund_code, Value为最新净资产日期和该基金的所有份额总资产
        """
        df = self.get_china_mutual_fund_nav_net_asset_total_df_cache(fund_code)
        if date is not None:
            df = df[df['PRICE_DATE'] <= date]
        if isinstance(fund_code, str):
            if len(df) > 0:
                res = df.sort_values(by='PRICE_DATE', ascending=False).iloc[0].to_dict()
                res_date = res['PRICE_DATE']
                res_net_asset_total = res['NETASSET_TOTAL']
                return [res_date, res_net_asset_total]
            else:
                return None
        res_dict = {}
        for code, grouped in df.groupby('F_INFO_WINDCODE'):
            if len(grouped) > 0:
                res = grouped.sort_values(by='PRICE_DATE', ascending=False).iloc[0].to_dict()
                res_date = res['PRICE_DATE']
                res_net_asset_total = res['NETASSET_TOTAL']
                res_dict[code] = [res_date, res_net_asset_total]
        return res_dict

    def get_china_mutual_fund_nav_f_prt_net_asset_cache(self, fund_code: Union[str, list, None],
                                                        date: Optional[str] = None) -> Union[List, Dict, None]:
        """
        传入日期, 获取当时最新的基金单份额净资产

        Args:
            fund_code: 基金代码
            date: 日期

        Returns:
            若传入fund_code为str, 则返回最新净资产日期和该基金的单份额净资产
            否则返回字典, Key为fund_code, Value为最新净资产日期和该基金的单份额净资产
        """
        redis_name = 'china_mutual_fund:nav_f_prt_net_asset'
        code_col = 'F_INFO_WINDCODE'
        date_col = 'PRICE_DATE'
        get_info_func = self.get_china_mutual_fund_nav_f_prt_net_asset
        df = self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func,
                                                 fund_code, begin_date=None, end_date=None, trade_date=None)
        if date is not None:
            df = df[df['PRICE_DATE'] <= date]
        if isinstance(fund_code, str):
            if len(df) > 0:
                res = df.sort_values(by='PRICE_DATE', ascending=False).iloc[0].to_dict()
                net_asset_date = res['PRICE_DATE']
                prt_net_asset = res['F_PRT_NETASSET']
                return [net_asset_date, prt_net_asset]
            else:
                return None
        res_dict = {}
        for code, grouped in df.groupby('F_INFO_WINDCODE'):
            if len(grouped) > 0:
                res = grouped.sort_values(by='PRICE_DATE', ascending=False).iloc[0].to_dict()
                net_asset_date = res['PRICE_DATE']
                prt_net_asset = res['F_PRT_NETASSET']
                res_dict[code] = [net_asset_date, prt_net_asset]
        return res_dict

    def get_a_index_wind_industries_eod_cache(self, index_code, begin_date: Optional[str] = None,
                                              end_date: Optional[str] = None,
                                              trade_date: Optional[str] = None):
        redis_name = 'a_index:wind_industries_eod_prices'
        get_info_func = self.get_a_index_wind_industries_eod
        return self._get_time_series_factory_cache(redis_name, 'S_INFO_WINDCODE', 'TRADE_DT', get_info_func,
                                                   index_code, begin_date, end_date, trade_date)

    def get_a_sws_index_eod_cache(self, index_code, begin_date=None, end_date=None, trade_date=None):
        """申万指数行情"""
        redis_name = 'a_sws:index_eod'
        get_info_func = self.get_a_sws_index_eod
        return self._get_time_series_factory_cache(redis_name, 'S_INFO_WINDCODE', 'TRADE_DT', get_info_func,
                                                   index_code, begin_date, end_date, trade_date)

    def get_style_price_cache(self, style_type, begin_date=None, end_date=None):
        """
        获取风格指数的价格
        style_type包括:
            CNI6: 巨潮风格
            CNI4: 巨潮四风格
            CSI: 中证行业
            INDEX: 宽基指数
            CITIC: 中信行业
            SW: 申万行业
        """
        if style_type not in STYLE_CONFIG:
            return None
        df = None
        index_dict = STYLE_CONFIG[style_type]
        index_list = list(index_dict.keys())
        if style_type in ["CNI6", "CNI4", "CSI", "INDEX"]:
            df = self.get_a_index_eod_prices_cache(index_list, begin_date, end_date)
        elif style_type == "CITIC":
            df = self.get_a_index_wind_industries_eod_cache(index_list, begin_date, end_date)
        elif style_type == "SW":
            df = self.get_a_sws_index_eod_cache(index_list, begin_date, end_date)
        if len(df) == 0:
            return None
        df_bond = self.get_cb_index_eod_prices_cache('CBA00301.CS', begin_date, end_date)
        df = df[["S_INFO_WINDCODE", "TRADE_DT", "S_DQ_CLOSE"]].append(
            df_bond[["S_INFO_WINDCODE", "TRADE_DT", "S_DQ_CLOSE"]])
        df = df.pivot(index="TRADE_DT", columns="S_INFO_WINDCODE", values="S_DQ_CLOSE").reindex(
            columns=index_list + ['CBA00301.CS']).dropna(axis=0)
        return df

    def get_c_money_market_daily_f_income_cache(self, code: Union[str, List, None] = None,
                                                begin_date: Optional[str] = None,
                                                end_date: Optional[str] = None,
                                                trade_date: Optional[str] = None) -> pd.DataFrame:
        """
        获取货币型基金每日收益
        """
        redis_name = 'c_money:market_daily_f_income'
        code_col = 'S_INFO_WINDCODE'
        date_col = 'F_INFO_ENDDATE'
        get_info_func = self.get_c_money_market_daily_f_income
        get_code_func = self.get_existing_china_mutual_fund_code
        res = self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func, code,
                                                  begin_date, end_date, trade_date, get_code_func)
        return res

    def get_cmm_quarterly_data_cache(self, code: Union[str, List, None] = None,
                                     begin_date: Optional[str] = None,
                                     end_date: Optional[str] = None,
                                     trade_date: Optional[str] = None) -> pd.DataFrame:
        """
        获取货币型基金每日收益
        """
        redis_name = 'cmm:quarterly_data'
        code_col = 'S_INFO_WINDCODE'
        date_col = 'F_INFO_ENDDATE'
        get_info_func = self.get_cmm_quarterly_data
        get_code_func = self.get_existing_china_mutual_fund_code
        res = self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func, code,
                                                  begin_date, end_date, trade_date, get_code_func)
        return res

    def get_china_closed_fund_eod_price_cache(self, code: Union[str, List, None] = None,
                                              begin_date: Optional[str] = None,
                                              end_date: Optional[str] = None,
                                              trade_date: Optional[str] = None) -> pd.DataFrame:
        """
        获取中国上市基金日行情
        """
        redis_name = 'china_closed_fund:eod_price'
        code_col = 'S_INFO_WINDCODE'
        date_col = 'TRADE_DT'
        get_info_func = self.get_china_closed_fund_eod_price
        get_code_func = self.get_existing_china_mutual_fund_code
        res = self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func, code,
                                                  begin_date, end_date, trade_date, get_code_func)
        return res

    def get_china_mutual_fund_float_share_cache(self, code: Union[str, List, None] = None,
                                                begin_date: Optional[str] = None,
                                                end_date: Optional[str] = None,
                                                trade_date: Optional[str] = None) -> pd.DataFrame:
        """
        中国共同基金场内流通份额
        """
        redis_name = 'china_mutual_fund:float_share'
        code_col = 'S_INFO_WINDCODE'
        date_col = 'TRADE_DT'
        get_info_func = self.get_china_mutual_fund_float_share
        get_code_func = self.get_existing_china_mutual_fund_code
        res = self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func, code,
                                                  begin_date, end_date, trade_date, get_code_func)
        return res

    def get_c_bond_curve_cnbd_china_bond_gov_ytm_10y(self, begin_date: Optional[str] = None,
                                                     end_date: Optional[str] = None,
                                                     trade_date: Optional[str] = None) -> pd.DataFrame:
        """
        10年期国债收益率曲线
        """

        def get_info_func(code='1232'):
            curve_res = self.get_c_bond_curve_cnbd(curve_number=code, curve_term=10)
            curve_res['B_ANAL_CURVENUMBER'] = curve_res['B_ANAL_CURVENUMBER'].astype(int).astype(str)
            return curve_res

        redis_name = 'c_bond:curve_cnbd_china_bond_gov_ytm_10y'
        code_col = 'B_ANAL_CURVENUMBER'
        date_col = 'TRADE_DT'
        res = self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func, '1232',
                                                  begin_date, end_date, trade_date)
        return res

    def get_china_mutual_fund_stock_portfolio_cache(self, code=None, begin_date=None, end_date=None,
                                                    report_period=None) -> pd.DataFrame:

        redis_name = 'china_mutual_fund:stock_portfolio'
        code_col = 'S_INFO_WINDCODE'
        date_col = 'F_PRT_ENDDATE'
        get_info_func = self.get_china_mutual_fund_stock_portfolio
        res = self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func, code, begin_date,
                                                  end_date, report_period)
        return res

    """
    +--------------+
    |   横截面类型   | 
    +--------------+
    """

    def get_china_mutual_fund_description_cache(self, code: Union[str, List, None] = None, date=None):
        """
        获取中国共同基金基本资料

        Args:
            code: 基金代码
            date: 日期, 如果为'all'则返回全部的结果, 如果为None为返回此时存续的基金, 否则返回当时存续的基金

        Returns:
            +--------------------------------+----------------------+-------+--------------------------------+
            |              字段              |         含义         |  类型 |              示例              |
            +--------------------------------+----------------------+-------+--------------------------------+
            |        F_INFO_WINDCODE         |       Wind代码       |  str  |           110011.OF            |
            |        F_INFO_FULLNAME         |         名称         |  str  | 易方达中小盘混合型证券投资基金 |
            |          F_INFO_NAME           |         简称         | float |          易方达中小盘          |
            | F_INFO_CORP_FUNDMANAGEMENTCOMP |        管理人        | float |           易方达基金           |
            |  F_INFO_CORP_FUNDMANAGEMENTID  |     基金管理人ID     |  str  |           502031274            |
            |         F_INFO_STATUS          |       存续状态       | float |           101001000            |
            |        F_INFO_SETUPDATE        |       成立日期       |  str  |            20080619            |
            |       F_INFO_DELISTDATE        |       退市日期       |  str  |                                |
            |      F_INFO_MATURITYDATE       |       到期日期       |  str  |                                |
            |         F_INFO_FUND_ID         |      基金品种ID      |  str  |           3CN4664283           |
            |     F_PCHREDM_PCHSTARTDATE     |    日常申购起始日    |  str  |            20080919            |
            |      F_INFO_REDMSTARTDATE      |    日常赎回起始日    |  str  |            20080919            |
            |      F_INFO_MINBUYAMOUNT       |       起点金额       | float |              0.1               |
            |        F_INFO_ISINITIAL        |    是否为初始基金    | float |               1                |
            |    F_PERSONAL_STARTDATEIND     | 个人投资者认购起始日 |  str  |            20080528            |
            |     F_PERSONAL_ENDDATEIND      | 个人投资者认购终止日 |  str  |            20080613            |
            +--------------------------------+----------------------+-------+--------------------------------+
        """
        redis_name = 'china_mutual_fund:description'
        get_info_func = self.get_china_mutual_fund_description
        code_col = 'F_INFO_WINDCODE'
        get_code_func = self.get_all_fund_list
        df = self._get_cross_sectional_factory(redis_name, code_col, get_info_func, code,
                                               get_code_func)
        if date is None:
            date = datetime.datetime.now().strftime('%Y%m%d')
        if date == 'all':
            return df
        else:
            df = df[(df['F_INFO_SETUPDATE'] <= date) & (
                    (df['F_INFO_MATURITYDATE'] >= date) | (df['F_INFO_MATURITYDATE'].isna()))]
        return df

    def get_china_mf_dividend_cache(self, fund_code: Union[str, list, None] = None) -> pd.DataFrame:
        """
        中国共同基金分红

        Args:
            fund_code: 基金代码

        Returns:
            +---------------------+--------------------------+-------+-----------+
            |         字段        |           含义           |  类型 |    示例   |
            +---------------------+--------------------------+-------+-----------+
            |   S_INFO_WINDCODE   |         Wind代码         |  str  | 110011.OF |
            |    EQY_RECORD_DT    |        权益登记日        |  str  |  20090414 |
            |        EX_DT        |          除息日          |  str  |  20090414 |
            |    F_DIV_EDEXDATE   |       除息日(场外)       |  str  |  20090414 |
            |        PAY_DT       |          派息日          |  str  |  20090414 |
            |    F_DIV_PAYDATE    |       派息日(场外)       |  str  |  20090414 |
            | CASH_DVD_PER_SH_TAX |       每股派息(元)       | float |    0.04   |
            |    F_REINV_BCH_DT   | 红利再投资份额净值基准日 |  str  |  20090414 |
            +---------------------+--------------------------+-------+-----------+
        """
        redis_name = 'china_mf:dividend'
        code_col = 'S_INFO_WINDCODE'
        get_info_func = self.get_china_mf_dividend
        get_code_func = self.get_existing_china_mutual_fund_code
        df = self._get_cross_sectional_factory(redis_name, code_col, get_info_func, fund_code, get_code_func)
        return df

    def get_c_fund_pch_redm_cache(self, fund_code: Union[str, list, None] = None) -> pd.DataFrame:
        """
        中国共同基金申购赎回天数

        Args:
            fund_code: 基金代码

        Returns:
            +----------------------+------------------+-------+-----------+
            |         字段         |       含义       |  类型 |    示例   |
            +----------------------+------------------+-------+-----------+
            |   F_INFO_WINDCODE    |     Wind代码     |  str  | 000001.OF |
            |   F_INFO_SUSPCHDAY   |   申购确认天数   | float |     1     |
            |  F_INFO_SUSREDMDAY4  | 赎回确认查询天数 | float |     2     |
            | F_INFO_APPROVED_DATE |     获批日期     |  str  |  20011113 |
            +----------------------+------------------+-------+-----------+
        """
        redis_name = 'cfund:pch_redm'
        code_col = 'F_INFO_WINDCODE'
        get_info_func = self.get_c_fund_pch_redm
        get_code_func = self.get_existing_china_mutual_fund_code
        df = self._get_cross_sectional_factory(redis_name, code_col, get_info_func, fund_code, get_code_func)
        return df

    def get_cmf_subred_fee_cache(self, fund_code: Union[str, list, None] = None) -> pd.DataFrame:
        """
        中国共同基金费率表

        Args:
            fund_code: 基金代码

        Returns:
            +-----------------+----------------+-------+-----------+
            |       字段      |      含义      |  类型 |    示例   |
            +-----------------+----------------+-------+-----------+
            | S_INFO_WINDCODE |    Wind代码    |  str  | 110011.OF |
            |   FEETYPECODE   |    费率类型    |  str  |  申购费率 |
            |     FEERATIO    |    费率(%)     | float |    1.2    |
            | AMOUNTDOWNLIMIT | 金额下限(万元) | float |    100    |
            |  AMOUNTUPLIMIT  | 金额上限(万元) | float |    500    |
            +-----------------+----------------+-------+-----------+
        """
        redis_name = 'cmf:subred_fee'
        code_col = 'S_INFO_WINDCODE'
        get_info_func = self.get_cmf_subred_fee
        get_code_func = self.get_existing_china_mutual_fund_code
        df = self._get_cross_sectional_factory(redis_name, code_col, get_info_func, fund_code, get_code_func)
        return df

    """
    +--------------+
    |  进入退出类型  | 
    +--------------+
    """

    def get_fund_manager_change_cache_by_fund(self, fund_code, begin_date=None, end_date=None, trade_date=None,
                                              is_cur=True):
        redis_name = 'dfcf:fund_manager:change_by_fund'
        code_col = 'SECURITYCODE'
        begin_date_col = 'CHANGEDATE'
        end_date_col = 'ENDDATE'
        get_info_func = self.get_fund_manager_change
        get_code_func = self.get_existing_fund_code
        res = self._get_entry_exit_factory(redis_name, code_col, begin_date_col, end_date_col, get_info_func, fund_code,
                                           begin_date, end_date, trade_date, is_cur, get_code_func)
        return res

    def get_fund_manager_change_cache_by_manager(self, manager_id=None, begin_date=None, end_date=None,
                                                 trade_date=None, is_cur=True):
        redis_name = 'dfcf:fund_manager:change_by_manager'
        code_col = 'PERSONCODE'
        begin_date_col = 'F_INFO_MANAGER_STARTDATE'
        end_date_col = 'ENDDATE'
        get_info_func = partial(self.get_fund_manager_change, None)
        res = self._get_entry_exit_factory(redis_name, code_col, begin_date_col, end_date_col, get_info_func,
                                           manager_id, begin_date, end_date, trade_date, is_cur)
        return res

    def get_fund_type_code_df_cache(self, fund_code, level=2, begin_date=None, end_date=None,
                                    trade_date=None, is_cur=True):
        redis_name = 'dfcf:fund:fund_type_change'
        code_col = 'SECURITYCODE'
        begin_date_col = 'CHANGEDATE'
        end_date_col = 'ENDDATE'
        get_info_func = self.get_fund_type_code
        get_code_func = self.get_existing_fund_code
        res = self._get_entry_exit_factory(redis_name, code_col, begin_date_col, end_date_col, get_info_func,
                                           fund_code, begin_date, end_date, trade_date, is_cur, get_code_func)
        res["TYPECODE"] = res["TYPECODE"].apply(lambda x: str(int(float(x))))
        return res

    def get_fund_type_code_cache(self, fund_code, level=2, trade_date=None, is_cur=True):
        res = self.get_fund_type_code_df_cache(fund_code, level=level, trade_date=trade_date, is_cur=is_cur)
        if fund_code is not None and isinstance(fund_code, str):
            if len(res["TYPECODE"]) > 0:
                return res["TYPECODE"].values[0]
            else:
                return "其他"
        else:
            return res.set_index("SECURITYCODE")["TYPECODE"].to_dict()

    def get_fund_type_name_df_cache(self, fund_code, level=2, begin_date=None, end_date=None,
                                    trade_date=None, is_cur=True):
        if trade_date is not None:
            is_cur = False
        res = self.get_fund_type_code_df_cache(fund_code, level, begin_date, end_date, trade_date,
                                               is_cur)
        fund_type_code_name_map = self.get_fund_type_code_name_dict_cache()
        res['TYPECODE'] = res['TYPECODE'].map(fund_type_code_name_map)
        return res

    def get_fund_type_name_cache(self, fund_code, level=2, trade_date=None, is_cur=True):
        if trade_date is not None:
            is_cur = False
        res = self.get_fund_type_code_cache(fund_code, level=level, trade_date=trade_date, is_cur=is_cur)
        fund_type_code_name_map = self.get_fund_type_code_name_dict_cache()
        if isinstance(fund_code, str):
            if res not in fund_type_code_name_map:
                return "其他"
            else:
                return fund_type_code_name_map[res]
        else:
            return pd.Series(res).map(fund_type_code_name_map).fillna("其他").to_dict()

    def get_china_mutual_fund_manager_cache_by_fund(self, fund_code, begin_date=None, end_date=None, trade_date=None,
                                                    is_cur=True):
        redis_name = 'china_mutual_fund:manager:by_fund_code'
        code_col = 'F_INFO_WINDCODE'
        begin_date_col = 'F_INFO_MANAGER_STARTDATE'
        end_date_col = 'F_INFO_MANAGER_LEAVEDATE'
        get_info_func = self.get_china_mutual_fund_manager_by_fund
        get_code_func = self.get_existing_china_mutual_fund_code
        res = self._get_entry_exit_factory(redis_name, code_col, begin_date_col, end_date_col, get_info_func, fund_code,
                                           begin_date, end_date, trade_date, is_cur, get_code_func)
        return res

    def get_china_mutual_fund_manager_cache_by_manager(self, manager_id=None, begin_date=None, end_date=None,
                                                       trade_date=None, is_cur=True) -> pd.DataFrame:
        redis_name = 'china_mutual_fund:manager:by_manager_id'
        code_col = 'F_INFO_FUNDMANAGER_ID'
        begin_date_col = 'F_INFO_MANAGER_STARTDATE'
        end_date_col = 'F_INFO_MANAGER_LEAVEDATE'
        get_info_func = self.get_china_mutual_fund_manager_by_manager
        res = self._get_entry_exit_factory(redis_name, code_col, begin_date_col, end_date_col, get_info_func,
                                           manager_id, begin_date, end_date, trade_date, is_cur)
        return res

    def get_china_mutual_fund_wind_sector_code_df_cache(self, fund_code=None, level=2, begin_date=None, end_date=None,
                                                        trade_date=None, is_cur=True):
        redis_name = f'china_mutual_fund:wind_sector:res'
        code_col = 'F_INFO_WINDCODE'
        begin_date_col = 'S_INFO_SECTORENTRYDT'
        end_date_col = 'S_INFO_SECTOREXITDT'
        get_info_func = self.get_china_mutual_fund_sector_by_invest_type
        get_code_func = self.get_existing_china_mutual_fund_code
        df_res = self._get_entry_exit_factory(redis_name, code_col, begin_date_col, end_date_col, get_info_func,
                                              fund_code, begin_date, end_date, trade_date, is_cur, get_code_func)
        if level == 1:
            # Wind一级分类, 8位代码 + 8个0, 如2001010100000000代表股票型基金
            df_res["S_INFO_SECTOR"] = df_res["S_INFO_SECTOR"].apply(lambda x: x[:8] + '0' * 8)
        elif level == 2:
            # Wind二级分类, 10位代码 + 6个0, 如2001010101000000代表普通股票型基金
            df_res["S_INFO_SECTOR"] = df_res["S_INFO_SECTOR"].apply(lambda x: x[:10] + '0' * 6)
        elif level == 3:
            # Wind三级分类, 12位代码+4个0, 如2001010801010000代表国际(QDII)普通股票型基金
            # 注意只有国际(QDII)基金、FOF基金存在三级分类
            df_res["S_INFO_SECTOR"] = df_res["S_INFO_SECTOR"].apply(lambda x: x[:12] + '0' * 4)

        df_res["S_INFO_SECTOR"] = df_res["S_INFO_SECTOR"].fillna("其他")
        return df_res

    def get_china_mutual_fund_wind_sector_code_cache(self, fund_code=None, level=2,
                                                     trade_date=None, is_cur=True):
        df_res = self.get_china_mutual_fund_wind_sector_code_df_cache(fund_code, level=level, trade_date=trade_date,
                                                                      is_cur=is_cur)
        if fund_code is not None and isinstance(fund_code, str):
            if len(df_res["S_INFO_SECTOR"]) > 0:
                return df_res["S_INFO_SECTOR"].values[0]
            else:
                return "其他"
        else:
            return df_res.set_index("F_INFO_WINDCODE")["S_INFO_SECTOR"].to_dict()

    def get_china_mutual_fund_wind_sector_name_df_cache(self, fund_code, level=2, begin_date=None, end_date=None,
                                                        trade_date=None, is_cur=True):
        if trade_date is not None:
            is_cur = False
        res = self.get_china_mutual_fund_wind_sector_code_df_cache(fund_code, level, begin_date, end_date, trade_date,
                                                                   is_cur)
        wind_industry_map = self.get_wind_industry_map_cache()
        res['S_INFO_SECTOR'] = res['S_INFO_SECTOR'].map(wind_industry_map)
        return res

    def get_china_mutual_fund_wind_sector_name_cache(self, fund_code=None, level=2, trade_date=None, is_cur=True):
        if trade_date is not None:
            is_cur = False
        res = self.get_china_mutual_fund_wind_sector_code_cache(fund_code, level=level, trade_date=trade_date,
                                                                is_cur=is_cur)
        wind_industry_map = self.get_wind_industry_map_cache()
        if isinstance(fund_code, str):
            if res not in wind_industry_map:
                return "其他"
            else:
                return wind_industry_map[res]
        else:
            return pd.Series(res).map(wind_industry_map).fillna("其他").to_dict()

    def get_cmf_holder_structure_ratio_df_cache(self, fund_code: str, begin_date=None, end_date=None,
                                                trade_date=None) -> pd.DataFrame:
        redis_name = 'cmf:holder_structure'
        code_col = 'S_INFO_WINDCODE'
        date_col = 'END_DT'
        get_info_func = self.get_cmf_holder_structure

        df = self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func,
                                                 fund_code, begin_date=begin_date, end_date=end_date,
                                                 trade_date=trade_date).fillna(0)
        return df

    def get_cmf_holder_structure_ratio_cache(self, fund_code: str,
                                             date: Optional[str] = None) -> Optional[Tuple[float, float, float, float]]:
        """
        获取中国共同基金持有人结构

        Args:
            fund_code: 基金代码
            date: 日期

        Returns:
            返回(机构投资者比例, 个人投资者比例, 管理者比例, 联接基金比例)

        """
        df = self.get_cmf_holder_structure_ratio_df_cache(fund_code)
        if date is not None:
            df = df[df['END_DT'] <= date]
        if len(df) > 0:
            res_dict = df.sort_values(by='END_DT', ascending=False).iloc[0].to_dict()
            institution_percent_structure = res_dict['HOLDER_INSTITUTION_HOLDINGPCT']
            personal_percent_structure = res_dict['HOLDER_PERSONAL_HOLDINGPCT']
            manage_percent_structure = res_dict['HOLDER_MNGEMP_HOLDINGPCT']
            feeder_percent_structure = res_dict['HOLDER_FEEDER_HOLDINGPCT']
            return (institution_percent_structure, personal_percent_structure,
                    manage_percent_structure, feeder_percent_structure)
        else:
            return None

    def get_cm_fund_split_cache(self, fund_code, share_trans_date=None):
        """
        获取中国共同基金份额拆分

        Args:
            fund_code: 基金代码
            share_trans_date: 拆分日期
        """
        redis_name = 'cm_fund:split'
        get_info_func = self.get_cm_fund_split
        get_code_func = self.get_existing_china_mutual_fund_code
        return self._get_time_series_factory_cache(redis_name, 'S_INFO_WINDCODE', 'F_INFO_SHARETRANSDATE',
                                                   get_info_func, fund_code, trade_date=share_trans_date,
                                                   get_code_func=get_code_func)

    """
    +--------------+
    |  时间列表类型  | 
    +--------------+
    """

    def get_distinct_fund_nav_date_cache(self, code: str, begin_date: Optional[str] = None,
                                         end_date: Optional[str] = None) -> List[str]:
        redis_name = 'dfcf:fund_nav_date'
        get_info_func = self.get_distinct_fund_nav_date
        get_code_func = self.get_existing_fund_code
        return self._get_time_list_factory_cache(redis_name, get_info_func, code, begin_date, end_date, get_code_func)

    def get_distinct_china_mutual_fund_nav_date_cache(self, code: str, begin_date: Optional[str] = None,
                                                      end_date: Optional[str] = None) -> List[str]:
        redis_name = 'china_mutual_fund:nav_date'
        get_info_func = self.get_distinct_china_mutual_fund_nav_date
        get_code_func = self.get_existing_china_mutual_fund_code
        return self._get_time_list_factory_cache(redis_name, get_info_func, code, begin_date, end_date, get_code_func)

    def get_distinct_cmf_holder_structure_date_cache(self, code: str, begin_date: Optional[str] = None,
                                                     end_date: Optional[str] = None) -> List[str]:
        redis_name = 'cmf:holder_structure:date'
        get_info_func = self.get_distinct_cmf_holder_structure_date
        get_code_func = self.get_existing_china_mutual_fund_code
        return self._get_time_list_factory_cache(redis_name, get_info_func, code, begin_date, end_date, get_code_func)

    def get_distinct_china_closed_fund_eod_price_date_cache(self, code: str, begin_date: Optional[str] = None,
                                                            end_date: Optional[str] = None) -> List[str]:
        redis_name = 'china_closed_fund:eod_price:date'
        get_info_func = self.get_distinct_china_closed_fund_eod_price_date
        get_code_func = self.get_existing_china_mutual_fund_code
        return self._get_time_list_factory_cache(redis_name, get_info_func, code, begin_date, end_date, get_code_func)

    """
    +------------+
    |   其他类型   | 
    +------------+
    """

    def get_fund_type_code_name_dict_cache(self):
        redis_name = 'dfcf:fund:fund_type_map'
        if self.exists(redis_name):
            industry_map = self.hgetall(redis_name)
        else:
            industry_map = self.get_fund_type_code_name_dict()
            self.hset_with_expire(redis_name, mapping=industry_map)
        return industry_map

    def get_trade_date_list_cache(self, begin_date: Optional[str] = None, end_date: Optional[str] = None) -> np.ndarray:
        """
        获取交易日列表

        分年份存储

        Args:
            begin_date: 开始日期
            end_date: 结束日期

        Returns:
            交易日列表

        Examples:
            >>> MarketReaderCache().get_trade_date_list_cache(begin_date="20210820", end_date="20210826")
            ['20210820' '20210823' '20210824' '20210825' '20210826']
        """
        name = 'a_share_trade_date_list'
        if not self.exists(name):
            # redis未保存的情形
            trade_date_list = self.get_a_share_calendar()['TRADE_DAYS'].values
            trade_date_list.sort()
            df = pd.DataFrame({'date': trade_date_list})
            df['year'] = df['date'].apply(lambda x: x[:4])
            # 因数据量太大, 按年保存
            for year, grouped in df.groupby("year"):
                self.hset_with_expire(name, year, json.dumps(grouped['date'].tolist(), ensure_ascii=False))
        else:
            # redis已保存的情形
            cur_year = datetime.datetime.now().year
            year_list = np.arange(1990, cur_year + 1).astype(str)
            if begin_date is not None:
                begin_year = str(datetime.datetime.strptime(begin_date, '%Y%m%d').year)
                year_list = year_list[year_list >= begin_year]
            if end_date is not None:
                end_year = str(datetime.datetime.strptime(end_date, '%Y%m%d').year)
                year_list = year_list[year_list <= end_year]
            trade_date_list = []
            for year in year_list:
                if self.hexists(name=name, key=year):
                    res = json.loads(self.hget(name=name, key=year))
                    trade_date_list.extend(res)
            trade_date_list = np.array(trade_date_list, dtype=object)

        if begin_date is not None:
            trade_date_list = trade_date_list[trade_date_list >= begin_date]
        if end_date is not None:
            trade_date_list = trade_date_list[trade_date_list <= end_date]
        return trade_date_list

    def get_wind_industry_map_cache(self):
        redis_name = 'china_mutual_fund:wind_sector:map'
        if self.exists(redis_name):
            industry_map = self.hgetall(redis_name)
        else:
            industry_map = self.get_wind_industry_map_code_name()
            self.hset_with_expire(redis_name, mapping=industry_map)
        return industry_map

    def get_parent_code_cache(self, fund_code: str) -> str:
        """
        获取主份额基金代码
        """
        redis_name = f'china_mutual_fund:parent_code'
        if self.hexists(redis_name, fund_code):
            res = self.hget(redis_name, fund_code)
            res = json.loads(res)
        else:
            res = self.get_parent_code(fund_code)
            self.hset_with_expire(redis_name, fund_code, json.dumps(res, ensure_ascii=False))
        return res

    def get_china_mutual_fund_issue_name_cache(self, fund_code: str) -> str:
        """
        获取基金名称
        """
        redis_name = f'china_mutual_fund:name'
        if self.hexists(redis_name, fund_code):
            res = self.hget(redis_name, fund_code)
            res = json.loads(res)
        else:
            res = self.get_china_mutual_fund_issue_name(fund_code)
            self.hset_with_expire(redis_name, fund_code, json.dumps(res, ensure_ascii=False))
        return res

    def get_ashare_eod_prices_cache(self, code: Union[str, List, None] = None, begin_date: Optional[str] = None,
                                    end_date: Optional[str] = None, trade_date: Optional[str] = None):
        """
        获取A股股票日行情
        """
        redis_name = 'ashare:eod_prices'
        code_col = 'S_INFO_WINDCODE'
        date_col = 'TRADE_DT'
        get_info_func = self.get_a_share_eod_prices
        get_code_func = self.get_existing_china_mutual_fund_code
        return self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func, code, begin_date,
                                                   end_date, trade_date, get_code_func=get_code_func)

    def get_hk_eod_prices_cache(self, code: Union[str, List, None] = None, begin_date: Optional[str] = None,
                                end_date: Optional[str] = None, trade_date: Optional[str] = None):
        """
        获取港股股票日行情
        """
        redis_name = 'hk:eod_prices'
        code_col = 'S_INFO_WINDCODE'
        date_col = 'TRADE_DT'
        get_info_func = self.get_hk_share_eod_prices
        return self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func, code, begin_date,
                                                   end_date, trade_date)

    def get_stock_eod_prices(self, code: Union[str, List], begin_date=None, end_date=None, trade_date=None):
        """
        获取股票日行情
        """
        if isinstance(code, str):
            if 'HK' in code:
                return self.get_hk_eod_prices_cache(code, begin_date, end_date, trade_date)
            else:
                return self.get_ashare_eod_prices_cache(code, begin_date, end_date, trade_date)
        else:
            ashare_code_list = [i for i in code if 'HK' not in i]
            hk_code_list = [i for i in code if 'HK' in i]
            ashare_df = self.get_ashare_eod_prices_cache(ashare_code_list, begin_date, end_date, trade_date)
            hk_df = self.get_hk_eod_prices_cache(hk_code_list, begin_date, end_date, trade_date)
            df_res = pd.concat([ashare_df, hk_df], axis=0)
        return df_res

    def get_composite_benchmark_eod_cache(self, bm_dict: Union[Dict], begin_date: str = None, end_date: str = None,
                                          trade_date: str = None):
        """
        复合基准
        Args:
            bm_dict: 基准权重字典{基准代码1： 权重1, 基准代码2： 权重2}
            begin_date: 开始日期
            end_date: 截至日期
            trade_date: 交易日期

        Returns:

        """
        redis_name = 'composite_benchmark_eod'
        code_col = 'code'
        date_col = 'trade_date'
        get_info_func = self._get_composite_benchmark_eod_cache
        df = self._get_time_series_factory_cache(redis_name, code_col, date_col, get_info_func, json.dumps(bm_dict),
                                                 begin_date, end_date, trade_date)
        return df

    def _get_composite_benchmark_eod_cache(self, code):
        if isinstance(code, str):
            code = [code]
        res = pd.DataFrame()
        for c in code:
            bm_dict = json.loads(c)
            df = self.get_all_index_eod_cache(list(bm_dict.keys()))
            start_date_list = [df[df['S_INFO_WINDCODE'] == index_code]['TRADE_DT'].min() for index_code in
                               list(bm_dict.keys())]
            df = df[df['TRADE_DT'] >= max(start_date_list)]
            df_close_pivot = df.pivot(index='TRADE_DT', columns='S_INFO_WINDCODE', values='S_DQ_CLOSE')
            df_pct_chg_pivot = df_close_pivot.pct_change().fillna(0)
            df_weight_pivot = pd.DataFrame().reindex_like(df_pct_chg_pivot).fillna(bm_dict)
            benchmark_nav = (df_pct_chg_pivot * df_weight_pivot).sum(axis=1)
            benchmark_nav = (benchmark_nav + 1).cumprod()
            df_benchmark = benchmark_nav.reset_index().rename(columns={'TRADE_DT': 'trade_date', 0: 'nav'})
            df_benchmark['code'] = c
            res = res.append(df_benchmark)
        return res

    """
    +--------------+
    |  时间集合工厂  | 
    +--------------+
    """

    def get_china_mutual_fund_stock_portfolio_by_date_cache(self, report_period, is_top10=False, fund_code=None):
        def get_info_func(date):
            return self.get_china_mutual_fund_stock_portfolio_by_date(date, is_top10=is_top10)

        if is_top10:
            redis_name = 'china_mutual_fund:stock_portfolio_by_date:top10'
        else:
            redis_name = 'china_mutual_fund:stock_portfolio_by_date:all'
        code_col = 'S_INFO_WINDCODE'
        res = self._get_time_list_cross_sectional_factory_cache(redis_name, code_col, get_info_func, report_period,
                                                                fund_code)
        return res

    def get_a_share_eod_derivative_indicator_cache(self, trade_date, stock_code=None):
        def get_info_func(date):
            return self.get_a_share_eod_derivative_indicator(trade_date=date)

        redis_name = 'a_share:eod_derivative_indicator'
        code_col = 'S_INFO_WINDCODE'
        res = self._get_time_list_cross_sectional_factory_cache(redis_name, code_col, get_info_func, trade_date,
                                                                stock_code)
        return res

    def get_hk_share_eod_derivative_index_cache(self, trade_date, stock_code=None):
        def get_info_func(date):
            return self.get_hk_share_eod_derivative_index(trade_date=date)

        redis_name = 'hk_share:eod_derivative_indicator'
        code_col = 'S_INFO_WINDCODE'
        res = self._get_time_list_cross_sectional_factory_cache(redis_name, code_col, get_info_func, trade_date,
                                                                stock_code)
        return res


if __name__ == '__main__':
    import time

    market_reader = MarketReaderCache()  # 推荐项目中构建数据读取单例
    begin = time.time()
    res = market_reader.get_china_mutual_fund_issue_name_cache("000001.OF")  # 获取全部交易日期
    print(time.time() - begin)
    print(res)
