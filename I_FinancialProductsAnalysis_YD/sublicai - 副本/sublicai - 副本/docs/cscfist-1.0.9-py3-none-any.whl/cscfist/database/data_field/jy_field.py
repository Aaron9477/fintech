# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/8/31 11:12
# @Author  : wangxybjs
# @File    : jy_field.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from sqlalchemy import Column, VARCHAR, Numeric, TEXT, Index, Date, Float, BIGINT, Integer
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class MF_INVESTINDUSTRY(Base):
    """公募基金行业投资"""
    __tablename__ = 'MF_InvestIndustry'
    ID = Column(Numeric(19), primary_key=True, comment='ID')
    InnerCode = Column(Numeric(10), comment='基金内部编码')
    TransCode = Column(Numeric(10), comment='基金转型统一编码')
    InfoPublDate = Column(Date, comment='信息发布日期')
    ReportDate = Column(Date, comment='报告期')
    InvestType = Column(Numeric(10), comment='投资类型')
    InduStandard = Column(Numeric(10), comment='行业划分标准')
    IndustryCode = Column(Numeric(10), comment='行业代码')
    InduDiscCode = Column(VARCHAR(10), comment='行业代码(公布)')
    IndustryName = Column(VARCHAR(50), comment='行业名称')
    MarketValue = Column(Numeric(19, 4), comment='行业市值(元)')
    RatioInNV = Column(Numeric(18, 6), comment='占资产净值比例')
    InsertTime = Column(Date, comment='插入时间')
    XGRQ = Column(Date, comment='修改日期')
    JSID = Column(Numeric(19), comment='JSID')


class SECUMAIN(Base):
    """证券主表"""
    __tablename__ = 'SecuMain'
    ID = Column(Numeric(19), primary_key=True, comment='ID')
    InnerCode = Column(Numeric(10), comment='证券内部编码')
    CompanyCode = Column(Numeric(10), comment='公司代码')
    SecuCode = Column(VARCHAR(30), comment='证券代码')
    ChiName = Column(VARCHAR(200), comment='中文名称')
    ChiNameAbbr = Column(VARCHAR(100), comment='中文名称缩写')
    EngName = Column(VARCHAR(200), comment='英文名称')
    EngNameAbbr = Column(VARCHAR(50), comment='英文名称缩写')
    SecuAbbr = Column(VARCHAR(100), comment='证券简称')
    ChiSpelling = Column(VARCHAR(50), comment='拼音证券简称')
    ExtendedAbbr = Column(VARCHAR(100), comment='扩位简称')
    ExtendedSpelling = Column(VARCHAR(50), comment='拼音扩位简称')
    SecuMarket = Column(Numeric(10), comment='证券市场')
    SecuCategory = Column(Numeric(10), comment='证券类别')
    ListedDate = Column(Date, comment='上市日期')
    ListedSector = Column(Numeric(10), comment='上市板块')
    ListedState = Column(Numeric(10), comment='上市状态')
    ISIN = Column(VARCHAR(20), comment='ISIN代码')
    XGRQ = Column(Date, comment='修改日期')
    JSID = Column(Numeric(19), comment='JSID')


class CT_SystemConst(Base):
    """系统常量表"""
    __tablename__ = 'CT_SystemConst'
    ID = Column(Numeric(19), primary_key=True, comment='ID')
    LB = Column(Numeric(10), primary_key=True, comment='常量分类编码')
    LBMC = Column(VARCHAR(50), primary_key=True, comment='常量分类名称')
    MS = Column(VARCHAR(300), primary_key=True, comment='常量描述')
    DM = Column(Numeric(10), primary_key=True, comment='常量代码')
    CVALUE = Column(VARCHAR(2000), primary_key=True, comment='字符值')
    DVALUE = Column(Date, primary_key=True, comment='日期值')
    FVALUE = Column(Float, comment='浮点值')
    IVALUE = Column(Numeric(10), comment='整型值')
    XGRQ = Column(Date, comment='修改日期')
    JSID = Column(Numeric(19), comment='JSID')


class QT_IndexQuote(Base):
    """指数行情"""
    __tablename__ = 'QT_INDEXQUOTE'
    ID = Column(Numeric(19), primary_key=True, comment='ID')
    InnerCode = Column(Numeric(10), primary_key=True, comment='证券内部编码')
    TradingDay = Column(Date, primary_key=True, comment='交易日')
    PrevClosePrice = Column(Numeric(19, 4), comment='昨收盘(元)')
    OpenPrice = Column(Numeric(19, 4), comment='今开盘(元)')
    HighPrice = Column(Numeric(19, 4), comment='最高价(元)')
    LowPrice = Column(Numeric(19, 4), comment='最低价(元)')
    ClosePrice = Column(Numeric(19, 4), comment='收盘价(元)')
    TurnoverVolume = Column(Numeric(19, 2), comment='成交量(股)')
    TurnoverValue = Column(Numeric(19, 4), comment='成交金额(元)')
    TurnoverDeals = Column(Numeric(10), comment='成交笔数(笔)')
    ChangePCT = Column(Numeric(19, 8), comment='涨跌幅')
    XGRQ = Column(Date, comment='修改日期')
    JSID = Column(Numeric(19), comment='JSID')
    NegotiableMV = Column(Numeric(19, 4), comment='流通市值')


class LC_SHSCTradeStat(Base):
    """沪港通交易统计"""
    __tablename__ = 'LC_SHSCTradeStat'
    ID = Column(Numeric(19), primary_key=True, comment='ID')
    ReportPeriod = Column(Numeric(10), primary_key=True, comment='报告周期')
    EndDate = Column(Date, primary_key=True, comment='日期')
    TradingType = Column(Numeric(10), primary_key=True, comment='交易方向')
    IfAdjusted = Column(Numeric(10), primary_key=True, comment='是否调整')
    Currency = Column(Numeric(10), comment='货币单位')
    BTradeValue = Column(Numeric(18, 2), comment='买入金额(元)')
    BTradeAmount = Column(Numeric(18, 2), comment='买入成交数目')
    STradeValue = Column(Numeric(18, 2), comment='卖出金额(元)')
    STradeAmount = Column(Numeric(18, 2), comment='卖出成交数目')
    BTradeValue_DA = Column(Numeric(18, 2), comment='日均买入成交额(元)')
    BTradeAmount_DA = Column(Numeric(18, 2), comment='日均买入成交数目')
    STradeValue_DA = Column(Numeric(18, 2), comment='日均卖出成交额(元)')
    STradeAmount_DA = Column(Numeric(18, 2), comment='日均卖出成交数目')
    BTradeValueChange = Column(Numeric(18, 4), comment='买入成交额增减(%)')
    BTradeValueChange_DA = Column(Numeric(18, 4), comment='日均买入成交额增减(%)')
    BTradeAmountChange = Column(Numeric(18, 4), comment='买入成交数目增减(%)')
    BTradeAmountChange_DA = Column(Numeric(18, 4), comment='日均买入成交数目增减(%)')
    STradeValueChange = Column(Numeric(18, 4), comment='卖出成交额增减(%)')
    STradeValueChange_DA = Column(Numeric(18, 4), comment='日均卖出成交额增减(%)')
    STradeAmountChange = Column(Numeric(18, 4), comment='卖出成交数目增减(%)')
    STradeAmountChange_DA = Column(Numeric(18, 4), comment='日均卖出成交数目增减(%)')
    UpdateTime = Column(Date, comment='更新时间')
    JSID = Column(Numeric(19), comment='JSID')
    InsertTime = Column(Date, comment='发布时间')


class LC_ZHSCTradeStat(Base):
    """深港通交易统计"""
    __tablename__ = 'LC_ZHSCTradeStat'
    ID = Column(Numeric(19), primary_key=True, comment='ID')
    ReportPeriod = Column(Numeric(10), primary_key=True, comment='报告周期')
    EndDate = Column(Date, primary_key=True, comment='日期')
    TradingType = Column(Numeric(10), primary_key=True, comment='交易方向')
    IfAdjusted = Column(Numeric(10), primary_key=True, comment='是否调整')
    Currency = Column(Numeric(10), comment='货币单位')
    BTradeValue = Column(Numeric(19, 4), comment='买入金额(元)')
    BTradeAmount = Column(Numeric(18, 2), comment='买入成交数目')
    STradeValue = Column(Numeric(19, 4), comment='卖出金额(元)')
    STradeAmount = Column(Numeric(18, 2), comment='卖出成交数目')
    BTradeValue_DA = Column(Numeric(19, 4), comment='日均买入成交额(元)')
    BTradeAmount_DA = Column(Numeric(18, 2), comment='日均买入成交数目')
    STradeValue_DA = Column(Numeric(19, 4), comment='日均卖出成交额(元)')
    STradeAmount_DA = Column(Numeric(18, 2), comment='日均卖出成交数目')
    BTradeValueChange = Column(Numeric(18, 4), comment='买入成交额增减(%)')
    BTradeValueChange_DA = Column(Numeric(18, 4), comment='日均买入成交额增减(%)')
    BTradeAmountChange = Column(Numeric(18, 4), comment='买入成交数目增减(%)')
    BTradeAmountChange_DA = Column(Numeric(18, 4), comment='日均买入成交数目增减(%)')
    STradeValueChange = Column(Numeric(18, 4), comment='卖出成交额增减(%)')
    STradeValueChange_DA = Column(Numeric(18, 4), comment='日均卖出成交额增减(%)')
    STradeAmountChange = Column(Numeric(18, 4), comment='卖出成交数目增减(%)')
    STradeAmountChange_DA = Column(Numeric(18, 4), comment='日均卖出成交数目增减(%)')
    UpdateTime = Column(Date, comment='更新时间')
    JSID = Column(Numeric(19), comment='JSID')
    InsertTime = Column(Date, comment='发布时间')


class LC_CorrIndexIndustry(Base):
    """指数与行业对应"""
    __tablename__ = 'LC_CorrIndexIndustry'
    ID = Column(Numeric(19), primary_key=True, comment='ID')
    IndexCode = Column(Numeric(10), primary_key=True, comment='指数代码')
    IndustryStandard = Column(Numeric(10), comment='行业标准')
    IndustryCode = Column(Numeric(10), comment='所属行业代码')
    EndDate = Column(Date, comment='日期')
    IndexState = Column(Numeric(10), comment='指数状态')
    UpdateTime = Column(Date, comment='更新时间')
    JSID = Column(Numeric(19), comment='JSID')


class CT_IndustryType(Base):
    """行业类别表"""
    __tablename__ = 'CT_IndustryType'
    ID = Column(Numeric(19), primary_key=True, comment='ID')
    Standard = Column(Numeric(10), primary_key=True, comment='行业分类标准')
    IndustryNum = Column(Numeric(19), comment='行业编码')
    Classification = Column(Numeric(10), comment='行业级别')
    IndustryCode = Column(VARCHAR(20), comment='所属行业代码')
    IndustryName = Column(VARCHAR(50), comment='行业名称')
    SectorCode = Column(Numeric(10), comment='行业板块编码')
    UpdateTime = Column(Date, comment='更新时间')
    JSID = Column(Numeric(19), comment='JSID')
    FirstIndustryCode = Column(VARCHAR(20), comment='对应一级行业代码')
    FirstIndustryName = Column(VARCHAR(100), comment='对应一级行业名称')
    SecondIndustryCode = Column(VARCHAR(20), comment='对应二级行业代码')
    SecondIndustryName = Column(VARCHAR(100), comment='对应二级行业名称')
    ThirdIndustryCode = Column(VARCHAR(20), comment='对应三级行业代码')
    ThirdIndustryName = Column(VARCHAR(100), comment='对应三级行业名称')
    FourthIndustryCode = Column(VARCHAR(20), comment='对应四级行业代码')
    FourthIndustryName = Column(VARCHAR(100), comment='对应四级行业名称')
    IndustryNameE = Column(VARCHAR(200), comment='行业英文名称')
    EffectiveDate = Column(Date, comment='生效日期')
    CancelDate = Column(Date, comment='取消日期')
    IfEffected = Column(Numeric(10), comment='是否有效')


class MF_IncomeStatementNew(Base):
    """公募基金利润表_新会计准则"""
    __tablename__ = 'MF_IncomeStatementNew'
    ID = Column(BIGINT, comment="ID", primary_key=True)
    InfoPublDate = Column(Date, comment="信息发布日期")
    InfoSource = Column(VARCHAR(100), comment="信息来源")
    BulletinType = Column(Integer, comment="公告类别")
    InnerCode = Column(Integer, comment="证券内部编码")
    CompanyCode = Column(Integer, comment="公司代码")
    EndDate = Column(Date, comment="日期")
    Mark = Column(Integer, comment="备注说明")
    AccountingStandards = Column(Integer, comment="会计准则")
    InterestIncome = Column(Numeric(19, 4), comment="其中:利息收入(元)")
    DepositInterestIncome = Column(Numeric(19, 4), comment="存款利息收入(元)")
    BondInterestIncome = Column(Numeric(19, 4), comment="取得债券利息收入所收到的现金(元)")
    ABSInterestIncome = Column(Numeric(19, 4), comment="资产支持证券利息收入")
    SellbackAssetsIncome = Column(Numeric(19, 4), comment="买入返售金融资产收入")
    OtherInterestIncome = Column(Numeric(19, 4), comment="其他利息收入")
    InvestmentIncome = Column(Numeric(19, 4), comment="投资收益(元)")
    StockInvestmentIncome = Column(Numeric(19, 4), comment="其中：股票投资收益")
    BondInvestmentIncome = Column(Numeric(19, 4), comment="债券投资收益")
    ABSInvestmentIncome = Column(Numeric(19, 4), comment="资产支持证券投资收益")
    DerivativeInvestIncome = Column(Numeric(19, 4), comment="衍生工具收益")
    DividendIncome = Column(Numeric(19, 4), comment="　股利收入(元)")
    OtherInvestmentIncome = Column(Numeric(19, 4), comment="　其他投资收益(元)")
    FairValueChangeIncome = Column(Numeric(19, 4), comment="公允价值变动净收益")
    OtherIncome = Column(Numeric(19, 4), comment="其他收入(元)")
    IncomeExceptionalItems = Column(Numeric(19, 4), comment="##收入特殊项目")
    IncomeAdjustmentItems = Column(Numeric(19, 4), comment="##收入调整项目")
    TotalRevenue = Column(Numeric(19, 4), comment="收入合计")
    MangementExpense = Column(Numeric(19, 4), comment="1.管理人报酬")
    TrusteeExpense = Column(Numeric(19, 4), comment="2.托管费")
    SaleExpense = Column(Numeric(19, 4), comment="销售费用(元)")
    TransactionExpense = Column(Numeric(19, 4), comment="4.交易费用")
    InterestExpense = Column(Numeric(19, 4), comment="其中:利息支出(元)")
    SoldRepoSecuExpense = Column(Numeric(19, 4), comment="卖出回购证券支出(元)")
    OtherExpense = Column(Numeric(19, 4), comment="其他费用(元)")
    ExpenseExceptionalItems = Column(Numeric(19, 4), comment="##费用特殊项目")
    ExpenseAdjustmentItems = Column(Numeric(19, 4), comment="##费用调整项目")
    TotalExpense = Column(Numeric(19, 4), comment="费用合计(元)")
    PastProfitAndLoss = Column(Numeric(19, 4), comment="(净收益)以前年度损益调整")
    ProfitExceptionalItems = Column(Numeric(19, 4), comment="##利润特殊项目")
    ProfitAdjustmentItems = Column(Numeric(19, 4), comment="##利润调整项目")
    TotalProfit = Column(Numeric(19, 4), comment="利润总额(元)")
    SpecialFieldRemark = Column(VARCHAR(1000), comment="特殊字段说明")
    UpdateTime = Column(Date, comment="更新时间")
    JSID = Column(BIGINT, comment="JSID")
    StartDate = Column(Date, comment="起始日期")
    FundInvestIncome = Column(Numeric(19, 4), comment="基金投资收益")
    ExchangeIncome = Column(Numeric(19, 4), comment="4.汇兑收益")
    RmetalInvestmentIncome = Column(Numeric(19, 4), comment="贵金属投资收益")
    TaxSurcharges = Column(Numeric(19, 4), comment="6.税金及附加")
    IncomeTaxCost = Column(Numeric(19, 4), comment="减:所得税费用")
    NetProfit = Column(Numeric(19, 4), comment="净利润")
    InsertTime = Column(Date, comment="插入时间")
    TransCode = Column(Integer, comment="基金转型统一编码")


class MF_FundsReference(Base):
    """公募基金附注"""
    __tablename__ = 'MF_FundsReference'
    ID = Column(BIGINT, comment="ID", primary_key=True)
    InnerCode = Column(Integer, comment="证券内部编码")
    CompanyCode = Column(Integer, comment="公司代码")
    EndDate = Column(Date, comment="日期")
    InfoSource = Column(VARCHAR(50), comment="信息来源")
    ReportPeriod = Column(Integer, comment="报告周期")
    Mark = Column(Integer, comment="备注说明")
    FinancialItemCode = Column(Integer, comment="财务科目代码")
    FinancialItem = Column(VARCHAR(200), comment="财务科目")
    ProjectCode = Column(Integer, comment="明细科目代码")
    ProjectName = Column(VARCHAR(200), comment="明细科目")
    CurrencyUnit = Column(Integer, comment="货币单位")
    OpeningBalance = Column(Numeric(19, 4), comment="1.期初金额(元)")
    EndingBalance = Column(Numeric(19, 4), comment="4.期末金额(元)")
    OpeningCost = Column(Numeric(19, 4), comment="期初成本")
    EndingCost = Column(Numeric(19, 4), comment="期末成本")
    Remarks = Column(VARCHAR(500), comment="备注")
    UpdateTime = Column(Date, comment="更新时间")
    JSID = Column(BIGINT, comment="JSID")
    InsertTime = Column(Date, comment="插入时间")
    TransCode = Column(Integer, comment="基金转型统一编码")


class MF_NVChange(Base):
    """公募基金净值变动"""
    __tablename__ = 'MF_NVChange'
    ID = Column(BIGINT, comment="ID", primary_key=True)
    InnerCode = Column(Integer, comment="证券内部编码")
    ReportDate = Column(Numeric(19, 4), comment="报告期")
    NVAtBegin = Column(Numeric(19, 4), comment="期初基金净值(元)")
    NetProfit = Column(Numeric(19, 4), comment="基金净收益(元)")
    UnrealizedProfitChange = Column(Numeric(19, 4), comment="未实现估值增值变动数(元)")
    NVChangeDueToOperating = Column(Numeric(19, 4), comment="经营活动产生的基金净值变动数(元)")
    ApplyingMoney = Column(Numeric(19, 4), comment="基金申购款(元)")
    RedemptionMoney = Column(Numeric(19, 4), comment="基金赎回款(元)")
    NVChangeDueToUnitTrade = Column(Numeric(19, 4), comment="基金单位交易产生的基金净值变动数(元)")
    DistributedProfit = Column(Numeric(19, 4), comment="本期向持有人分配收益(元)")
    NVAtEnd = Column(Numeric(19, 4), comment="期末基金净值(元)")
    PriorYearProfitAdjust = Column(Numeric(19, 4), comment="以前年度损益调整")
    XGRQ = Column(Numeric(19, 4), comment="更新日期")
    JSID = Column(Numeric(19, 4), comment="JSID")
