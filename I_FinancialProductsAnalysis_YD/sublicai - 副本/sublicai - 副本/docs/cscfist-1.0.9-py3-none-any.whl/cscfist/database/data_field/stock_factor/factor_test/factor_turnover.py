# -*- coding: utf-8 -*-
from sqlalchemy import Column, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.types import VARCHAR, Integer, Numeric, BIGINT

from cscfist.tools.generate_id import generate_update_time

Base = declarative_base()


class FactorTurnoverRateDaily(Base):
    __tablename__ = 'factor_turnover_rate_daily'

    id = Column(BIGINT, autoincrement=True, primary_key=True)
    factor_id = Column(VARCHAR(200), nullable=True, comment='因子ID')
    pool_id = Column(VARCHAR(200), nullable=True, comment='股票池ID')
    period = Column(Integer, comment='周期')
    factor_group = Column(VARCHAR(20), comment='因子组别')
    trade_date = Column(VARCHAR(8), nullable=True, comment='日期')
    turnover = Column(Numeric(20, 6), comment='换手率')
    __table_args__ = (
        Index('turnover_factor_pool_id_cal_begin_end_date', "factor_id", "pool_id", "trade_date"),
        {'comment': '每日换手率'},)


class FactorTurnoverRateStat(Base):
    __tablename__ = 'factor_turnover_rate_stat'

    id = Column(BIGINT, autoincrement=True, primary_key=True)
    factor_id = Column(VARCHAR(200), nullable=True, comment='因子ID')
    pool_id = Column(VARCHAR(200), nullable=True, comment='股票池ID')
    cal_date = Column(VARCHAR(8), default=generate_update_time("%Y%m%d"), comment='计算日期')
    update_time = Column(VARCHAR(20), default=generate_update_time, comment='更新时间')
    interval = Column(VARCHAR(20), comment='时间区间')
    begin_date = Column(VARCHAR(20), comment='开始时间')
    end_date = Column(VARCHAR(20), comment='结束时间')
    period = Column(Integer, comment='周期')
    factor_group = Column(VARCHAR(20), comment='因子组别')
    turnover_mean = Column(Numeric(20, 6), comment='换手率均值')
    __table_args__ = (
        Index('turnover_factor_pool_id_cal_begin_end_date', "factor_id", "pool_id", "cal_date", "begin_date", "end_date"),
        {'comment': '换手率分析统计'},)


def create_table(connection):
    Base.metadata.create_all(connection.engine)