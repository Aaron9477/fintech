# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/1/11 17:30
# @Author  : wangxybjs
# @File    : factor_back_test.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------

from sqlalchemy import Column, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.types import VARCHAR, Numeric, Integer, BIGINT

from cscfist.tools.generate_id import generate_update_time

Base = declarative_base()


class GroupBackTestDaily(Base):
    __tablename__ = 'group_backtest_daily'

    id = Column(BIGINT, autoincrement=True, primary_key=True)
    factor_id = Column(VARCHAR(200), nullable=True, comment='因子ID')
    pool_id = Column(VARCHAR(200), nullable=True, comment='股票池ID')
    trade_date = Column(VARCHAR(20), comment='交易日期')
    period = Column(Integer, comment='周期')
    stock_group = Column(VARCHAR(20), nullable=True, comment='股票分组')
    factor_group = Column(VARCHAR(20), comment='因子组别')
    total_profit = Column(Numeric(20, 6), comment='累积收益率')
    __table_args__ = (
        Index('daily_factor_condition_id_date', "factor_id", "pool_id", "trade_date"),
        {'comment': '回测分析--回测日频表现表'},)


class GroupBenchmarkBackTestDaily(Base):
    __tablename__ = 'group_benchmark_backtest_daily'
    id = Column(BIGINT, autoincrement=True, primary_key=True)
    benchmark_code = Column(VARCHAR(200), nullable=True, comment='基准ID')
    trade_date = Column(VARCHAR(20), comment='交易日期')
    benchmark_total_return = Column(Numeric(20, 6), comment='基准累计收益率')
    __table_args__ = (
        Index('benchmark_daily_benchmark_code_trade_date', "benchmark_code", "trade_date"),
        {'comment': '回测分析--基准回测日频表现表'},)


class GroupBackTestAccumulativeReturn(Base):
    __tablename__ = 'group_backtest_accumulative_return'
    id = Column(BIGINT, autoincrement=True, primary_key=True)
    factor_id = Column(VARCHAR(200), nullable=True, comment='因子ID')
    pool_id = Column(VARCHAR(200), nullable=True, comment='股票池ID')
    # begin_date = Column(VARCHAR(20), comment='分析开始时间')
    # end_date = Column(VARCHAR(20), comment='分析结束时间')
    trade_date = Column(VARCHAR(20), comment='交易日期')
    period = Column(Integer, comment='周期')
    stock_group = Column(VARCHAR(20), nullable=True, comment='股票分组')
    factor_group = Column(VARCHAR(20), comment='因子组别')
    total_profit = Column(Numeric(20, 6), comment='累积收益率')
    __table_args__ = (
        Index('return_factor_pool_id_trade_date', "factor_id", "pool_id","trade_date"),
        {'comment': '回测分析--每日累积收益率'},)


class GroupBackTestBenchmarkAccumulativeReturn(Base):
    __tablename__ = 'group_backtest_benchmark_accumulative_return'
    id = Column(BIGINT, autoincrement=True, primary_key=True)
    benchmark_code = Column(VARCHAR(200), nullable=True, comment='基准ID')
    # begin_date = Column(VARCHAR(20), comment='分析开始时间')
    # end_date = Column(VARCHAR(20), comment='分析结束时间')
    trade_date = Column(VARCHAR(20), comment='交易日期')
    benchmark_total_return = Column(Numeric(20, 6), comment='基准累计收益率')
    __table_args__ = (
        Index('bm_return_benchmark_code_date', "benchmark_code", "trade_date"),
        {'comment': '回测分析--基准每日累积收益率'},)


class GroupBackTestResultStat(Base):
    __tablename__ = 'group_backtest_result_stat'
    id = Column(BIGINT, autoincrement=True, primary_key=True)
    factor_id = Column(VARCHAR(200), nullable=True, comment='因子ID')
    benchmark_code = Column(VARCHAR(200), nullable=True, comment='基准代码')
    pool_id = Column(VARCHAR(200), nullable=True, comment='股票池ID')
    cal_date = Column(VARCHAR(20), default=generate_update_time("%Y%m%d"), comment='计算日期')
    update_time = Column(VARCHAR(20), default=generate_update_time, comment='更新时间')
    interval = Column(VARCHAR(20), comment='时间区间')
    begin_date = Column(VARCHAR(20), comment='分析开始时间')
    end_date = Column(VARCHAR(20), comment='分析结束时间')
    period = Column(Integer, comment='周期')
    group_num = Column(VARCHAR(30), nullable=True, comment='组别')
    interval_return = Column(Numeric(20, 6), comment='累积收益率')
    annual_return = Column(Numeric(20, 6), comment='年化收益率')
    volatility = Column(Numeric(20, 6), comment='年化波动率')
    max_draw_down = Column(Numeric(20, 6), comment='最大回撤')
    max_draw_down_begin_date = Column(Numeric(20, 6), comment='最大回撤开始时间')
    max_draw_down_end_date = Column(Numeric(20, 6), comment='最大回撤结束时间')
    sharpe = Column(Numeric(20, 6), comment='夏普比率')
    information_ratio = Column(Numeric(20, 6), comment='信息比率')
    excess_return = Column(Numeric(20, 6), comment='超额收益率')
    excess_annual_return = Column(Numeric(20, 6), comment='超额年化收益率')
    __table_args__ = (
        Index('count_factor_pool_id_begin_end_date', "factor_id", "pool_id", "begin_date", "end_date"),
        {'comment': '回测分析--单组回测统计'},)


class GroupBackTestBenchmarkResultStat(Base):
    __tablename__ = 'group_backtest_benchmark_result_stat'
    id = Column(BIGINT, autoincrement=True, primary_key=True)
    benchmark_code = Column(VARCHAR(200), nullable=True, comment='基准代码')
    cal_date = Column(VARCHAR(20), default=generate_update_time("%Y%m%d"), comment='计算日期')
    update_time = Column(VARCHAR(20), default=generate_update_time, comment='更新时间')
    interval = Column(VARCHAR(20), comment='时间区间')
    begin_date = Column(VARCHAR(20), comment='分析开始时间')
    end_date = Column(VARCHAR(20), comment='分析结束时间')
    benchmark_return = Column(Numeric(20, 6), comment='基准累计收益率')
    benchmark_annual_return = Column(Numeric(20, 6), comment='基准年化收益率')
    benchmark_volatility = Column(Numeric(20, 6), comment='基准年化波动率')
    benchmark_max_draw_down = Column(Numeric(20, 6), comment='基准最大回撤')
    benchmark_max_draw_down_begin_date = Column(Numeric(20, 6), comment='基准最大回撤开始时间')
    benchmark_max_draw_down_end_date = Column(Numeric(20, 6), comment='基准最大回撤结束时间')
    benchmark_sharpe = Column(Numeric(20, 6), comment='基准夏普比率')
    __table_args__ = (
        Index('bm_count_benchmark_code_begin_end_date', "benchmark_code", "begin_date", "end_date"),
        {'comment': '回测分析--基准回测统计'},)


def create_table(connection):
    Base.metadata.create_all(connection.engine)
