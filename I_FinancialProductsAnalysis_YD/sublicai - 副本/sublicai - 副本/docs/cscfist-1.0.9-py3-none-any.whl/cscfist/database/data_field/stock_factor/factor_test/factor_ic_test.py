# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/1/10 17:23
# @Author  : wangxybjs
# @File    : factor_ic_test.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------
from sqlalchemy import Column, Index, UniqueConstraint
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.types import VARCHAR, Numeric, Integer, NUMERIC, BIGINT

from cscfist.tools.generate_id import generate_update_time

Base = declarative_base()


class FactorIcTestDaily(Base):
    __tablename__ = 'factor_ic_test_daily'

    id = Column(BIGINT, autoincrement=True, primary_key=True)
    factor_id = Column(VARCHAR(200), nullable=True, comment='因子ID')
    pool_id = Column(VARCHAR(200), nullable=True, comment='股票池ID')
    trade_date = Column(VARCHAR(8), nullable=True, comment='日期')
    period = Column(Integer, comment='周期')
    is_accumulative_return = Column(Integer, comment='收益率是否累积')
    normal_ic = Column(Numeric(20, 6), comment='普通相关系数')
    rank_ic = Column(Numeric(20, 6), comment='秩相关系数')
    __table_args__ = (
        Index('ic_d_id_date_pool_period', "factor_id", "trade_date", "pool_id", "period"),
        UniqueConstraint("factor_id", "pool_id", "trade_date", "period", "is_accumulative_return",
                         name="ic_d_id_pool_date_period_accumulate"), {'comment': 'IC检验--IC值'},)


class FactorIcTestAccumulative(Base):
    __tablename__ = "factor_ic_test_accumulative"
    id = Column(BIGINT, autoincrement=True, primary_key=True)
    factor_id = Column(VARCHAR(200), nullable=True, comment='因子ID')
    pool_id = Column(VARCHAR(200), nullable=True, comment='股票池ID')
    cal_date = Column(VARCHAR(8), default=generate_update_time("%Y%m%d"), comment='计算日期')
    update_time = Column(VARCHAR(20), default=generate_update_time, comment='更新时间')
    begin_date = Column(VARCHAR(20), comment='开始时间')
    end_date = Column(VARCHAR(20), comment='结束时间')
    trade_date = Column(VARCHAR(8), nullable=True, comment='交易日期')
    period = Column(Integer, comment='周期')
    normal_ic_accumulative = Column(NUMERIC(20, 6), comment='累积普通IC')
    rank_ic_accumulative = Column(NUMERIC(20, 6), comment='累积RankIC')
    sign = Column(Integer, default=2, comment='最新标志')
    __table_args__ = (
        Index('ic_accumulative_id_begin_end_date_pool_period', "factor_id", "begin_date", "end_date", "pool_id",
              "period"), {'comment': 'IC检验--累积IC'},)


class FactorIcTestStat(Base):
    __tablename__ = 'factor_ic_test_stat'
    id = Column(BIGINT, autoincrement=True, primary_key=True)
    factor_id = Column(VARCHAR(200), nullable=True, comment='因子ID')
    pool_id = Column(VARCHAR(200), nullable=True, comment='股票池ID')
    cal_date = Column(VARCHAR(8), default=generate_update_time("%Y%m%d"), comment='计算日期')
    update_time = Column(VARCHAR(20), default=generate_update_time, comment='更新时间')
    interval = Column(VARCHAR(20), comment='时间区间')
    begin_date = Column(VARCHAR(20), comment='开始时间')
    end_date = Column(VARCHAR(20), comment='结束时间')
    period = Column(Integer, comment='周期')
    normal_ic_mean = Column(NUMERIC(20, 6), comment='普通IC均值')
    normal_ic_std = Column(NUMERIC(20, 6), comment='普通IC标准差')
    normal_ic_ir = Column(NUMERIC(20, 6), comment='普通ICIR')
    large_abs_normal_ic_ratio = Column(NUMERIC(20, 6), comment='普通IC绝对值大于2的比例')
    normal_ic_pos_ratio = Column(NUMERIC(20, 6), comment='普通IC正向比例')
    normal_ic_neg_ratio = Column(NUMERIC(20, 6), comment='普通IC负向比例')
    large_normal_ic_pos_ratio = Column(NUMERIC(20, 6), comment='普通IC大于2的比例')
    large_normal_ic_neg_ratio = Column(NUMERIC(20, 6), comment='普通IC小于-2的比例')
    normal_ic_same_direction_ratio = Column(NUMERIC(20, 6), comment='普通IC同向比例')
    normal_ic_reverse_ratio = Column(NUMERIC(20, 6), comment='普通IC反向比例')
    rank_ic_mean = Column(NUMERIC(20, 6), comment='RankIC均值')
    rank_ic_std = Column(NUMERIC(20, 6), comment='RankIC标准差')
    rank_ic_ir = Column(NUMERIC(20, 6), comment='RankICIR')
    large_abs_rank_ic_ratio = Column(NUMERIC(20, 6), comment='RankIC均值绝对值大于2的比例')
    rank_ic_pos_ratio = Column(NUMERIC(20, 6), comment='RankIC正向比例')
    rank_ic_neg_ratio = Column(NUMERIC(20, 6), comment='RankIC负向比例')
    large_rank_ic_pos_ratio = Column(NUMERIC(20, 6), comment='RankIC大于2的比例')
    large_rank_ic_neg_ratio = Column(NUMERIC(20, 6), comment='RankIC小于-2的比例')
    rank_ic_same_direction_ratio = Column(NUMERIC(20, 6), comment='RankIC同向比例')
    rank_ic_reverse_ratio = Column(NUMERIC(20, 6), comment='RankIC反向比例')
    __table_args__ = (
        Index('ic_s_id_begin_end_date_pool_period', "factor_id", "begin_date", "end_date", "pool_id", "period"),
        UniqueConstraint("factor_id", "begin_date", "end_date", "pool_id", "period",
                         name="unique_ic_s_id_begin_end_date_pool_period"), {'comment': 'IC检验--IC统计'},)


class FactorIcTestDecay(Base):
    __tablename__ = 'factor_ic_test_decay'

    id = Column(BIGINT, autoincrement=True, primary_key=True)
    factor_id = Column(VARCHAR(200), nullable=True, comment='因子ID')
    pool_id = Column(VARCHAR(200), nullable=True, comment='股票池ID')
    cal_date = Column(VARCHAR(8), default=generate_update_time("%Y%m%d"), comment='计算日期')
    update_time = Column(VARCHAR(20), default=generate_update_time, comment='更新时间')
    begin_date = Column(VARCHAR(20), comment='开始时间')
    end_date = Column(VARCHAR(20), comment='结束时间')
    period = Column(Integer, nullable=True, comment='周期')
    ic_value = Column(NUMERIC(20, 6), comment='普通IC值')
    rank_ic = Column(NUMERIC(20, 6), comment='RankIC值')
    sign = Column(Integer, default=2, comment='最新标志')
    __table_args__ = (
        Index('ic_decay_id_begin_end_date_pool_period', "factor_id", "begin_date", "end_date", "pool_id", "period"),
        UniqueConstraint("factor_id", "begin_date", "end_date", "pool_id", "period",
                         name="unique_ic_decay_id_begin_end_date_pool_period"), {'comment': 'IC检验--IC统计'},)


def create_table(connection):
    Base.metadata.create_all(connection.engine)