from sqlalchemy import Column, Index, DECIMAL, UniqueConstraint, BigInteger, DATETIME, INTEGER
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.types import VARCHAR, String

from cscfist import NatureDateUtils
from cscfist.tools import generate_id

Base = declarative_base()


class StrategyPerformance(Base):
    """
    策略表现
    """
    __tablename__ = 'strategy_performance'
    id = Column(BigInteger, autoincrement=True, primary_key=True)
    contest_id = Column(INTEGER, nullable=True, comment="大赛ID")
    user_id = Column(VARCHAR(30), nullable=True, comment="用户ID")
    alpha = Column(DECIMAL(30, 4), comment="Alpha")
    beta = Column(DECIMAL(30, 4), comment="Beta")
    sharpe = Column(DECIMAL(30, 4), comment="夏普比率")
    excess_sharpe = Column(DECIMAL(30, 4), comment="超额夏普")
    information_ratio = Column(DECIMAL(30, 4), comment="信息比率")
    downside_risk = Column(DECIMAL(30, 4), comment="下行风险")
    tracking_error = Column(DECIMAL(30, 4), comment="跟踪误差")
    sortino = Column(DECIMAL(30, 4), comment="索提诺比率")
    volatility = Column(DECIMAL(30, 4), comment="波动率")
    excess_volatility = Column(DECIMAL(30, 4), comment="超额波动率")
    excess_annual_volatility = Column(DECIMAL(30, 4), comment="超额年化波动率")
    max_drawdown = Column(DECIMAL(30, 4), comment="最大回撤")
    excess_max_drawdown = Column(DECIMAL(30, 4), comment="超额最大回撤")
    excess_returns = Column(DECIMAL(30, 4), comment="超额收益率")
    excess_annual_returns = Column(DECIMAL(30, 4), comment="超额年化收益率")
    total_returns = Column(DECIMAL(30, 4), comment="总收益率")
    annualized_returns = Column(DECIMAL(30, 4), comment="年化收益率")
    benchmark_total_returns = Column(DECIMAL(30, 4), comment="基准总收益率")
    benchmark_annualized_returns = Column(DECIMAL(30, 4), comment="基准年化收益率")
    weekly_alpha = Column(DECIMAL(30, 4), comment="周度Alpha")
    weekly_beta = Column(DECIMAL(30, 4), comment="周度Beta")
    weekly_sharpe = Column(DECIMAL(30, 4), comment="周度夏普")
    weekly_sortino = Column(DECIMAL(30, 4), comment="周度索提诺比率")
    weekly_information_ratio = Column(DECIMAL(30, 4), comment="周度信息比率")
    weekly_tracking_error = Column(DECIMAL(30, 4), comment="周度跟踪误差")
    weekly_max_drawdown = Column(DECIMAL(30, 4), comment="周度最大回撤")

    cal_date = Column(VARCHAR(30), default=NatureDateUtils.get_cur_date, nullable=True, comment="计算日期")
    update_time = Column(VARCHAR(30), default=NatureDateUtils.get_cur_time, nullable=True, comment="更新时间")
    __table_args__ = (Index('index_strategy_performance', "contest_id", "user_id"),
                      UniqueConstraint("contest_id", "user_id", name="strategy_performance_contest_user"),
                      {'comment': '策略表现'},)


class ProfitHis(Base):
    """
    策略净值
    """
    __tablename__ = 'profit_his'
    id = Column(BigInteger, autoincrement=True, primary_key=True)
    contest_id = Column(VARCHAR(30), nullable=True, comment="大赛ID")
    user_id = Column(VARCHAR(30), nullable=True, comment="用户ID")
    trd_date = Column(VARCHAR(8), comment="交易日")
    total_return = Column(DECIMAL(30, 4), comment="净值")

    create_time = Column(DATETIME)
    update_time = Column(DATETIME)


def create_table(connection):
    Base.metadata.create_all(connection.engine)
