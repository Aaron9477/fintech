# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/1/11 17:44
# @Author  : wangxybjs
# @File    : fund_basic.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------

from sqlalchemy import Column, Index, BIGINT, UniqueConstraint
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.types import VARCHAR, Text, Integer

from cscfist.tools.generate_id import generate_update_time

Base = declarative_base()


class FactorBasic(Base):
    __tablename__ = 'factor_basic'

    id = Column(BIGINT, autoincrement=True, primary_key=True)
    factor_id = Column(VARCHAR(200), nullable=True, comment='因子ID')
    factor_name = Column(VARCHAR(200), comment='因子名称')
    author = Column(VARCHAR(20), comment='作者')
    list_date = Column(VARCHAR(8), comment='建立时间')
    delist_date = Column(VARCHAR(8), comment='失效时间')
    is_event = Column(Integer, comment='是否是事件类因子')
    source_code = Column(Text, comment='源代码')
    md5 = Column(VARCHAR(100), comment='源代码md5值, 用于源代码重复检查')
    factor_class_name = Column(VARCHAR(100), comment='因子类名')
    formula = Column(Text, comment='公式')
    description = Column(Text, comment='描述')
    tag = Column(VARCHAR(200), comment='标签')
    direction = Column(Integer, comment='方向')
    is_calc = Column(Integer, comment='是否计算因子值')
    is_cross_stat = Column(Integer, comment='是否截面统计')
    is_examine = Column(Integer, comment='是否检验')
    begin_date_calc = Column(VARCHAR(8), comment='开始计算日期')
    begin_date_stat = Column(VARCHAR(8), comment='开始横截面统计日期')
    begin_date_examine = Column(VARCHAR(8), comment='开始检验日期')
    dependency_factor_list = Column(Text, comment='依赖因子')  # 目前只能依赖于预处理前的因子, 不能依赖于预处理后因子, 如果有需求可以再加
    preprocess_method = Column(VARCHAR(8), comment='预处理方法')
    periods = Column(VARCHAR(20), default='1', comment='分析周期')
    is_open_valid = Column(Integer, comment='是否开盘时可用')
    cal_date = Column(VARCHAR(8), default=generate_update_time("%Y%m%d"), comment='计算日期')
    update_time = Column(VARCHAR(20), default=generate_update_time, comment='更新时间')
    __table_args__ = (Index('basic_id', "factor_id", ),
                      UniqueConstraint("factor_id", name="uni_factor_basic_factor_id"),
                      {'comment': '因子基本信息'},)


def create_table(connection):
    Base.metadata.create_all(connection.engine)
