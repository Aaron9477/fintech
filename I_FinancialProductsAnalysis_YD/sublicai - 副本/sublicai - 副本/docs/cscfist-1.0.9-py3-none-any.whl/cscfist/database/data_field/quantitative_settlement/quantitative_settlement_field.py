# coding: utf-8
from cscfist import NatureDateUtils
from cscfist.database.connection.mysql_con import get_default_qs_connection
from cscfist.tools import generate_id
from sqlalchemy import Column, DECIMAL, Date, Index, String, TIMESTAMP, text, TEXT, Integer, VARCHAR
from sqlalchemy.dialects.mysql import BIGINT, INTEGER
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
metadata = Base.metadata

__all__ = ['StrategyFofAccount', 'StrategyFofCashDividend', 'StrategyFofDividendExRecord', 'StrategyFofFundShareSplit',
           'StrategyFofHoldingPlan', 'StrategyFofNewestSharePlan', 'StrategyFofOnthewayAmount',
           'StrategyFofOnthewayShare', 'StrategyFofOrder', 'StrategyFofPosition', 'StrategyFofReinvestDividend',
           'StrategyInfo', 'StrategyStockClearing', 'StrategyStockPosition', 'StrategyStockTargetWeight',
           'StrategyStockTrading', 'StrategyStockValue', 'TIndicatorVal', 'RqalphaPersist', 'create_table',
           'StrategyStockTradingBacktest', 'StrategyStockTradingClearing']
Base = declarative_base()


class StrategyFofAccount(Base):
    __tablename__ = 'strategy_fof_accounts'
    __table_args__ = (
        Index('strategy_id', 'strategy_id', 'model', 'trading_date', unique=True),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(100), nullable=False, comment='策略ID')
    model = Column(String(20), nullable=False, comment='策略形式：backtest|simulate')
    trading_date = Column(String(8), nullable=False, comment='交易日期')
    fund_value = Column(DECIMAL(24, 8), comment='基金市值')
    cash_value = Column(DECIMAL(24, 8), comment='剩余现金')
    div_value = Column(DECIMAL(24, 8), comment='现金分红')
    total_value = Column(DECIMAL(24, 8), comment='账户总资金')
    ontheway_value = Column(DECIMAL(24, 8), comment='在途金額(在途份额)价值')
    fund_ratio = Column(DECIMAL(24, 8), comment='基金仓位占比')
    cash_ratio = Column(DECIMAL(24, 8), comment='剩余现金占比')
    total_profit = Column(DECIMAL(24, 8), comment='总盈亏')
    floating_pnl = Column(DECIMAL(24, 8), comment='总浮动盈亏')
    realize_profit = Column(DECIMAL(24, 8), comment='总已实现盈亏')
    cost_carry = Column(DECIMAL(24, 8), comment='持仓总成本')
    total_trading_fee = Column(DECIMAL(24, 8), comment='总交易手续费')
    current_floating_pnl_ratio = Column(DECIMAL(24, 8), comment='当日组合涨跌幅')
    current_profit = Column(DECIMAL(24, 8), comment='当日盈亏')
    update_time = Column(String(40))


class StrategyFofCashDividend(Base):
    __tablename__ = 'strategy_fof_cash_dividends'
    __table_args__ = (
        Index('strategy_id', 'strategy_id', 'model', 'trading_date', 'fund_code', unique=True),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(100), nullable=False, comment='策略ID')
    model = Column(String(20), nullable=False, comment='策略形式：backtest|simulate')
    trading_date = Column(String(8), nullable=False, comment='交易日期')
    fund_code = Column(String(40), nullable=False, comment='基金代码')
    holding_share = Column(DECIMAL(24, 8), comment='基金持仓份额')
    div_per_share = Column(DECIMAL(24, 8), comment='每份额基金的分红')
    div_amount = Column(DECIMAL(24, 8), comment='仓位分红金额')
    update_time = Column(String(40))


class StrategyFofDividendExRecord(Base):
    __tablename__ = 'strategy_fof_dividend_ex_records'
    __table_args__ = (
        Index('strategy_id', 'strategy_id', 'model', 'xr_date', 'fund_code', unique=True),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(100), nullable=False, comment='策略ID')
    model = Column(String(20), nullable=False, comment='策略形式：backtest|simulate')
    xr_date = Column(String(8), nullable=False, comment='除权登记日')
    fund_code = Column(String(40), nullable=False, comment='基金代码')
    holding_share = Column(DECIMAL(24, 8), comment='基金持仓份额')
    dr_date = Column(String(8), comment='除息日')
    div_per_share = Column(DECIMAL(24, 8), comment='每份额基金分红')
    deal_date = Column(String(8), comment='分红到账日')
    status = Column(String(10), comment='分红处理状态：dealed|undealed')
    update_time = Column(String(40))


class StrategyFofFundShareSplit(Base):
    __tablename__ = 'strategy_fof_fund_share_splits'
    __table_args__ = (
        Index('strategy_id', 'strategy_id', 'model', 'trading_date', 'fund_code', unique=True),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(100), nullable=False, comment='策略ID')
    model = Column(String(20), nullable=False, comment='策略形式：backtest|simulate')
    trading_date = Column(String(8), nullable=False, comment='交易日期')
    fund_code = Column(String(40), nullable=False, comment='基金代码')
    split_ratio = Column(DECIMAL(24, 8), comment='拆分比例')
    pre_holding_share = Column(DECIMAL(24, 8), comment='拆分前持仓份额')
    pre_nav_cost = Column(DECIMAL(24, 8), comment='拆分前持仓成本')
    holding_share = Column(DECIMAL(24, 8), comment='拆分后持仓份额')
    nav_cost = Column(DECIMAL(24, 8), comment='拆分后持仓成本')
    update_time = Column(String(40))


class StrategyFofHoldingPlan(Base):
    __tablename__ = 'strategy_fof_holding_plans'
    __table_args__ = (
        Index('strategy_id', 'strategy_id', 'trading_date', 'fund_code', unique=True),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(100), nullable=False, comment='策略ID')
    trading_date = Column(String(8), nullable=False, comment='交易日期')
    fund_code = Column(String(40), nullable=False, comment='基金代码')
    weight = Column(DECIMAL(24, 8), comment='基金权重')
    update_time = Column(String(40))


class StrategyFofNewestSharePlan(Base):
    __tablename__ = 'strategy_fof_newest_share_plans'
    __table_args__ = (
        Index('strategy_id', 'strategy_id', 'model', 'trading_date', 'fund_code', unique=True),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(100), nullable=False, comment='策略ID')
    model = Column(String(20), nullable=False, comment='策略形式：backtest|simulate')
    trading_date = Column(String(8), nullable=False, comment='交易日期')
    fund_code = Column(String(40), nullable=False, comment='基金代码')
    share = Column(DECIMAL(24, 8), comment='目标基金份额')
    update_time = Column(String(40))


class StrategyFofOnthewayAmount(Base):
    __tablename__ = 'strategy_fof_ontheway_amounts'
    __table_args__ = (
        Index('strategy_id', 'strategy_id', 'model', 'trading_date', 'fund_code', unique=True),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(100), nullable=False, comment='策略ID')
    model = Column(String(20), nullable=False, comment='策略形式：backtest|simulate')
    trading_date = Column(String(8), nullable=False, comment='交易日期')
    fund_code = Column(String(40), nullable=False, comment='基金代码')
    trading_amount = Column(DECIMAL(24, 8), comment='在途金额')
    close_pnl = Column(DECIMAL(24, 8), comment='平仓盈亏')
    deal_date = Column(String(8), comment='到账日期')
    status = Column(String(10), comment='在途金额状态')
    update_time = Column(String(40))


class StrategyFofOnthewayShare(Base):
    __tablename__ = 'strategy_fof_ontheway_shares'
    __table_args__ = (
        Index('strategy_id', 'strategy_id', 'model', 'trading_date', 'fund_code', unique=True),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(100), nullable=False, comment='策略ID')
    model = Column(String(20), nullable=False, comment='策略形式：backtest|simulate')
    trading_date = Column(String(8), nullable=False, comment='交易日期')
    fund_code = Column(String(40), nullable=False, comment='基金代码')
    trading_share = Column(DECIMAL(24, 8), comment='在途份额')
    price = Column(DECIMAL(24, 8), comment='份额申购价格')
    deal_date = Column(String(8), comment='到账日期')
    status = Column(String(10), comment='在途份额状态')
    update_time = Column(String(40))


class StrategyFofOrder(Base):
    __tablename__ = 'strategy_fof_orders'
    __table_args__ = (
        Index('strategy_id', 'strategy_id', 'model', 'trading_date', 'fund_code', 'side', unique=True),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(100), nullable=False, comment='策略ID')
    model = Column(String(20), nullable=False, comment='策略形式：backtest|simulate')
    trading_date = Column(String(8), nullable=False, comment='交易日期')
    fund_code = Column(String(40), nullable=False, comment='基金代码')
    fund_name = Column(String(50), comment='基金简称')
    side = Column(String(10), comment='买卖方向')
    opr_desc = Column(String(20), comment='订单描述')
    share = Column(DECIMAL(24, 8), comment='下单份额')
    price = Column(DECIMAL(24, 8), comment='下单价格')
    trade_share = Column(DECIMAL(24, 8), comment='成交份额')
    trade_price = Column(DECIMAL(24, 8), comment='成交价格')
    trading_fee = Column(DECIMAL(24, 8), comment='交易费用')
    close_pnl = Column(DECIMAL(24, 8), comment='平仓盈亏')
    trading_priority = Column(String(10), comment='交易优先级')
    desc = Column(String(50), comment='订单执行描述')
    status = Column(String(50), comment='订单状态')
    update_time = Column(String(40))


class StrategyFofPosition(Base):
    __tablename__ = 'strategy_fof_positions'
    __table_args__ = (
        Index('strategy_id', 'strategy_id', 'model', 'trading_date', 'fund_code', unique=True),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(100), nullable=False, comment='策略ID')
    model = Column(String(20), nullable=False, comment='策略形式：backtest|simulate')
    trading_date = Column(String(8), nullable=False, comment='交易日期')
    fund_code = Column(String(40), nullable=False, comment='基金代码')
    fund_name = Column(String(50), comment='基金简称')
    holding_share = Column(DECIMAL(24, 8), comment='持仓份额')
    nav_cost = Column(DECIMAL(24, 8), comment='持仓成本价')
    cost_value = Column(DECIMAL(24, 8), comment='持仓总成本')
    last_nav = Column(DECIMAL(24, 8), comment='最新价格')
    holding_value = Column(DECIMAL(24, 8), comment='持仓市值')
    holding_weight = Column(DECIMAL(24, 8), comment='持仓权重')
    floating_pnl_ratio = Column(DECIMAL(24, 8), comment='浮动涨跌幅')
    floating_pnl = Column(DECIMAL(24, 8), comment='浮动盈亏')
    profit_achieved = Column(DECIMAL(24, 8), comment='已实现盈亏')
    total_profit = Column(DECIMAL(24, 8), comment='总盈亏')
    total_profit_ratio = Column(DECIMAL(24, 8), comment='累计盈亏率')
    update_time = Column(String(40))


class StrategyFofReinvestDividend(Base):
    __tablename__ = 'strategy_fof_reinvest_dividends'
    __table_args__ = (
        Index('strategy_id', 'strategy_id', 'model', 'trading_date', 'fund_code', unique=True),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(100), nullable=False, comment='策略ID')
    model = Column(String(20), nullable=False, comment='策略形式：backtest|simulate')
    trading_date = Column(String(8), nullable=False, comment='交易日期')
    fund_code = Column(String(40), nullable=False, comment='基金代码')
    holding_share = Column(DECIMAL(24, 8), comment='基金持仓份额')
    div_per_share = Column(DECIMAL(24, 8), comment='每份额基金的分红')
    price = Column(DECIMAL(24, 8), comment='分红当天基金净值')
    div_share = Column(DECIMAL(24, 8), comment='分红再投资份额')
    update_time = Column(String(40))


class StrategyInfo(Base):
    __tablename__ = 'strategy_info'
    __table_args__ = (
        Index('idx_strategy_id_bm_code_init_amount_last_date', 'strategy_id', 'benchmark_code', 'init_amount',
              'list_date'),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(200), unique=True, comment='组合代码')
    benchmark_code = Column(String(200), comment='业绩基准代码')
    init_amount = Column(DECIMAL(30, 4), comment='组合初始资产规模')
    competitor_code = Column(String(50), comment='竞合组合代码')
    list_date = Column(String(30), comment='建立日期')
    delist_date = Column(String(30), comment='下线日期')
    strategy_type = Column(String(200), comment='策略大类')
    sub_strategy_type = Column(String(100), comment='策略子类')
    strategy_name = Column(String(200), comment='组合中文名称')
    author = Column(String(100), comment='策略作者')
    description = Column(String(10240), comment='策略描述')
    dividend_mode = Column(String(20), server_default=text("'01'"), comment='01:现金分红，02：红利再投')
    fee_mode = Column(String(1), comment='null,0:不收取手续费，1:按照公告收取手续费')
    fee_discount_rate = Column(DECIMAL(6, 4), comment='手续费折扣率')
    ifap_strategy_id = Column(String(100))


class StrategyStockClearing(Base):
    __tablename__ = 'strategy_stock_clearing'
    __table_args__ = (
        Index('idx_strategy_id_clearing_date', 'strategy_id', 'clearing_date'),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(200), comment='组合代码')
    clearing_date = Column(Date, nullable=False, comment='清算日')
    status = Column(INTEGER(11), nullable=False, comment='状态: 0-未撮合, 1-已撮合, 2-已清算')


class StrategyStockPosition(Base):
    __tablename__ = 'strategy_stock_position'
    __table_args__ = (
        Index('idx_strategy_id_trading_date_stock_code_name', 'strategy_id', 'trading_date', 'stock_code',
              'stock_name'),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(200), comment='组合代码')
    stock_code = Column(String(50), nullable=False, comment='股票代码')
    stock_name = Column(String(200), nullable=False, comment='股票名称')
    last_price = Column(DECIMAL(30, 4), comment='最新价格(元/股)')
    price_change = Column(DECIMAL(30, 4), comment='涨跌(元/股)')
    pct_change = Column(DECIMAL(30, 4), comment='涨跌幅(%)')
    holding_share = Column(DECIMAL(30, 4), comment='持仓数量(股)')
    holding_value = Column(DECIMAL(30, 4), comment='持仓市值(元)')
    holding_weight = Column(DECIMAL(30, 4), comment='最新权重(%)')
    daily_profit = Column(DECIMAL(30, 4), comment='当日盈亏(元)')
    float_profit = Column(DECIMAL(30, 4), comment='浮动盈亏(元)')
    total_profit = Column(DECIMAL(30, 4), comment='累计盈亏(元)')
    float_profit_ratio = Column(DECIMAL(30, 4), comment='浮动盈亏率(%)')
    total_profit_ratio = Column(DECIMAL(30, 4), comment='累计盈亏率(%)')
    interest_profit = Column(DECIMAL(30, 4), comment='利息收入(元)')
    realize_profit = Column(DECIMAL(30, 4), comment='已实现盈亏(元)')
    holding_cost = Column(DECIMAL(30, 4), comment='持仓成本(元)')
    cost_price = Column(DECIMAL(30, 4), comment='成本价格(元/股)')
    break_even_price = Column(DECIMAL(30, 4), comment='保本价格(元/股)')
    trading_date = Column(String(30), comment='交易日期')
    description = Column(String(100), comment='说明信息')


class StrategyStockTargetWeight(Base):
    __tablename__ = 'strategy_stock_target_weight'
    __table_args__ = (
        Index('strategy_stock_target_weight_un', 'strategy_id', 'trading_date', 'stock_code', 'weight', unique=True),
        Index('idx_strategy_id_trading_date_stock_code_name_weight', 'strategy_id', 'trading_date', 'stock_code',
              'stock_name', 'weight')
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(200), comment='组合代码')
    stock_code = Column(String(50), nullable=False, comment='股票代码')
    stock_name = Column(String(200), nullable=False, comment='股票名称')
    weight = Column(DECIMAL(20, 4), comment='目标权重')
    price = Column(DECIMAL(20, 4), comment='目标价格')
    trading_date = Column(String(30), comment='交易日期')


class StrategyStockTrading(Base):
    __tablename__ = 'strategy_stock_trading'
    __table_args__ = (
        Index('idx_strategy_id_trading_date_stock_code_name', 'strategy_id', 'trading_date', 'stock_code',
              'stock_name'),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(200), comment='组合代码')
    trading_date = Column(String(30), nullable=False, comment='交易日期')
    stock_code = Column(String(50), nullable=False, comment='股票代码')
    stock_name = Column(String(200), comment='股票名称')
    side = Column(String(50), comment='买卖方向')
    trading_priority = Column(String(50), comment='交易优先级')
    order_share = Column(DECIMAL(30, 4), comment='申请数量(股)')
    trading_price = Column(DECIMAL(30, 4), comment='成交价格')
    trading_result = Column(String(200), comment='成交结果')
    trading_info = Column(String(200), comment='成交状态')
    trading_type = Column(String(200), comment='调整类别')
    trading_share = Column(DECIMAL(30, 4), comment='成交数量(股)')
    trading_cost = Column(DECIMAL(30, 4), comment='交易手续费')


class StrategyStockValue(Base):
    __tablename__ = 'strategy_stock_value'
    __table_args__ = (
        Index('idx_strategy_id_trading_date', 'strategy_id', 'trading_date'),
    )

    id = Column(BIGINT(20), primary_key=True)
    strategy_id = Column(String(200), comment='组合代码')
    daily_profit_ratio = Column(DECIMAL(30, 4), comment='当日涨跌幅(%)')
    stock_ratio = Column(DECIMAL(30, 4), comment='股票仓位(%)')
    stock_value = Column(DECIMAL(30, 4), comment='股票市值(元)')
    cash_value = Column(DECIMAL(30, 4), comment='剩余现金(元)')
    total_value = Column(DECIMAL(30, 4), comment='总市值(元)')
    daily_profit = Column(DECIMAL(30, 4), comment='当日盈亏(元)')
    float_profit = Column(DECIMAL(30, 4), comment='浮动盈亏(元)')
    total_profit = Column(DECIMAL(30, 4), comment='累计盈亏(元)')
    float_profit_ratio = Column(DECIMAL(30, 4), comment='浮动盈亏率(%)')
    total_profit_ratio = Column(DECIMAL(30, 4), comment='累计盈亏率(%)')
    interest_profit = Column(DECIMAL(30, 4), comment='利息收入(元)')
    realize_profit = Column(DECIMAL(30, 4), comment='已实现盈亏(元)')
    holding_cost = Column(DECIMAL(30, 4), comment='持仓成本(元)')
    total_trading_cost = Column(DECIMAL(30, 4), comment='累计交易手续费')
    trading_date = Column(String(30), comment='交易日期')
    description = Column(String(100), comment='说明信息')


class TIndicatorVal(Base):
    __tablename__ = 't_indicator_val'
    __table_args__ = (
        Index('t_indicator_val_strategy_id_IDX', 'strategy_id', 'indicator_name', 'trading_date'),
        Index('t_indicator_val_un', 'trading_date', 'strategy_id', 'indicator_name', 'extra_key', unique=True),
        Index('t_indicator_vals_strategy_id_dt_IDX', 'strategy_id', 'trading_date')
    )

    id = Column(BIGINT(20), primary_key=True)
    trading_date = Column(String(8), nullable=False, comment='指标日期')
    strategy_id = Column(String(100), nullable=False, comment='策略id')
    indicator_name = Column(String(100), nullable=False, comment='指标名称/id')
    extra_key = Column(String(100), server_default=text("''"), comment='对指标的额外限定，如: 周期(1y, 2y) ... etc')
    indicator_value = Column(String(2000), comment='指标值, 字符串类型存储, 使用时需做类型转换')
    val_type = Column(String(100), server_default=text("'float'"), comment='指标值类型, 以便进行类型转换')
    cal_date = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))


class RqalphaPersist(Base):
    __tablename__ = "rqalpha_persist"
    id = Column(String(32), default=generate_id, primary_key=True)
    strategy_id = Column(String(32), comment="策略id")
    save_object = Column(String(32), comment="")
    save_value = Column(TEXT, comment="")
    cal_date = Column(VARCHAR(30), default=NatureDateUtils.get_cur_date, nullable=True, comment="计算日期")
    update_time = Column(VARCHAR(30), default=NatureDateUtils.get_cur_time, nullable=True, comment="更新时间")


class StrategyStockTradingBacktest(Base):
    __tablename__ = 'strategy_stock_trading_backtest'
    __table_args__ = (
        Index('idx_tb_strategy_id_trading_date_stock_code_name', 'strategy_id', 'trade_date', 'stock_code',
              'stock_name'),
    )
    id = Column(BIGINT(20), primary_key=True, autoincrement=True)
    strategy_id = Column(String(200), comment='策略ID')
    trade_date = Column(String(30), nullable=False, comment='交易日期')
    stock_code = Column(String(50), nullable=False, comment='股票代码')
    stock_name = Column(String(200), comment='股票名称')
    order_time = Column(String(8), nullable=False, comment='下单时间, 当前支持open和close')
    order_type = Column(String(50), comment='下单类别, 当前只支持order_target_percent')
    order_direction = Column(String(50), comment='买卖方向, 当order_type为目标权重或目标金额下单时, 此字段失效')
    order_volume = Column(DECIMAL(30, 4), comment='申请数量, 可能为股数、比例数、金额数, 取决于order_type')
    trading_commission = Column(DECIMAL(30, 4), comment='交易手续费')
    trading_tax = Column(DECIMAL(30, 4), comment='交易税费')


class StrategyStockTradingClearing(Base):
    __tablename__ = 'strategy_stock_trading_clearing'
    __table_args__ = (
        Index('idx_tc_strategy_id_trading_date_stock_code_name', 'strategy_id', 'trade_date', 'stock_code',
              'stock_name'),
    )
    id = Column(BIGINT(20), primary_key=True, autoincrement=True)
    strategy_id = Column(String(200), comment='策略ID')
    trade_date = Column(String(30), nullable=False, comment='交易日期')
    stock_code = Column(String(50), nullable=False, comment='股票代码')
    stock_name = Column(String(200), comment='股票名称')
    order_time = Column(String(8), nullable=False, comment='下单时间, 当前支持open和close')
    order_type = Column(String(50), comment='下单类别, 当前只支持order_target_percent')
    order_direction = Column(String(50), comment='买卖方向, 当order_type为目标权重或目标金额下单时, 此字段失效')
    order_volume = Column(DECIMAL(30, 4), comment='申请数量, 可能为股数、比例数、金额数, 取决于order_type')
    trading_commission = Column(DECIMAL(30, 4), comment='交易手续费')
    trading_tax = Column(DECIMAL(30, 4), comment='交易税费')


def create_table(engine):
    """建表"""
    Base.metadata.create_all(engine)
