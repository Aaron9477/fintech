# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/1/10 17:27
# @Author  : wangxybjs
# @File    : __init__.py.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------

from cscfist.database.data_field.stock_factor.factor_summary.factor_coverage import *