# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/12/17 14:34
# @Author  : lisl3
# @File    : jcjs_field.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from sqlalchemy import Column, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.types import Integer, VARCHAR, Numeric, String

from cscfist.tools import generate_id, NatureDateUtils

__all__ = ['StockValueInterval', 'RiskFreeRate', 'StockMorningStar', 'StockFourFactors',
           'BarraRawFactor', 'BarraStyleFactorExpose', 'BarraStyleFactorReturn', 'BarraIndustryFactorExpose',
           'BarraIndustryFactorReturn', 'BarraFactorCovariance', 'BarraStockUniqueReturn', 'BarraStockUniqueRisk',
           'create_table']
Base = declarative_base()


class StockValueInterval(Base):
    """股票财务指标区间"""
    __tablename__ = 'jcjs_stock_value_interval'
    id = Column(String(32), default=generate_id, primary_key=True, comment='主键')
    time_tag = Column(VARCHAR(8), comment='数据日期')
    stock_code = Column(VARCHAR(9), comment='股票代码')
    cal_date = Column(VARCHAR(8), default=NatureDateUtils.get_now_time('%Y%m%d'), comment='计算日期')
    PE_interval = Column(Integer, comment='PE区间')
    PB_interval = Column(Integer, comment='PB区间')
    ROE_interval = Column(Integer, comment='ROE区间')
    TDR_interval = Column(Integer, comment='TDR区间')
    eps = Column(Numeric(20, 6), comment='每股收益')
    excess_return = Column(Numeric(20, 6), comment='超额收益')
    __table_args__ = (Index('jcjs_stock_code_time_tag', "stock_code", "time_tag"), Index("jcjs_time_tag", "time_tag"))


class RiskFreeRate(Base):
    """无风险收益率"""
    __tablename__ = 'jcjs_risk_free_rate'
    id = Column(String(32), default=generate_id, primary_key=True, comment='主键')
    trade_date = Column(VARCHAR(8), comment='交易日期')
    cal_date = Column(VARCHAR(8), default=NatureDateUtils.get_now_time('%Y%m%d'), comment='计算日期')
    rate = Column(Numeric(20, 6), nullable=True, comment='无风险利率')
    __table_args__ = (Index('jcjs_risk_free_rate', "trade_date"),)


class StockMorningStar(Base):
    """股票的晨星风格"""
    __tablename__ = 'jcjs_stock_morning_star'
    id = Column(String(32), default=generate_id, primary_key=True, comment='主键')
    stock_code = Column(VARCHAR(9), comment='股票代码')
    trade_dt = Column(VARCHAR(8), comment='数据日期')
    cal_date = Column(VARCHAR(8), default=NatureDateUtils.get_now_time('%Y%m%d'), comment='计算日期')
    raw_x = Column(Numeric(20, 6), nullable=True, comment='成长价值因子')
    raw_y = Column(Numeric(20, 6), nullable=True, comment='规模因子')
    raw_x_value = Column(Numeric(20, 6), nullable=True, comment='价值因子')
    raw_x_growth = Column(Numeric(20, 6), nullable=True, comment='成长因子')
    __table_args__ = (Index('jcjs_ms_stock_date', "stock_code", "trade_dt"),
                      Index('jcjs_ms_date', "trade_dt"),)


class StockFourFactors(Base):
    """A股四因子"""
    __tablename__ = 'jcjs_stock_four_factors'
    id = Column(String(32), default=generate_id, primary_key=True, comment='主键')
    trade_dt = Column(VARCHAR(8), comment='数据日期')
    freq = Column(VARCHAR(20), comment='频率')
    cal_date = Column(VARCHAR(8), default=NatureDateUtils.get_now_time('%Y%m%d'), comment='计算日期')
    hml = Column(Numeric(20, 6), nullable=True, comment='价值因子')
    mkt = Column(Numeric(20, 6), nullable=True, comment='市场因子')
    mom = Column(Numeric(20, 6), nullable=True, comment='动量因子')
    smb = Column(Numeric(20, 6), nullable=True, comment='市值因子')
    pmo = Column(Numeric(20, 6), nullable=True, comment='换手率因子')
    __table_args__ = (Index('jcjs_s4f_trade_dt', "trade_dt"),
                      Index('jcjs_s4f_freq_trade_dt', "freq", "trade_dt"),)


class BarraRawFactor(Base):
    """Barra因子基础因子数据，如beta，std（e）等"""
    __tablename__ = 'jcjs_barra_raw_factor'
    id = Column(String(32), default=generate_id, primary_key=True, comment='主键')
    project_name = Column(VARCHAR(40), comment='项目名')
    s_info_windcode = Column(VARCHAR(20), comment='股票代码')
    trade_dt = Column(VARCHAR(8), comment='数据日期')
    cal_date = Column(VARCHAR(8), default=NatureDateUtils.get_now_time('%Y%m%d'), comment='计算日期')
    factor_name = Column(VARCHAR(40), comment='因子名称')
    factor_value = Column(Numeric(20, 6), nullable=True, comment='因子值')
    __table_args__ = (Index('jcjs_brf_code_dt', "s_info_windcode", "trade_dt"),
                      Index('jcjs_brf_trade_dt', "trade_dt"),)


class BarraStyleFactorExpose(Base):
    """Barra风格因子暴露"""
    __tablename__ = 'jcjs_barra_style_factor_expose'
    id = Column(String(32), default=generate_id, primary_key=True, comment='主键')
    project_name = Column(VARCHAR(40), comment='项目名')
    s_info_windcode = Column(VARCHAR(20), comment='股票代码')
    trade_dt = Column(VARCHAR(8), comment='数据日期')
    cal_date = Column(VARCHAR(8), default=NatureDateUtils.get_now_time('%Y%m%d'), comment='计算日期')
    beta = Column(Numeric(20, 6), nullable=True, comment='贝塔因子')
    momentum = Column(Numeric(20, 6), nullable=True, comment='动量因子')
    size = Column(Numeric(20, 6), nullable=True, comment='市值因子')
    earning = Column(Numeric(20, 6), nullable=True, comment='收益因子')
    volatility = Column(Numeric(20, 6), nullable=True, comment='波动率因子')
    growth = Column(Numeric(20, 6), nullable=True, comment='成长因子')
    book_to_price = Column(Numeric(20, 6), nullable=True, comment='市净率因子')
    leverage = Column(Numeric(20, 6), nullable=True, comment='杠杆因子')
    liquidity = Column(Numeric(20, 6), nullable=True, comment='流动性因子')
    non_linear = Column(Numeric(20, 6), nullable=True, comment='非线性市值因子')
    __table_args__ = (Index('jcjs_bsfe_code_dt', "s_info_windcode", "trade_dt"),
                      Index('jcjs_bsfe_trade_dt', "trade_dt"),)


class BarraStyleFactorReturn(Base):
    """Barra风格因子收益"""
    __tablename__ = 'jcjs_barra_style_factor_return'
    id = Column(String(32), default=generate_id, primary_key=True, comment='主键')
    project_name = Column(VARCHAR(40), comment='项目名')
    trade_dt = Column(VARCHAR(8), comment='数据日期')
    cal_date = Column(VARCHAR(8), default=NatureDateUtils.get_now_time('%Y%m%d'), comment='计算日期')
    const = Column(Numeric(20, 6), nullable=True, comment='常数')
    beta = Column(Numeric(20, 6), nullable=True, comment='贝塔因子')
    momentum = Column(Numeric(20, 6), nullable=True, comment='动量因子')
    size = Column(Numeric(20, 6), nullable=True, comment='市值因子')
    earning = Column(Numeric(20, 6), nullable=True, comment='收益因子')
    volatility = Column(Numeric(20, 6), nullable=True, comment='波动率因子')
    growth = Column(Numeric(20, 6), nullable=True, comment='成长因子')
    book_to_price = Column(Numeric(20, 6), nullable=True, comment='市净率因子')
    leverage = Column(Numeric(20, 6), nullable=True, comment='杠杆因子')
    liquidity = Column(Numeric(20, 6), nullable=True, comment='流动性因子')
    non_linear = Column(Numeric(20, 6), nullable=True, comment='非线性市值因子')
    __table_args__ = (Index('jcjs_bsfr_dt', "trade_dt"),)


class BarraIndustryFactorExpose(Base):
    """Barra行业因子暴露"""
    __tablename__ = 'jcjs_barra_industry_factor_expose'
    id = Column(String(32), default=generate_id, primary_key=True, comment='主键')
    project_name = Column(VARCHAR(40), comment='项目名')
    s_info_windcode = Column(VARCHAR(20), comment='股票代码')
    trade_dt = Column(VARCHAR(8), comment='数据日期')
    cal_date = Column(VARCHAR(8), default=NatureDateUtils.get_now_time('%Y%m%d'), comment='计算日期')
    industry = Column(VARCHAR(40), comment='所在行业')
    __table_args__ = (Index('jcjs_bife_code_dt', "s_info_windcode", "trade_dt"),
                      Index('jcjs_bife_trade_dt', "trade_dt"),)


class BarraIndustryFactorReturn(Base):
    """Barra行业因子收益"""
    __tablename__ = 'jcjs_barra_industry_factor_return'
    id = Column(String(32), default=generate_id, primary_key=True, comment='主键')
    project_name = Column(VARCHAR(40), comment='项目名')
    trade_dt = Column(VARCHAR(8), comment='数据日期')
    cal_date = Column(VARCHAR(8), default=NatureDateUtils.get_now_time('%Y%m%d'), comment='计算日期')
    factor_name = Column(VARCHAR(40), comment='因子名称')
    factor_return = Column(Numeric(20, 6), nullable=True, comment='因子收益')
    __table_args__ = (Index('jcjs_bifr_dt', "trade_dt"),)


class BarraFactorCovariance(Base):
    """Barra因子协方差数据"""
    __tablename__ = 'jcjs_barra_factor_covariance'
    id = Column(String(32), default=generate_id, primary_key=True, comment='主键')
    project_name = Column(VARCHAR(40), comment='项目名')
    trade_dt = Column(VARCHAR(8), comment='数据日期')
    cal_date = Column(VARCHAR(8), default=NatureDateUtils.get_now_time('%Y%m%d'), comment='计算日期')
    factor_name_horizon = Column(VARCHAR(20), comment='横向因子')
    factor_name_vertical = Column(VARCHAR(20), comment='纵向因子')
    cov_value = Column(Numeric(20, 6), nullable=True, comment='协方差')
    __table_args__ = (Index('jcjs_bfc_dt', "trade_dt"),)


class BarraStockUniqueReturn(Base):
    """Barra因子股票特异性收益率"""
    __tablename__ = 'jcjs_barra_stock_unique_return'
    id = Column(String(32), default=generate_id, primary_key=True, comment='主键')
    project_name = Column(VARCHAR(40), comment='项目名')
    s_info_windcode = Column(VARCHAR(20), comment='股票代码')
    trade_dt = Column(VARCHAR(8), comment='数据日期')
    cal_date = Column(VARCHAR(8), default=NatureDateUtils.get_now_time('%Y%m%d'), comment='计算日期')
    unique_return = Column(Numeric(20, 6), nullable=True, comment='特异性收益率')
    __table_args__ = (Index('jcjs_bsur_code_dt', "s_info_windcode", "trade_dt"),
                      Index('jcjs_bsur_trade_dt', "trade_dt"),)


class BarraStockUniqueRisk(Base):
    """Barra因子股票特异性风险"""
    __tablename__ = 'jcjs_barra_stock_unique_risk'
    id = Column(String(32), default=generate_id, primary_key=True, comment='主键')
    project_name = Column(VARCHAR(40), comment='项目名')
    s_info_windcode = Column(VARCHAR(20), comment='股票代码')
    trade_dt = Column(VARCHAR(8), comment='数据日期')
    cal_date = Column(VARCHAR(8), default=NatureDateUtils.get_now_time('%Y%m%d'), comment='计算日期')
    unique_risk = Column(Numeric(20, 6), nullable=True, comment='特异性风险')
    __table_args__ = (Index('jcjs_bsuri_code_dt', "s_info_windcode", "trade_dt"),)


def create_table(engine):
    """建表"""
    Base.metadata.create_all(engine)
