from sqlalchemy import Column, VARCHAR, Numeric, Index, Date, CHAR, NVARCHAR, CLOB
from sqlalchemy.dialects.oracle import NCLOB
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class FUNDBSOFINFO(Base):
    """
    开放式基金详细情况
    """
    __tablename__ = 'fund_bs_ofinfo'
    __table_args__ = (
        Index('pk_lg_fund_bs_ofinfo', 'SECURITYCODE'),)
    ISTYPE = Column(VARCHAR(100), comment='投资风格 (NIPMID: 100000000000260965)')
    ISSUM = Column(VARCHAR(80), comment='是否为合并数据 (NIPMID: 127000000838614349)')
    MSFTYPE = Column(Numeric(20, 8), comment='MS基金分类 (NIPMID: 127000000026022183)')
    ISSTAT = Column(Numeric(20, 8), comment='是否参与统计 (NIPMID: 127000000842614277)')
    FPROPERTY = Column(VARCHAR(60), comment='基金风格属性 (NIPMID: 127000000026021403)')
    ITYPE = Column(Numeric(20, 8), comment='基金投资类别 (NIPMID: 127000000026021992)')
    COMETHOD = Column(VARCHAR(4), comment='份额结转方式 (NIPMID: 127000000026021160)')
    FNATURE = Column(VARCHAR(100), comment='基金性质 (NIPMID: 127000000026019968)')
    MCOVERINFO = Column(VARCHAR(200), comment='份额结转日说明 (NIPMID: 138000000570387747)')
    ENDREASON = Column(VARCHAR(100), comment='基金终止原因 (NIPMID: 138000000732127230)')
    SECURITYTYPE = Column(VARCHAR(100), comment='基金类型 (NIPMID: 127000000026019954)')
    ALLOTRULE = Column(CLOB, comment='分配原则')
    MANAGERCODE = Column(VARCHAR(16), comment='基金管理人代码')
    SECURITYSNAME = Column(VARCHAR(100), comment='基金简称')
    RAISESUM1ST = Column(Numeric(38, 18), comment='首次募资总额')
    IAREADISCR = Column(CLOB, comment='投资区域说明')
    FSERIESCODE = Column(VARCHAR(12), comment='所属基金系列代码')
    SUMTDAILY = Column(Numeric(38, 18), comment='单日申购上限')
    ENDDATE = Column(Date, comment='基金终止日')
    FSERIESNAME = Column(VARCHAR(200), comment='所属基金系列名称')
    FINTRO = Column(CLOB, comment='基金简介')
    REMARK = Column(CLOB, comment='附注')
    ISTRATERGY = Column(CLOB, comment='投资策略')
    ASDATE = Column(Date, comment='场内申购起始日')
    FOUNDDATE = Column(Date, comment='成立日期')
    IAIM = Column(CLOB, comment='投资目标')
    APPLYADATE = Column(VARCHAR(40), comment='申购申请确认日')
    DECIDEORDER = Column(CLOB, comment='决策程序')
    DECLAREDATE = Column(Date, comment='公告日期')
    ASUML = Column(Numeric(20, 8), comment='申购金额下限')
    DEICDEBASE = Column(CLOB, comment='决策依据')
    IRANGE = Column(CLOB, comment='投资范围')
    SECURITYNAME = Column(VARCHAR(200), comment='基金法定名称')
    MCOVERDATE = Column(Numeric(20, 8), comment='每月份额结转日')
    ISTANDARD = Column(CLOB, comment='投资标准')
    FMANAGER = Column(VARCHAR(400), comment='基金经理')
    RSDATEOTC = Column(Date, comment='场外日常赎回起始日')
    RISKINCOME = Column(CLOB, comment='风险收益特征')
    ASDATEOTC = Column(Date, comment='场外日常申购起始日')
    TRUSTEECODE = Column(VARCHAR(16), comment='基金托管人代码')
    UPDATEDATE = Column(Date, comment='资料更新日期')
    ESOURCEMEMO = Column(VARCHAR(100))
    REDEEMADATE = Column(VARCHAR(40), comment='赎回申请确认日')
    RSHARELPER = Column(Numeric(20, 8), comment='单笔赎回份额下限')
    IIDEA = Column(CLOB, comment='投资理念')
    ARSNAMEIN = Column(VARCHAR(100), comment='场内申购赎回简称')
    ARCODEIN = Column(VARCHAR(40), comment='场内申购赎回代码')
    RSDATE = Column(Date, comment='场内赎回起始日')
    RISKMANAGER = Column(CLOB, comment='风险管理工具及主要指标')
    ENDREASONINFO = Column(VARCHAR(2000), comment='基金终止原因说明')
    SECINNERCODE = Column(VARCHAR(200), comment='证券内码')
    IAREA = Column(VARCHAR(200), comment='投资区域')
    SECURITYCODE = Column(VARCHAR(12), comment='基金代码')
    RSUMPAYDATE = Column(VARCHAR(40), comment='赎回款项支付日')
    EID = Column(Numeric(18, 0), primary_key=True)
    ESEQID = Column(Numeric(20, 0))
    EITIME = Column(Date)
    EUTIME = Column(Date)
    EGETTIME = Column(Date)
    EISDEL = Column(CHAR(1))
    TRADE_WAY = Column(VARCHAR(50), comment='交易方式 (NIPMID: 138000000784999572)')
    TRANSFORM_DATE = Column(Date, comment='转型生效日期')


class TRADTDTDATE(Base):
    """
    交易日期
    """
    __tablename__ = 'trad_td_tdate'
    __table_args__ = (
        Index('pk_lg_trad_td_tdate', 'TYPECODE', 'TRADEMARKETCODE', 'TRADEDATE'),)
    TRADEMARKETCODE = Column(VARCHAR(200), comment='交易市场编码 (NIPMID: 127000000001707275)')
    TRADEDATE = Column(VARCHAR(16), comment='交易日期')
    AUCTIONCOPM = Column(VARCHAR(40), comment='下午竞价结束时间')
    OPENTRADEPM = Column(VARCHAR(40), comment='下午交易开始时间')
    TYPECODE = Column(VARCHAR(80), comment='品种')
    CLOSETRADEPM = Column(VARCHAR(40), comment='下午交易结束时间')
    ESOURCEMEMO = Column(VARCHAR(100))
    AUCTIONCOAM = Column(VARCHAR(40), comment='上午竞价结束时间')
    PPDATE = Column(Date, comment='日期')
    AUCTIONOPPM = Column(VARCHAR(40), comment='下午竞价开始时间')
    CLOSETRADEAM = Column(VARCHAR(40), comment='上午交易结束时间')
    AUCTIONOPAM = Column(VARCHAR(40), comment='上午竞价开始时间')
    OPENTRADEAM = Column(VARCHAR(40), comment='上午交易开始时间')
    EID = Column(Numeric(18, 0), primary_key=True)
    ESEQID = Column(Numeric(20, 0))
    EITIME = Column(Date)
    EUTIME = Column(Date)
    EGETTIME = Column(Date)
    EISDEL = Column(CHAR(1))


class FUNDBSATYPE(Base):
    """None"""
    __tablename__ = 'fund_bs_atype'
    __table_args__ = (
        Index('PK_LG_FUND_BS_ATYPE', 'TYPECODE', 'SECURITYCODE', 'CHANGEDATE'),)
    TYPECODE = Column(Numeric(20, 8), comment='类型代码 (NIPMID: 138000000412793992)')
    TYPEMETHOD = Column(Numeric(20, 8), comment='分类口径 (NIPMID: 138000000412793985)')
    ISUSABLE = Column(CHAR(1), comment='是否正在使用 (NIPMID: 127000000541478933)')
    ESOURCEMEMO = Column(VARCHAR(100))
    SECINNERCODE = Column(VARCHAR(200), comment='证券内码')
    ENDDATE = Column(Date, comment='截止日期')
    SECURITYCODE = Column(VARCHAR(40), comment='基金代码')
    CHANGEDATE = Column(Date, comment='变动日期')
    EID = Column(Numeric(18, 0), primary_key=True)
    ESEQID = Column(Numeric(20, 0))
    EITIME = Column(Date)
    EUTIME = Column(Date)
    EGETTIME = Column(Date)
    EISDEL = Column(CHAR(1))


class FUNDNVNAV(Base):
    """None"""
    __tablename__ = 'fund_nv_nav'
    __table_args__ = (
        Index('PK_LG_FUND_NV_NAV', 'SECURITYCODE', 'ENDDATE'),)
    ISSTAT = Column(Numeric(20, 8), comment='是否参与统计 (NIPMID: 127000000842615577)')
    ISSUM = Column(Numeric(20, 8), comment='是否合并数据 (NIPMID: 127000000838614349)')
    CURRENCY = Column(VARCHAR(40), comment='币种 (NIPMID: 127000000001707337)')
    ENDDATE = Column(Date, comment='截止日期')
    NOTICEDATE = Column(Date, comment='公告日期')
    ESOURCEMEMO = Column(VARCHAR(100))
    SECINNERCODE = Column(VARCHAR(200), comment='证券内码')
    NAV = Column(Numeric(38, 18), comment='资产净值')
    SECURITYCODE = Column(VARCHAR(80), comment='基金代码')
    EID = Column(Numeric(18, 0), primary_key=True)
    ESEQID = Column(Numeric(20, 0))
    EITIME = Column(Date)
    EUTIME = Column(Date)
    EGETTIME = Column(Date)
    EISDEL = Column(CHAR(1))


class FUNDDRFUNDNV(Base):
    """
    基金净值衍生表
    """
    __tablename__ = 'fund_dr_fundnv'
    __table_args__ = (
        Index('idx_csc_sec_fund_dr_fundnv', 'SECURITYCODE', 'ENDDATE'),
        Index('pk_lg_fund_dr_fundnv', 'SECINNERCODE', 'ENDDATE'),)
    SECURITYCODE = Column(VARCHAR(20), comment='基金代码')
    ESOURCEMEMO = Column(VARCHAR(100))
    NVGRW1W = Column(Numeric(20, 8), comment='最近1周净值增长率')
    ENDDATE = Column(Date, comment='截止日期')
    AANVGRF = Column(Numeric(20, 8), comment='成立至今复权单位净值增长率')
    NVGR260W = Column(Numeric(20, 8), comment='最近5年净值增长率')
    SECINNERCODE = Column(VARCHAR(200), comment='证券内码')
    NVGRWTD = Column(Numeric(20, 8), comment='当日净值增长率')
    NVGR208W = Column(Numeric(20, 8), comment='最近4年净值增长率')
    YIELD3YA = Column(Numeric(20, 8), comment='往前第三年净值增长率')
    NVGR4W = Column(Numeric(20, 8), comment='最近1月净值增长率')
    NVGRTY = Column(Numeric(20, 8), comment='今年以来净值增长率')
    YIELD4YA = Column(Numeric(20, 8), comment='往前第四年净值增长率')
    NVYIELDTW = Column(Numeric(20, 8), comment='本周净值增长率')
    REDTYPE = Column(VARCHAR(40), comment='赎回状态')
    NVGR26W = Column(Numeric(20, 8), comment='最近6月净值增长率')
    NVGR13W = Column(Numeric(20, 8), comment='最近3月净值增长率')
    NVGR52W = Column(Numeric(20, 8), comment='最近1年净值增长率')
    REMARK = Column(VARCHAR(200), comment='备注')
    NVPER = Column(Numeric(20, 8), comment='单位净值')
    AANVPERL = Column(Numeric(20, 8), comment='昨复权单位净值')
    AAYIELD = Column(Numeric(20, 8), comment='年化总回报')
    NVGRF = Column(Numeric(20, 8), comment='成立至今净值增长率')
    YIELDLY = Column(Numeric(20, 8), comment='去年净值增长率')
    YIELD5YA = Column(Numeric(20, 8), comment='往前第五年净值增长率')
    NVPERCHG = Column(Numeric(20, 8), comment='当日净值增长率（不复权）')
    YIELD2YA = Column(Numeric(20, 8), comment='前年净值增长率')
    NVCHG = Column(Numeric(20, 8), comment='当日复权净值对数收益率')
    NVYIELDTM = Column(Numeric(20, 8), comment='本月净值增长率')
    AANVPER = Column(Numeric(20, 8), comment='复权单位净值')
    PURTYPE = Column(VARCHAR(40), comment='申购状态')
    NVGR156W = Column(Numeric(20, 8), comment='最近3年净值增长率')
    ANVPER = Column(Numeric(20, 8), comment='累计单位净值')
    NVGR104W = Column(Numeric(20, 8), comment='最近2年净值增长率')
    EID = Column(Numeric(18, 0), primary_key=True)
    ESEQID = Column(Numeric(20, 0))
    EITIME = Column(Date)
    EUTIME = Column(Date)
    EGETTIME = Column(Date)
    EISDEL = Column(CHAR(1))
    IS_UNUSUAL_VOLATILITY = Column(VARCHAR(4), comment='是否异常波动')
    IS_PREDICT = Column(VARCHAR(2), comment='是否预测 (NIPMID: 138000000565856534)')


class FUNDBSCBINFO(Base):
    """
    封闭式基金概况
    """
    __tablename__ = 'fund_bs_cbinfo'
    __table_args__ = (
        Index('pk_lg_fund_bs_cbinfo', 'SECURITYCODE'),)
    FPROPERTY = Column(VARCHAR(60), comment='基金风格属性 (NIPMID: 127000000026021403)')
    ISTYPE = Column(VARCHAR(100), comment='投资风格 (NIPMID: 100000000000260965)')
    FNATURE = Column(VARCHAR(100), comment='基金性质 (NIPMID: 127000000026019968)')
    TRADEMARKETCODE = Column(VARCHAR(50), comment='市场代码 (NIPMID: 127000000001707275)')
    SECURITYTYPE = Column(VARCHAR(100), comment='基金类型 (NIPMID: 127000000026019954)')
    ENDDATE = Column(Date, comment='存续终止日')
    LISTDATE = Column(Date, comment='上市日期')
    FHISTORY = Column(CLOB, comment='基金沿革')
    UPDATEDATE = Column(Date, comment='资料更新日期')
    DURATION = Column(Numeric(38, 18), comment='存续期限')
    REMARK = Column(CLOB, comment='附注')
    DECIDEORDER = Column(CLOB, comment='决策程序')
    STARTDATE = Column(Date, comment='存续起始日')
    DEICDEBASE = Column(CLOB, comment='决策依据')
    SECINNERCODE = Column(VARCHAR(200), comment='证券内码')
    FMANAGER = Column(VARCHAR(60), comment='基金经理')
    IAIM = Column(CLOB, comment='投资目标')
    IIDEA = Column(CLOB, comment='投资理念')
    PENDDATE = Column(Date, comment='原存续终止日')
    RISKMANAGER = Column(CLOB, comment='风险管理工具及主要指标')
    FINTRO = Column(CLOB, comment='基金简介')
    TRUSTEECODE = Column(VARCHAR(16), comment='基金托管人代码')
    MANAGERCODE = Column(VARCHAR(16), comment='基金管理人代码')
    FOUNDDATE = Column(Date, comment='成立日期')
    SECURITYSNAME = Column(VARCHAR(100), comment='基金简称')
    ESOURCEMEMO = Column(VARCHAR(100))
    SECURITYCODE = Column(VARCHAR(12), comment='基金代码')
    FTOTAL = Column(Numeric(38, 18), comment='基金单位总额')
    ISTANDARD = Column(CLOB, comment='投资标准')
    NOTICEDATE = Column(Date, comment='公告日期')
    PHONE = Column(VARCHAR(100), comment='信息披露电话')
    SECURITYNAME = Column(VARCHAR(200), comment='基金法定名称')
    ALLOTRULE = Column(CLOB, comment='分配原则')
    RELEASER = Column(VARCHAR(60), comment='信息披露人')
    RISKINCOME = Column(CLOB, comment='风险收益特征')
    ISTRATERGY = Column(CLOB, comment='投资策略')
    IRANGE = Column(CLOB, comment='投资范围')
    EID = Column(Numeric(18, 0), primary_key=True)
    ESEQID = Column(Numeric(20, 0))
    EITIME = Column(Date)
    EUTIME = Column(Date)
    EGETTIME = Column(Date)
    EISDEL = Column(CHAR(1))


class FUNDBSFEXECUTIVE(Base):
    """
    基金高管
    """
    __tablename__ = 'fund_bs_fexecutive'
    __table_args__ = (
        Index('PK_LG_FUND_BS_FEXECUTIVE', 'SECURITYCODE', 'POST', 'PERSONCODE', 'CHANGEDATE'),)
    ISPOSITION = Column(Numeric(20, 8), comment='是否现任 (NIPMID: 127000000021910162)')
    SEX = Column(VARCHAR(4), comment='性别 (NIPMID: 127000000001707335)')
    JOBTITLE = Column(VARCHAR(120), comment='职称 (NIPMID: 127000000842179077)')
    POST = Column(VARCHAR(160), comment='基金职务 (NIPMID: 127000000021907159)')
    DEGREE = Column(VARCHAR(80), comment='学历 (NIPMID: 127000000842179156)')
    DATASOURCE = Column(VARCHAR(100), comment='数据来源 (NIPMID: 127000000842179176)')
    BIRTHDATE = Column(Date, comment='出生日期')
    PERSONCODE = Column(VARCHAR(16), comment='人员代码')
    REASON = Column(VARCHAR(200), comment='离任原因')
    SECINNERCODE = Column(VARCHAR(200), comment='证券内码')
    ESOURCEMEMO = Column(VARCHAR(100))
    CHANGEDATE = Column(Date, comment='变动日期')
    PATICTERM = Column(Numeric(38, 18), comment='从业年限')
    ENDDATE = Column(Date, comment='离任日期')
    NOTICEDATE = Column(Date, comment='公告日期')
    REMARK = Column(CLOB, comment='附注')
    SECURITYCODE = Column(VARCHAR(12), comment='基金代码')
    EID = Column(Numeric(18, 0), primary_key=True)
    ESEQID = Column(Numeric(20, 0))
    EITIME = Column(Date)
    EUTIME = Column(Date)
    EGETTIME = Column(Date)
    EISDEL = Column(CHAR(1))
    PERSONNAME = Column(NVARCHAR(200), comment='姓名')
    RESUME = Column(NCLOB, comment='简历')


class CFPPVALUE(Base):
    """None"""
    __tablename__ = 'cfp_pvalue'
    PARAMID = Column(Numeric(18, 0), comment='参数ID')
    VAL2 = Column(NVARCHAR(100), comment='备用值2')
    VAL1 = Column(NVARCHAR(100), comment='备用值1')
    PARAMORDER = Column(NVARCHAR(50), comment='参数序号')
    ENSHORT = Column(NVARCHAR(100), comment='英文缩写')
    EID_TMP2 = Column(Numeric(29, 0))
    PARAMCODE = Column(NVARCHAR(100), comment='参数编码(录入新增)')
    EID_OLD = Column(Numeric(29, 0))
    ESOURCEMEMO = Column(VARCHAR(100))
    NIPMID_OLD = Column(Numeric(29, 0))
    VCVALUE = Column(NVARCHAR(50))
    NIPMID = Column(Numeric(20, 0))
    PARAMCHNAME = Column(NVARCHAR(100), comment='参数中文名(录入新增)')
    MEMO = Column(NVARCHAR(500), comment='备注')
    NIVTYPE = Column(Numeric(10, 0))
    EID_LONG = Column(Numeric(29, 0))
    EID = Column(Numeric(18, 0), primary_key=True)
    ESEQID = Column(Numeric(20, 0))
    EITIME = Column(Date)
    EUTIME = Column(Date)
    EGETTIME = Column(Date)
    EISDEL = Column(CHAR(1))
    PARAM_NAME_TC = Column(NVARCHAR(100), comment='参数中文名(繁体)')


class LICOIMINCHG(Base):
    """行业分类变动"""
    __tablename__ = 'lico_im_inchg'
    __table_args__ = (
        Index('PK_LG_LICO_IM_INCHG', 'INDTYPE', 'INDSORT', 'COMPANYCODE', 'CHANGEDATE'),)
    INDTYPE = Column(VARCHAR(100), comment='行业类型 (NIPMID: 127000000843325192)')
    FINLOGO = Column(Numeric(20, 8), comment='首次入库标识 (NIPMID: 127000000843738245)')
    NSHALOGO = Column(Numeric(20, 8), comment='新股标识 (NIPMID: 127000000843737862)')
    INDSORT = Column(VARCHAR(100), comment='行业类别 (NIPMID: 127000000843737369)')
    ISNEW = Column(CHAR(1), comment='是否最新 (NIPMID: 127000000024644623)')
    CHANGEDATE = Column(Date, comment='变动日期')
    INDCODE = Column(VARCHAR(100), comment='行业代码')
    COMPANYCODE = Column(VARCHAR(16), comment='公司代码')
    NOTICEDATE = Column(Date, comment='公告日期')
    CHGNUM = Column(Numeric(20, 8), comment='变动次数')
    YEARS = Column(VARCHAR(8), comment='年度')
    ESOURCEMEMO = Column(VARCHAR(100))
    REMARK = Column(CLOB, comment='附注')
    EID = Column(Numeric(18, 0), primary_key=True)
    ESEQID = Column(Numeric(20, 0))
    EITIME = Column(Date)
    EUTIME = Column(Date)
    EGETTIME = Column(Date)
    EISDEL = Column(CHAR(1))
    SECURITY_INNER_CODE = Column(VARCHAR(50), comment='证券内码')


class CDSYSECUCODE(Base):
    """证券代码表"""
    __tablename__ = 'cdsy_secucode'
    __table_args__ = (
        Index('PK_LG_CDSY_SECUCODE', 'TRADEMARKETCODE', 'SECURITYTYPECODE', 'SECURITYCODE', 'SECINNERCODE',
              'COMPANYCODE'),)
    TRADEMARKET = Column(VARCHAR(400), comment='交易市场 (NIPMID: 127000000001707275)')
    TRADEMARKETCODE = Column(VARCHAR(400), comment='交易市场编码 (NIPMID: 127000000001707275)')
    SECURITYTYPECODE = Column(VARCHAR(400), comment='证券类型编码 (NIPMID: 127000000001707274)')
    SECURITYTYPE = Column(VARCHAR(400), comment='证券类型 (NIPMID: 127000000001707274)')
    CURRENCY = Column(VARCHAR(160), comment='计量货币 (NIPMID: 127000000001707314)')
    USESTATE = Column(CHAR(2), comment='使用状态 (NIPMID: 127000000541478933)')
    LISTSTATE = Column(VARCHAR(24), comment='上市状态 (NIPMID: 127000000001707312)')
    SECINNERCODE = Column(VARCHAR(200), comment='证券内码')
    LISTDATE = Column(Date, comment='上市日期')
    CODETYPE = Column(VARCHAR(24), comment='代码属性(废弃)')
    ESOURCEMEMO = Column(VARCHAR(100), comment='ESOURCEMEMO')
    ENDDATE = Column(Date, comment='截止日期')
    EXPAND_NAME_ABBR = Column(VARCHAR(400), comment='扩位简称')
    COMPANYCODE = Column(VARCHAR(400), comment='发行机构代码')
    SECURITYNAME = Column(VARCHAR(1600), comment='证券全称')
    SECURITYCODE = Column(VARCHAR(160), comment='证券代码')
    SPELL = Column(VARCHAR(800), comment='证券拼音')
    SECURITYSNAME = Column(VARCHAR(800), comment='证券简称')
    EID = Column(Numeric(18, 0), primary_key=True)
    ESEQID = Column(Numeric(20, 0))
    EITIME = Column(Date)
    EUTIME = Column(Date)
    EGETTIME = Column(Date)
    EISDEL = Column(CHAR(1))
    PREDICT_LTD = Column(Date, comment='预计最后交易日')


class CDSYKPPUBLISHRELATION(Base):
    """板块关系对照新表"""
    __tablename__ = 'cdsy_kp_publishrelation'
    PUBLISHCODE = Column(VARCHAR(100), comment='板块编码')
    PUBLISHTYPE = Column(VARCHAR(200), comment='板块节点类型')
    CATEGORYNAME = Column(VARCHAR(400), comment='分类名称')
    ISIMPORTANT = Column(VARCHAR(200), comment='是否重要板块')
    PUBLISHNAME = Column(VARCHAR(400), comment='板块名称')
    CATEGORYCODE = Column(VARCHAR(20), comment='分类编码')
    INDEXINNERCODE = Column(VARCHAR(100), comment='主指数内码')
    ISPROCESS = Column(CHAR(1), comment='是否有历史成分')
    ISUSABLE = Column(Numeric(20, 8), comment='是否可用')
    NUM = Column(Numeric(20, 8), comment='排序')
    TMPL = Column(VARCHAR(20), comment='行情报价适用模板')
    ESOURCEMEMO = Column(VARCHAR(100))
    ORIGINALCODE = Column(VARCHAR(100), comment='原始编码')
    EMINDEXCODE = Column(VARCHAR(100), comment='东财指数编码')
    PUBKEYCODE = Column(VARCHAR(20), comment='板块内码')
    PARENTCODE = Column(VARCHAR(100), comment='父节点编码')
    EID = Column(Numeric(18, 0), primary_key=True)
    ESEQID = Column(Numeric(20, 0))
    EITIME = Column(Date)
    EUTIME = Column(Date)
    EGETTIME = Column(Date)
    EISDEL = Column(CHAR(1))


class FUNDBSINFOCHANGE(Base):
    """None"""
    __tablename__ = 'fund_bs_infochange'
    __table_args__ = (
        Index('PK_LG_FUND_BS_INFOCHANGE', 'SECURITYCODE', 'NOTICEDATE', 'CHANGETYPE', 'CHANGEDATE'),)
    CHANGETYPE = Column(VARCHAR(200), comment='基金变动类型 (NIPMID: 127000000842318503)')
    REMARK = Column(CLOB, comment='附注')
    SECURITYCODE = Column(VARCHAR(16), comment='基金代码')
    BCHANGE = Column(VARCHAR(4000), comment='变动前')
    NOTICEDATE = Column(Date, comment='公告日期')
    SECINNERCODE = Column(VARCHAR(200), comment='证券内码')
    ACHANGE = Column(VARCHAR(4000), comment='变动后')
    CHANGEDATE = Column(Date, comment='变动日期')
    ESOURCEMEMO = Column(VARCHAR(100))
    EID = Column(Numeric(18, 0), primary_key=True)
    ESEQID = Column(Numeric(20, 0))
    EITIME = Column(Date)
    EUTIME = Column(Date)
    EGETTIME = Column(Date)
    EISDEL = Column(CHAR(1))
    BEFORE_CHANGE_TEXT = Column(NCLOB, comment="变动前(长文本)")
    AFTER_CHANGE_TEXT = Column(NCLOB, comment="变动后(长文本)")
