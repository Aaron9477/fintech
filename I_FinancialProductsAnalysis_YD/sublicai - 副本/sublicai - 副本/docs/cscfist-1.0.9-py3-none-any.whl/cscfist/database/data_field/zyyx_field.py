from sqlalchemy import Column, VARCHAR, Numeric, Index, Float, NVARCHAR, Date, MetaData
from sqlalchemy.ext.declarative import declarative_base

metadata = MetaData(schema='ZYYX')
Base = declarative_base(metadata=metadata)


class DER_PROB_EXCESS_STOCK(Base):
    """None"""
    __tablename__ = 'der_prob_excess_stock'
    __table_args__ = (
        Index('IDX96620012', 'TMSTAMP'),
        Index('IDX96620010', 'ENTRYTIME'),)
    ID = Column(Numeric(20, 0), primary_key=True)
    STOCK_CODE = Column(VARCHAR(20))
    STOCK_NAME = Column(VARCHAR(100))
    REPORT_YEAR = Column(Numeric(10, 0))
    REPORT_QUARTER = Column(Numeric(10, 0))
    DECLARE_DATE = Column(Date)
    INFORMATION_CODE = Column(VARCHAR(10))
    INFORMATION_TYPE = Column(VARCHAR(50))
    INFORMATION_DESCRIPTION = Column(VARCHAR(1000))
    ENTRYTIME = Column(Date)
    UPDATETIME = Column(Date)
    TMSTAMP = Column(Numeric(20, 0))


class RPT_EARNINGS_ADJUST(Base):
    """None"""
    __tablename__ = 'rpt_earnings_adjust'
    __table_args__ = (
        Index('IDX44475852', 'CURRENT_CREATE_DATE'),
        Index('IDX44475853', 'ENTRYTIME'),
        Index('IDX46571946', 'TMSTAMP'),)
    ID = Column(Numeric(10, 0), primary_key=True)
    REPORT_ID = Column(Numeric(10, 0))
    STOCK_CODE = Column(NVARCHAR(20))
    STOCK_NAME = Column(NVARCHAR(50))
    TITLE = Column(NVARCHAR(150))
    REPORT_TYPE = Column(Numeric(10, 0))
    ORGAN_ID = Column(Numeric(10, 0))
    ORGAN_NAME = Column(NVARCHAR(50))
    AUTHOR = Column(NVARCHAR(200))
    REPORT_YEAR = Column(Numeric(10, 0))
    CURRENT_CREATE_DATE = Column(Date)
    PREVIOUS_CREATE_DATE = Column(Date)
    CURRENT_FORECAST_NP = Column(Float)
    PREVIOUS_FORECAST_NP = Column(Float)
    NP_ADJUST_RATE = Column(Float)
    NP_ADJUST_MARK = Column(Numeric(10, 0))
    CURRENT_FORECAST_EPS = Column(Float)
    PREVIOUS_FORECAST_EPS = Column(Float)
    EPS_ADJUST_RATE = Column(Float)
    EPS_ADJUST_MARK = Column(Numeric(10, 0))
    IS_CAPITAL_DIFFERENT = Column(Numeric(10, 0))
    ENTRYTIME = Column(Date)
    UPDATETIME = Column(Date)
    TMSTAMP = Column(Numeric(20, 0))


class DER_PROB_BELOW_STOCK(Base):
    """None"""
    __tablename__ = 'der_prob_below_stock'
    __table_args__ = (
        Index('IDX96618774', 'TMSTAMP'),)
    ID = Column(Numeric(10, 0), comment='流水号')
    STOCK_CODE = Column(VARCHAR(30), primary_key=True, comment='股票代码')
    STOCK_NAME = Column(VARCHAR(30), comment='股票简称')
    REPORT_YEAR = Column(Numeric(10, 0), primary_key=True, comment='报表年度')
    REPORT_QUARTER = Column(Numeric(10, 0), primary_key=True, comment='报表期类型(1:一季度 2:中报 3:三季度 4:年报 5:其他)')
    DECLARE_DATE = Column(Date, primary_key=True, comment='公告日期')
    INFORMATION_CODE = Column(VARCHAR(20), primary_key=True, comment='信息类别代码')
    INFORMATION_TYPE = Column(VARCHAR(50), comment='信息类别描述')
    INFORMATION_DESCRIPTION = Column(VARCHAR(500), primary_key=True, comment='信息描述')
    ENTRYTIME = Column(Date, comment='入库时间')
    UPDATETIME = Column(Date, comment='最后更新时间')
    TMSTAMP = Column(Numeric(20, 0), comment='时间戳')


class RPT_RATING_ADJUST(Base):
    """None"""
    __tablename__ = 'rpt_rating_adjust'
    __table_args__ = (
        Index('IDX44475986', 'CURRENT_CREATE_DATE'),
        Index('IDX44475987', 'ENTRYTIME'),
        Index('IDX48024147', 'TMSTAMP'),)
    ID = Column(Numeric(10, 0), primary_key=True)
    REPORT_ID = Column(Numeric(10, 0))
    STOCK_CODE = Column(NVARCHAR(20))
    STOCK_NAME = Column(NVARCHAR(50))
    TITLE = Column(NVARCHAR(150))
    REPORT_TYPE = Column(Numeric(10, 0))
    ORGAN_ID = Column(Numeric(10, 0))
    ORGAN_NAME = Column(NVARCHAR(50))
    AUTHOR = Column(NVARCHAR(200))
    CURRENT_CREATE_DATE = Column(Date)
    PREVIOUS_CREATE_DATE = Column(Date)
    CURRENT_GG_RATING = Column(NVARCHAR(4))
    PREVIOUS_GG_RATING = Column(NVARCHAR(4))
    RATING_ADJUST_MARK = Column(Numeric(10, 0))
    ENTRYTIME = Column(Date)
    UPDATETIME = Column(Date)
    TMSTAMP = Column(Numeric(20, 0))
