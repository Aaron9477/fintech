"""
私募基金基金信息表结构定义
"""
from sqlalchemy import Column
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.types import Integer, VARCHAR, Numeric, CLOB, DATE

Base = declarative_base()

__all__ = ["PFundNav", "PCompanyInfo", "PFundAssetSize", "PFundManagerMapping", "PFundStrategy", "PFundInfo",
           "PFundCompanyInfo", "PFundFee", "PFundStatus", "PPersonnelInfo", "PFundPersonnelCompanyMapping",
           "PvnDistribution"]


class PFundNav(Base):
    __tablename__ = 'PVN_NAV'

    ID = Column(VARCHAR(100, 'Chinese_PRC_BIN'), primary_key=True)
    FUND_ID = Column(VARCHAR(40, 'Chinese_PRC_BIN'), comment="基金id")
    PRICE_DATE = Column(DATE, comment='净值日期')
    NAV = Column(Numeric(22, 6), comment="单位净值")
    CUMULATIVE_NAV = Column(Numeric(22, 6), comment="考虑分红再投资的单位累计净值")
    CUMULATIVE_NAV_WITHDRAWAL = Column(Numeric(22, 6), comment="分红不投资的单位累计净值")
    ISVALID = Column(Numeric(22, 6), comment="是否有效")


class PCompanyInfo(Base):
    __tablename__ = 'PVN_COMPANY_INFO'
    COMPANY_ID = Column(VARCHAR(10, 'Chinese_PRC_BIN'), primary_key=True, comment='公司id')
    COMPANY_NAME = Column(VARCHAR(255, 'Chinese_PRC_BIN'), comment='公司中文全称')
    COMPANY_SHORT_NAME = Column(VARCHAR(80, 'Chinese_PRC_BIN'), comment='公司中文简称')
    ISVALID = Column(Numeric(22, 6), comment="是否有效")
    ISVISIBLE = Column(Integer, comment='是否可见')


class PFundAssetSize(Base):
    __tablename__ = 'PVN_FUND_ASSET_SIZE'
    ID = Column(VARCHAR(100, 'Chinese_PRC_BIN'), primary_key=True)
    FUND_ID = Column(VARCHAR(40, 'Chinese_PRC_BIN'), comment="基金id")
    FUND_ASSET_SIZE_DATE = Column(DATE, comment='规模日期')
    FUND_ASSET_SIZE = Column(Numeric(22, 6), comment="基金资产规模")
    ISVALID = Column(Integer, comment='有效性')


class PFundManagerMapping(Base):
    __tablename__ = 'PVN_FUND_MANAGER_MAPPING'
    ID = Column(VARCHAR(100, 'Chinese_PRC_BIN'), primary_key=True)
    FUND_ID = Column(VARCHAR(40, 'Chinese_PRC_BIN'), comment="基金id")
    FUND_MANAGER_ID = Column(VARCHAR(40, 'Chinese_PRC_BIN'), comment="基金经理id")
    MANAGEMENT_START_DATE = Column(DATE, comment='基金管理开始日期')
    MANAGEMENT_END_DATE = Column(DATE, comment='基金管理结束日期')
    ISVALID = Column(Integer, comment='有效性')
    ISVISIBLE = Column(Integer, comment='是否可见')


class PFundStrategy(Base):
    __tablename__ = 'PVN_FUND_STRATEGY'
    FUND_ID = Column(VARCHAR(40, 'Chinese_PRC_BIN'), comment="基金id", primary_key=True)
    STRATEGY = Column(Integer, comment='融智策略分类')
    SUBSTRATEGY = Column(Integer, comment='融智子策略分类')
    ISVALID = Column(Integer, comment="记录的有效性; 1-有效; 0-无效")


class PFundInfo(Base):
    """私募基金基本信息"""
    __tablename__ = 'PVN_FUND_INFO'
    ID = Column(VARCHAR(100, 'Chinese_PRC_BIN'), primary_key=True)
    FUND_ID = Column(VARCHAR(40, 'Chinese_PRC_BIN'), comment="基金id")
    FUND_NAME = Column(VARCHAR(255, 'Chinese_PRC_BIN'), comment='基金中文全称')
    FUND_SHORT_NAME = Column(VARCHAR(80, 'Chinese_PRC_BIN'), comment='基金中文简称')
    FUND_STRUCTURE = Column(Numeric(22), comment='基金形式')
    FUND_TYPE = Column(Numeric(22), comment='基金类型')
    TRUST_ID = Column(VARCHAR(10, 'Chinese_PRC_BIN'), comment="基金管理公司id")
    INCEPTION_DATE = Column(DATE, comment='基金成立日期')
    BASE_CURRENCY = Column(Integer, comment='基础货币')
    CUSTODIAN_ID = Column(VARCHAR(10, 'Chinese_PRC_BIN'), comment="托管银行id")
    ISVISIBLE = Column(Integer, comment='是否可见')
    ISVALID = Column(Integer, comment="记录的有效性; 1-有效; 0-无效")


class PFundCompanyInfo(Base):
    """公司基本信息"""
    __tablename__ = 'pvn_company_info'
    P_COMPANY_ID = Column(VARCHAR(10, 'Chinese_PRC_BIN'), comment="上级公司id", primary_key=True)
    COMPANY_ID = Column(VARCHAR(10, 'Chinese_PRC_BIN'), comment="公司id")
    COMPANY_NAME = Column(VARCHAR(255, 'Chinese_PRC_BIN'), comment="公司中文全称")
    COMPANY_SHORT_NAME = Column(VARCHAR(80, 'Chinese_PRC_BIN'), comment="公司中文简称")
    COMPANY_TYPE = Column(Integer, comment="公司类型")
    ESTABLISH_DATE = Column(DATE, comment="公司成立日期")
    COMPANY_ADDRESS = Column(VARCHAR(255, 'Chinese_PRC_BIN'), comment="公司注册地址")
    COMPANY_ADDRESS2 = Column(VARCHAR(255, 'Chinese_PRC_BIN'), comment="办公地址")
    CONTACT_PHONE = Column(VARCHAR(20, 'Chinese_PRC_BIN'), comment="联系电话")
    WEBSITE = Column(VARCHAR(255, 'Chinese_PRC_BIN'), comment="公司网址")
    LEGAL_REPRESENTATIVE = Column(VARCHAR(100, 'Chinese_PRC_BIN'), comment="法人代表")
    ISVISIBLE = Column(Integer, comment='基金在前台是否可见')
    ISVALID = Column(Integer, comment="记录的有效性; 1-有效; 0-无效")


class PFundFee(Base):
    __tablename__ = 'PVN_FUND_RATE_MAPPING'
    FUND_ID = Column(VARCHAR(30, 'Chinese_PRC_BIN'), primary_key=True, comment="基金id")
    MIN_INVESTMENT_SHARE = Column(Numeric(22, 6), comment="最低认购额")
    SUBSEQUENT_INVESTMENT_SHARE = Column(Numeric(22, 6), comment="最低追加额")
    SUBSCRIPTION_FEE = Column(Numeric(22, 6), comment="最高认购费")
    REDEMPTION_FEE = Column(Numeric(22, 6), comment="最高赎回费")
    MANAGEMENTFEE_TRUST = Column(Numeric(22), comment='受托人管理费')
    MANAGEMENTFEE_BANK = Column(Numeric(22), comment='银行托管费')
    PERFORMANCE_FEE = Column(Numeric(22), comment='业绩报酬')
    ISVALID = Column(Integer, comment="记录的有效性; 1-有效; 0-无效")


class PFundStatus(Base):
    __tablename__ = 'PVN_FUND_STATUS'
    ID = Column(VARCHAR(100, 'Chinese_PRC_BIN'), primary_key=True)
    FUND_ID = Column(VARCHAR(10, 'Chinese_PRC_BIN'), primary_key=True, comment="基金id")
    FUND_STATUS = Column(Integer, comment="基金运行状态")
    STATUS_START_DATE = Column(DATE, comment="募集开始时间")
    STATUS_END_DATE = Column(DATE, comment="募集开始时间")
    LIQUIDATE_DATE = Column(DATE, comment="清算日期")
    ISVALID = Column(Integer, comment="记录的有效性")


class PPersonnelInfo(Base):
    __tablename__ = 'PVN_PERSONNEL_INFO'
    PERSONNEL_ID = Column(VARCHAR(10, 'Chinese_PRC_BIN'), primary_key=True, comment='人员id')
    PERSONNEL_NAME = Column(VARCHAR(40), comment="姓名")
    PERSONNEL_TYPE = Column(Integer, comment="人员类别")
    SEX = Column(Integer, comment="性别")
    EDUCATION = Column(Integer, comment="最高学历")
    VPROFILE = Column(CLOB, comment="人物简介")
    ISVISIBLE = Column(Numeric(22), comment='前台是否可见')
    ISVALID = Column(Integer, comment="记录的有效性; 1-有效; 0-无效")


class PvnDistribution(Base):
    __tablename__ = 'PVN_DISTRIBUTION'
    ID = Column(Integer, primary_key=True)
    FUND_ID = Column(VARCHAR(10, 'Chinese_PRC_BIN'), primary_key=True, comment="基金id")
    DISTRIBUTE_DATE = Column(DATE, comment='分配日期')
    DISTRIBUTE_TYPE = Column(Integer, comment='基金分配类型标志：-1-其他，1-分红，2-拆分,3-业绩报酬,4-注资,5-撤资')
    distribution = Column(Numeric(22), comment='分红/拆分比例')
    ISVALID = Column(Integer, comment="记录的有效性; 1-有效; 0-无效")


class PFundPersonnelCompanyMapping(Base):
    __tablename__ = 'pvn_personnel_company_mapping'
    ID = Column(VARCHAR(100, 'Chinese_PRC_BIN'), primary_key=True)
    PERSONNEL_ID = Column(VARCHAR(10, 'Chinese_PRC_BIN'), comment='人员id')
    COMPANY_ID = Column(VARCHAR(10), comment='公司id')
    PERSONNEL_TYPE = Column(Integer, comment="人员类型")
    START_DATE = Column(DATE, comment="任职开始日期")
    END_DATE = Column(DATE, comment="任职结束日期")
    IS_VISIBLE = Column(Numeric(22), comment='前台是否可见')
    ISVALID = Column(Integer, comment="记录的有效性; 1-有效; 0-无效")
