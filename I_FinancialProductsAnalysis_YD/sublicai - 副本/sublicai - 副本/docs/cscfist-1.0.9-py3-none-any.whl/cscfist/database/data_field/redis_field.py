# -*- coding: utf-8 -*-
from cscfist import NatureDateUtils
from cscfist.model.db_model.redis_model.abstract_table import AbstractRedisTable
from cscfist.model.db_model.redis_model.column import Column


class AShareEodPricesCache(AbstractRedisTable):
    """
    时间序列型Redis
    """
    __redis_name__ = 'ts:wind:ashare:eod:prices'
    __redis_type__ = 'time_series'
    S_INFO_WINDCODE = Column(str, is_ts_code=True)
    TRADE_DT = Column(str, is_ts_date=True)
    S_DQ_ADJCLOSE = Column(float)
    S_DQ_ADJPRECLOSE = Column(float)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class ChinaMutualFundNavCache(AbstractRedisTable):
    """
    时间序列型Redis
    """
    __redis_name__ = 'ts:wind:china_mutual_fund:nav'
    __redis_type__ = 'time_series'
    F_INFO_WINDCODE = Column(str, is_ts_code=True)
    PRICE_DATE = Column(str, is_ts_date=True)
    F_NAV_UNIT = Column(int)
    F_NAV_ACCUMULATED = Column(int)
    F_NAV_ADJUSTED = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class AShareCalendarCache(AbstractRedisTable):
    """
    A股交易日历
    """
    __redis_name__ = 'ts:wind:a_share:calendar'
    __redis_type__ = 'time_series'
    exchange_code = Column(str, is_ts_code=True, comment="交易所代码")
    trade_date = Column(str, is_ts_date=True, comment="交易日期")
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class ChinaMutualFundCompoundFundBenchmarkCache(AbstractRedisTable):
    """
    复合基准
    """
    __redis_name__ = "ts:wind:china_mutual_fund:compound_benchmark_eod"
    __redis_type__ = 'time_series'
    S_INFO_WINDCODE = Column(str, is_ts_code=True)
    TRADE_DT = Column(str, is_ts_date=True)
    S_DQ_CLOSE = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class ChinaMutualFundNavContinuousCache(AbstractRedisTable):
    """
    基金连续行情
    """
    __redis_name__ = "ts:wind:china_mutual_fund:nav_continuous"
    __redis_type__ = "time_series"
    F_INFO_WINDCODE = Column(str, is_ts_code=True)
    PRICE_DATE = Column(str, is_ts_date=True)
    F_NAV_UNIT = Column(int)
    F_NAV_ACCUMULATED = Column(int)
    F_NAV_ADJUSTED = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class ChinaMutualFundBenchmarkEodCache(AbstractRedisTable):
    """
    基金基准行情
    """
    __redis_name__ = "ts:wind:china_mutual_fund:benchmark_eod"
    __redis_type__ = "time_series"
    S_INFO_WINDCODE = Column(str, is_ts_code=True)
    TRADE_DT = Column(str, is_ts_date=True)
    S_DQ_CLOSE = Column(int)
    S_DQ_PCTCHANGE = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class AllIndexEodPricesCache(AbstractRedisTable):
    """
    相关指数行情
    """
    __redis_name__ = "ts:wind:all_index:eod_prices"
    __redis_type__ = "time_series"
    S_INFO_WINDCODE = Column(str, is_ts_code=True)
    TRADE_DT = Column(str, is_ts_date=True)
    S_DQ_CLOSE = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class CBondIndexEodCNBDCache(AbstractRedisTable):
    """
    中债登指数行情
    """
    __redis_name__ = "ts:wind:c_bond:index_eod_cnbd"
    __redis_type__ = "time_series"
    S_INFO_WINDCODE = Column(str, is_ts_code=True)
    TRADE_DT = Column(str, is_ts_date=True)
    S_DQ_CLOSE = Column(int)
    S_VAL_PE = Column(int)
    AVGMVDURATION = Column(int)
    AVGCF = Column(int)
    AVG_VALUE_CONVEXITY = Column(int)
    AVG_CASH_CONVEXITY = Column(int)
    AVG_CASH_YTM = Column(int)
    AVG_MATU = Column(int)
    AVG_DIVIDEND_RATE = Column(int)
    AVG_VOBP = Column(int)
    PENDING_TERM_CODE = Column(int)
    SPOT_SETTLEMENT = Column(int)
    AVG_VALUE_YTM = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class ChinaMutualFundNavNetAssetTotalCache(AbstractRedisTable):
    """
    基金总资产
    """
    __redis_name__ = "ts:wind:china_mutual_fund:nav_net_asset_total"
    __redis_type__ = "time_series"
    F_INFO_WINDCODE = Column(str, is_ts_code=True)
    PRICE_DATE = Column(str, is_ts_date=True)
    NETASSET_TOTAL = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class ChinaMutualFundNavFPRTNetAssetCache(AbstractRedisTable):
    """
    基金净资产
    """
    __redis_name__ = "ts:wind:china_mutual_fund:nav_f_prt_net_asset"
    __redis_type__ = "time_series"
    F_INFO_WINDCODE = Column(str, is_ts_code=True)
    PRICE_DATE = Column(str, is_ts_date=True)
    F_PRT_NETASSET = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class CMoneyMarketDailyFIncomeCache(AbstractRedisTable):
    """"""
    __redis_name__ = "ts:wind:c_money:market_daily_f_income"
    __redis_type__ = "time_series"
    S_INFO_WINDCODE = Column(str, is_ts_code=True)
    F_INFO_ENDDATE = Column(str, is_ts_date=True)
    F_INFO_BGNDATE = Column(str)
    F_INCOME_PER_MILLION = Column(int)
    F_INFO_YEARLYROE = Column(int)
    ANN_DATE = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class CMMQuarterlyDataCache(AbstractRedisTable):
    """"""
    __redis_name__ = "ts:wind:cmm:quarterly_data"
    __redis_type__ = "time_series"
    S_INFO_WINDCODE = Column(str, is_ts_code=True)
    F_INFO_BGNDATE = Column(str)
    F_INFO_ENDDATE = Column(str, is_ts_date=True)
    FLOATING_BOND_AMOUNT = Column(int)
    FLOATING_BOND_AMOUNT_RATIO = Column(int)
    BONDREPO_BALANCE = Column(int)
    BONDREPO_BALANCE_RATIO = Column(int)
    END_BONDREPO_BALANCE = Column(int)
    END_BONDREPO_BALANCE_RATIO = Column(int)
    AVG_REMAINDER_PERIOD_MAX = Column(int)
    DEVIATION_DEGREE_FREQUENCY = Column(int)
    DEVIATION_DEGREE_MAX = Column(int)
    DEVIATION_DEGREE_MIN = Column(int)
    DEVIATION_DEGREE_AVG_VALUE = Column(int)
    FIXED_DEPOSIT = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class ChinaClosedFundEodPriceCache(AbstractRedisTable):
    __redis_name__ = "ts:wind:china_closed_fund:eod_price"
    __redis_type__ = "time_series"
    S_INFO_WINDCODE = Column(str, is_ts_code=True)
    TRADE_DT = Column(str, is_ts_date=True)
    S_DQ_PRECLOSE = Column(int)
    S_DQ_OPEN = Column(int)
    S_DQ_HIGH = Column(int)
    S_DQ_LOW = Column(int)
    S_DQ_CLOSE = Column(int)
    S_DQ_CHANGE = Column(int)
    S_DQ_PCTCHANGE = Column(int)
    S_DQ_VOLUME = Column(int)
    S_DQ_AMOUNT = Column(int)
    S_DQ_ADJPRECLOSE = Column(int)
    S_DQ_ADJOPEN = Column(int)
    S_DQ_ADJHIGH = Column(int)
    S_DQ_ADJLOW = Column(int)
    S_DQ_ADJCLOSE = Column(int)
    S_DQ_ADJFACTOR = Column(int)
    TRADES_COUNT = Column(int)
    DISCOUNT_RATE = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class ChinaMutualFundFloatShareCache(AbstractRedisTable):
    """
    中国共同基金场内流通份额
    """
    __redis_name__ = "ts:wind:china_mutual_fund:float_share"
    __redis_type__ = "time_series"
    S_INFO_WINDCODE = Column(str, is_ts_code=True)
    TRADE_DT = Column(str, is_ts_date=True)
    F_UNIT_FLOATSHARE = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class CBondCurveCNBDChinaBondGovYTM10yCache(AbstractRedisTable):
    """
    10年期国债收益率曲线
    """
    __redis_name__ = "ts:wind:c_bond:curve_cnbd_china_bond_gov_ytm_10y"
    __redis_type__ = "time_series"
    B_ANAL_CURVENUMBER = Column(str, is_ts_code=True)
    TRADE_DT = Column(str, is_ts_date=True)
    B_ANAL_YIELD = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class HKShareEodPricesCache(AbstractRedisTable):
    """
    港股股票日行情
    """
    __redis_name__ = "ts:wind:hk:eod_prices"
    __redis_type__ = "time_series"
    S_INFO_WINDCODE = Column(str, is_ts_code=True)
    TRADE_DT = Column(str, is_ts_date=True)
    S_DQ_ADJCLOSE = Column(int)
    S_DQ_ADJPRECLOSE = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class ChinaMutualFundDescriptionCache(AbstractRedisTable):
    """
    中国共同基金基本资料
    """
    __redis_name__ = "cross:wind:china_mutual_fund:description"
    __redis_type__ = "cross_sectional"
    F_INFO_WINDCODE = Column(str, is_hash_key=True)
    F_INFO_FULLNAME = Column(str)
    F_INFO_NAME = Column(str)
    F_INFO_CORP_FUNDMANAGEMENTCOMP = Column(str)
    F_INFO_CORP_FUNDMANAGEMENTID = Column(str)
    F_INFO_STATUS = Column(int)
    F_INFO_SETUPDATE = Column(str)
    F_INFO_DELISTDATE = Column(str)
    F_INFO_LISTDATE = Column(str)
    F_INFO_MATURITYDATE = Column(str)
    F_INFO_FUND_ID = Column(str)
    F_PCHREDM_PCHSTARTDATE = Column(str)
    F_INFO_REDMSTARTDATE = Column(str)
    F_INFO_MINBUYAMOUNT = Column(int)
    F_INFO_ISINITIAL = Column(int)
    F_PERSONAL_STARTDATEIND = Column(int)
    F_PERSONAL_ENDDATEIND = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class ChinaMFDividendCache(AbstractRedisTable):
    """
    中国共同基金分红
    """
    __redis_name__ = "cross:wind:china_mf:dividend"
    __redis_type__ = "cross_sectional"
    S_INFO_WINDCODE = Column(str, is_hash_key=True, comment='Wind代码')
    F_E_BCH_DT = Column(str, comment='可分配收益基准日')
    F_DIV_PROGRESS = Column(str, comment='方案进度')
    CASH_DVD_PER_SH_TAX = Column(float, comment='每股派息(元)')
    CRNCY_CODE = Column(str, comment='货币代码')
    EQY_RECORD_DT = Column(str, comment='权益登记日')
    EX_DT = Column(str, comment='除息日')
    F_DIV_EDEXDATE = Column(str, comment='除息日(场外)')
    PAY_DT = Column(str, comment='派息日')
    F_DIV_PAYDATE = Column(str, comment='派息日(场外)')
    F_DIV_IMPDATE = Column(str, comment='分红实施公告日')
    F_SH_BCH_Y = Column(str, comment='份额基准年度')
    F_BCH_UNIT = Column(float, comment='基准基金份额(万份)')
    F_E_APR = Column(float, comment='可分配收益(元)')
    F_EX_DIV_DT = Column(str, comment='净值除权日')
    F_E_APR_AMOUNT = Column(float, comment='收益分配金额(元)')
    F_REINV_BCH_DT = Column(str, comment='红利再投资份额净值基准日')
    F_REINV_TOAC_DT = Column(str, comment='红利再投资到账日')
    F_REINV_REDEEM_DT = Column(str, comment='红利再投资可赎回起始日')
    ANN_DATE = Column(str, comment='公告日期')
    F_DIV_OBJECT = Column(str, comment='分配对象')
    F_DIV_IPAYDT = Column(str, comment='收益支付日')
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class CFundPCHREDMCache(AbstractRedisTable):
    """
    中国共同基金申购赎回天数
    """
    __redis_name__ = "cross:wind:cfund:pch_redm"
    __redis_type__ = "cross_sectional"
    F_INFO_WINDCODE = Column(str, is_hash_key=True)
    F_INFO_SUSPCHDAY = Column(str)
    F_INFO_SUSREDMDAY2 = Column(str)
    F_INFO_SUSREDMDAY4 = Column(str)
    F_INFO_APPROVED_DATE = Column(str)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class CMFSubRedFeeCache(AbstractRedisTable):
    """
    中国共同基金费率表
    """
    __redis_name__ = "cross:wind:cmf:subred_fee"
    __redis_type__ = "cross_sectional"
    S_INFO_WINDCODE = Column(str, is_hash_key=True)
    FEETYPECODE = Column(str)
    FEERATIO = Column(int)
    AMOUNTDOWNLIMIT = Column(int)
    AMOUNTUPLIMIT = Column(int)
    SUPPLEMENTARY = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class ChinaMutualFundManagerCache(AbstractRedisTable):
    """

    """
    __redis_name__ = "cross:wind:china_mutual_fund:manager"
    __redis_type__ = "cross_sectional"
    F_INFO_WINDCODE = Column(str, is_hash_key=True)
    ANN_DATE = Column(str)
    F_INFO_FUNDMANAGER = Column(str)
    F_INFO_MANAGER_GENDER = Column(str)
    F_INFO_MANAGER_BIRTHYEAR = Column(str)
    F_INFO_MANAGER_EDUCATION = Column(str)
    F_INFO_MANAGER_NATIONALITY = Column(str)
    F_INFO_MANAGER_STARTDATE = Column(str)
    F_INFO_MANAGER_LEAVEDATE = Column(str)
    F_INFO_FUNDMANAGER_ID = Column(str)
    S_INFO_MANAGER_POST = Column(str)
    F_INFO_ESCROW_FUNDMANAGER = Column(str)
    F_INFO_ESCROW_STARTDATE = Column(str)
    F_INFO_ESCROW_LEAVEDATE = Column(str)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class ChinaMutualFundWindSectorCodeCache(AbstractRedisTable):
    __redis_name__ = "cross:wind:china_mutual_fund:wind_sector"
    __redis_type__ = "cross_sectional"
    F_INFO_WINDCODE = Column(str, is_hash_key=True)
    S_INFO_SECTOR = Column(str)
    S_INFO_SECTORENTRYDT = Column(str)
    S_INFO_SECTOREXITDT = Column(str)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class CMFHolderStructureRatioCache(AbstractRedisTable):
    __redis_name__ = "cross:wind:cmf:holder_structure"
    __redis_type__ = "cross_sectional"
    S_INFO_WINDCODE = Column(str, is_hash_key=True)
    END_DT = Column(str)
    HOLDER_INSTITUTION_HOLDINGPCT = Column(int)
    HOLDER_PERSONAL_HOLDINGPCT = Column(int)
    HOLDER_MNGEMP_HOLDINGPCT = Column(int)
    HOLDER_FEEDER_HOLDINGPCT = Column(int)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class CMFundSplitCache(AbstractRedisTable):
    __redis_name__ = "cross:wind:cm_fund:split"
    __redis_type__ = "cross_sectional"
    S_INFO_WINDCODE = Column(str, is_hash_key=True)
    F_INFO_SPLITTYPE = Column(str)
    F_INFO_SHARETRANSDATE = Column(str)
    F_INFO_SPLITINC = Column(int)
    F_INFO_SPLIT_DT = Column(str)
    F_INFO_SPLITANNOECDATE = Column(str)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class ChinaMutualFundRelatedCodeCache(AbstractRedisTable):
    """
    相关份额基金代码
    """
    __redis_name__ = "cross:wind:china_mutual_fund:related_code"
    __redis_type__ = "cross_sectional"
    F_INFO_WINDCODE = Column(str, is_hash_key=True)
    RELATED_CODE = Column(str)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class ChinaMutualFundParentCodeCache(AbstractRedisTable):
    __redis_name__ = "cross:wind:china_mutual_fund:parent_code"
    __redis_type__ = "cross_sectional"
    F_INFO_WINDCODE = Column(str, is_hash_key=True)
    PARENT_CODE = Column(str)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)


class AShareIndustriesCodeCache(AbstractRedisTable):
    """"""
    __redis_name__ = "cross:wind:ashare:industries_code"
    __redis_type__ = "cross_sectional"
    INDUSTRIESCODE = Column(str, is_hash_key=True)
    INDUSTRIESNAME = Column(str)
    LEVELNUM = Column(int)
    USED = Column(int)
    INDUSTRIESALIAS = Column(str)
    SEQUENCE = Column(int)
    MEMO = Column(str)
    CHINESEDEFINITION = Column(str)
    WIND_NAME_ENG = Column(str)
    CAL_DATE = Column(str, default=NatureDateUtils.get_cur_date)
    UPDATE_TIME = Column(str, default=NatureDateUtils.get_cur_time)
