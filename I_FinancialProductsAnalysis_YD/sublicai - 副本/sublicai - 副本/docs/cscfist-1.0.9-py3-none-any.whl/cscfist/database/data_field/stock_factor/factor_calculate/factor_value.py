# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/1/10 17:20
# @Author  : wangxybjs
# @File    : factor_raw.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------
"""
因子原始结果表
"""

from sqlalchemy import Column, Index, UniqueConstraint
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.types import VARCHAR, Numeric, BIGINT

from cscfist.tools.generate_id import generate_update_time

Base = declarative_base()

class RawFactorValue(Base):
    __tablename__ = 'raw_factor_value'

    id = Column(BIGINT, autoincrement=True, primary_key=True)
    factor_id = Column(VARCHAR(200), nullable=True, comment='因子ID')
    trade_date = Column(VARCHAR(8), nullable=True, comment='交易日期')
    stock_code = Column(VARCHAR(20), nullable=True, comment='股票代码')
    factor_value = Column(Numeric(20, 6), comment='因子值')
    cal_date = Column(VARCHAR(8), default=generate_update_time("%Y%m%d"), comment='计算日期')
    update_time = Column(VARCHAR(20), default=generate_update_time, comment='更新时间')
    __table_args__ = (
        Index('raw_value_id_date', "factor_id", "trade_date"),
        UniqueConstraint("factor_id", "trade_date", "stock_code", name="raw_value_id_date_code"),
        {'comment': '预处理前因子值'},)


class FactorValue(Base):
    __tablename__ = 'factor_value'

    id = Column(BIGINT, autoincrement=True, primary_key=True)
    factor_id = Column(VARCHAR(200), nullable=True, comment='因子ID')
    trade_date = Column(VARCHAR(8), nullable=True, comment='交易日期')
    stock_code = Column(VARCHAR(20), nullable=True, comment='股票代码')
    factor_value = Column(Numeric(20, 6), comment='因子值')
    cal_date = Column(VARCHAR(8), default=generate_update_time("%Y%m%d"), comment='计算日期')
    update_time = Column(VARCHAR(20), default=generate_update_time, comment='更新时间')
    __table_args__ = (
        Index('value_id_date', "factor_id", "trade_date"),
        UniqueConstraint("factor_id", "trade_date", "stock_code", name="value_id_date_code"), {'comment': '因子值'},)


class FactorCalFinishDate(Base):
    __tablename__ = 'factor_cal_finish_date'

    id = Column(BIGINT, autoincrement=True, primary_key=True)
    factor_id = Column(VARCHAR(200), nullable=True, comment='因子ID')
    trade_date = Column(VARCHAR(8), nullable=True, comment='交易日期')
    cal_date = Column(VARCHAR(8), default=generate_update_time("%Y%m%d"), comment='计算日期')
    update_time = Column(VARCHAR(20), default=generate_update_time, comment='更新时间')
    __table_args__ = (Index('cal_fin_id_date', "factor_id", "trade_date"),
                      UniqueConstraint("factor_id", "trade_date", name="cal_finish_id_date"),
                      {'comment': "因子计算完成状态."},)


class CombineFactorValue(Base):
    __tablename__ = 'combine_factor_value'

    id = Column(BIGINT, autoincrement=True, primary_key=True)
    combine_method_id = Column(VARCHAR(200), nullable=True, comment='合成因子ID')
    trade_date = Column(VARCHAR(8), nullable=True, comment='交易日期')
    stock_code = Column(VARCHAR(20), nullable=True, comment='股票代码')
    factor_value = Column(Numeric(20, 6), comment='合成因子值')
    cal_date = Column(VARCHAR(8), default=generate_update_time("%Y%m%d"), comment='计算日期')
    update_time = Column(VARCHAR(20), default=generate_update_time, comment='更新时间')
    __table_args__ = (
        Index('value_id_date', "combine_method_id", "trade_date"),
        UniqueConstraint("combine_method_id", "trade_date", "stock_code", name="value_id_date_code"),
        {'comment': '合成因子值'},)


def create_table(connection):
    Base.metadata.create_all(connection.engine)
