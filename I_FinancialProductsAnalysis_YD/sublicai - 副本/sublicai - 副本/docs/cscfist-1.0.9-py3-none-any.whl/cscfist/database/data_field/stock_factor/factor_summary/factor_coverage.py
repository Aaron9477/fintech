# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/1/10 17:26
# @Author  : wangxybjs
# @File    : factor_coverage.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------

from sqlalchemy import Column, Index, Integer
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.types import VARCHAR, Numeric,  BIGINT

from cscfist.tools.generate_id import generate_update_time

Base = declarative_base()


class FactorCrossStatistics(Base):
    __tablename__ = 'factor_cross_statistics'

    id = Column(BIGINT, autoincrement=True, primary_key=True)
    factor_id = Column(VARCHAR(200), nullable=True, comment='因子ID')
    pool_id = Column(VARCHAR(200), nullable=True, comment='股票池ID')
    cal_date = Column(VARCHAR(8), default=generate_update_time("%Y%m%d"), comment='计算日期')
    update_time = Column(VARCHAR(20), default=generate_update_time, comment='更新时间')
    trade_date = Column(VARCHAR(8), nullable=True, comment='日期')
    max_value = Column(Numeric(20, 6), comment='最大值')
    quantile3 = Column(Numeric(20, 6), comment='四分之三分位数')
    median_value = Column(Numeric(20, 6), comment='中位数')
    mean_value = Column(Numeric(20, 6), comment='均值')
    quantile1 = Column(Numeric(20, 6), comment='四分之一分位数')
    min_value = Column(Numeric(20, 6), comment='最小值')
    coverage = Column(Numeric(20, 6), comment='覆盖度')
    std = Column(Numeric(20, 6), comment='标准差')
    sign = Column(Integer, default=2, comment='标志')

    __table_args__ = (
        Index('statistics_factor_pool_id_date', "factor_id", "pool_id", "trade_date"),
        {'comment': '因子概览--截面数值统计'},)


def create_table(connection):
    Base.metadata.create_all(connection.engine)
