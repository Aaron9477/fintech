from cscfist.database.connection.mysql_con import get_default_sf_connection
from cscfist.database.data_field.stock_factor.basic_info import *
from cscfist.database.data_field.stock_factor.factor_calculate import *
from cscfist.database.data_field.stock_factor.factor_test import *
from cscfist.database.data_field.stock_factor.factor_summary import *


def create_tables(connection):
    factor_basic.create_table(connection)
    factor_value.create_table(connection)
    factor_backtest_analysis.create_table(connection)
    factor_ic_test.create_table(connection)
    factor_regress_test.create_table(connection)
    factor_coverage.create_table(connection)
    factor_turnover.create_table(connection)


if __name__ == '__main__':
    create_tables(get_default_sf_connection())