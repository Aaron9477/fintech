# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/7/30 18:36
# @Author  : lisl3
# @File    : __init__.py.py
# @Project : cscfist
# @Function: 定义数据字段类型
# @Version : V0.0.1
