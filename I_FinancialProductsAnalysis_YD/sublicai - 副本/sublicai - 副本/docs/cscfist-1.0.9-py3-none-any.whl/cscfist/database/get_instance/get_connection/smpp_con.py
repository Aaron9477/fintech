# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2023/3/30 10:07
# @Author  : wangxybjs
# @File    : smpp_con.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.connection.oracle_con import get_default_smpp_connection

smpp_connection = get_default_smpp_connection()
