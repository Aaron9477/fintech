# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/12/3 18:14
# @Author  : wangxybjs
# @File    : dfcf_con.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.connection.oracle_con import get_default_dfcf_connection

dfcf_connection = get_default_dfcf_connection()
