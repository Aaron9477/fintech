# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/9/13 13:27
# @Author  : wangxybjs
# @File    : dfcf_inst.py
# @Project : workspaces_jjpg
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.read.read_dfcf import DFCFReader
from cscfist.database.get_instance.get_connection.dfcf_con import dfcf_connection

dfcf_reader = DFCFReader(dfcf_connection)
