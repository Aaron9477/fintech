# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/12/3 18:15
# @Author  : wangxybjs
# @File    : redis_con.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.connection.redis_con import get_default_redis_session

redis_session = get_default_redis_session()
