# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/2/10 11:19
# @Author  : wangxybjs
# @File    : jcjs_con.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.connection.oracle_con import get_default_jcjs_connection

jcjs_connection = get_default_jcjs_connection()
