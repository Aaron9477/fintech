# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/2/10 11:18
# @Author  : wangxybjs
# @File    : jcjs_inst.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.read.read_jcjs import JCJSReader
from cscfist.database.get_instance.get_connection.jcjs_con import jcjs_connection

jcjs_reader = JCJSReader(jcjs_connection)
