# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/8/23 14:14
# @Author  : wangxybjs
# @File    : wind_inst.py
# @Project : workspaces_jjpg
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.get_instance.get_connection.wind_con import wind_connection
from cscfist.database.read.read_wind import WindReader

wind_reader = WindReader(wind_connection)
