# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/7/21 13:24
# @Author  : wangxybjs
# @File    : qc_con.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.connection.mysql_con import get_default_qc_connection

qc_connection = get_default_qc_connection()
