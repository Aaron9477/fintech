# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/1/11 17:56
# @Author  : wangxybjs
# @File    : sf_con.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.connection.mysql_con import get_default_sf_connection

sf_connection = get_default_sf_connection()
