# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/7/21 13:16
# @Author  : wangxybjs
# @File    : qc_inst.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.get_instance.get_connection.qc_con import qc_connection
from cscfist.database.save.save_qc import QuantContestSaver
from cscfist.database.read.read_qc import QuantContestReader

qc_saver = QuantContestSaver(qc_connection)
qc_reader = QuantContestReader(qc_connection)
