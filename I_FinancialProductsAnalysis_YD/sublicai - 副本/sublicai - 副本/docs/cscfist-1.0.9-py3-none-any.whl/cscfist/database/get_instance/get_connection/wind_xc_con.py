from cscfist.database.connection.mysql_con import get_default_wind_xc_connection

wind_xc_connection = get_default_wind_xc_connection()
