# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2023/3/30 12:08
# @Author  : wangxybjs
# @File    : caihui_inst.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.read.read_caihui import CaiHuiReader
from cscfist.database.get_instance.get_connection.caihui_con import caihui_connection

caihui_reader = CaiHuiReader(caihui_connection)
