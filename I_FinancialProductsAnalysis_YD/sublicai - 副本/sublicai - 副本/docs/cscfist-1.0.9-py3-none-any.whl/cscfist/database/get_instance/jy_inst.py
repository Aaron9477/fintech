# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/8/31 13:45
# @Author  : wangxybjs
# @File    : jy_inst.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.get_instance.get_connection.jy_con import jy_connection
from cscfist.database.read.read_jy import JyReader

jy_reader = JyReader(jy_connection)

if __name__ == '__main__':
    df_portfolio = jy_reader.get_mf_invest_industry('005827', report_period='20211231')
    print(df_portfolio)
