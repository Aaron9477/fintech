# -*- coding: utf-8 -*-

from cscfist.database.connection.mysql_con import get_default_qs_connection

qs_connection = get_default_qs_connection()
