# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2023/3/30 10:07
# @Author  : wangxybjs
# @File    : smpp_inst.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.get_instance.get_connection.smpp_con import smpp_connection
from cscfist.database.read.read_smpp import SMPPReader

smpp_reader = SMPPReader(smpp_connection)
