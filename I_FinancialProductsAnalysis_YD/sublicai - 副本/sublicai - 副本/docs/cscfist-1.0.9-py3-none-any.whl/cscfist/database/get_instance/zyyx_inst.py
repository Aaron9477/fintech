# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/3/17 14:55
# @Author  : wangxybjs
# @File    : zyyx_inst.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.get_instance.get_connection.zyyx_con import zyyx_connection
from cscfist.database.read.read_zyyx import ZYYXReader

zyyx_reader = ZYYXReader(zyyx_connection)
