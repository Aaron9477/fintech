from cscfist.database.get_instance.get_connection.wind_xc_con import wind_xc_connection
from cscfist.database.read.read_wind import WindReader

wind_xc_reader = WindReader(wind_xc_connection)

if __name__ == '__main__':
    df = wind_xc_reader.get_a_share_eod_derivative_indicator("000001.SZ")
    print(df)
