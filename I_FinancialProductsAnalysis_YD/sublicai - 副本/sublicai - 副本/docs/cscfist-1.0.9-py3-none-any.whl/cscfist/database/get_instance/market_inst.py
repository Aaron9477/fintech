# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/12/10 10:11
# @Author  : wangxybjs
# @File    : market_inst.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.get_instance.get_connection.dfcf_con import dfcf_connection
from cscfist.database.get_instance.get_connection.wind_con import wind_connection
from cscfist.database.read.read_market import MarketReader

market_reader = MarketReader(wind_connection, dfcf_connection)
