# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/3/17 14:55
# @Author  : wangxybjs
# @File    : zyyx_con.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.connection.oracle_con import get_default_zyyx_connection

zyyx_connection = get_default_zyyx_connection()
