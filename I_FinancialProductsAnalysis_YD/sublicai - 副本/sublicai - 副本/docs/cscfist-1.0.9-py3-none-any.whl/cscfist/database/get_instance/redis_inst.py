# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/8/23 13:51
# @Author  : wangxybjs
# @File    : redis_inst.py
# @Project : workspaces_jjpg
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.combine_operator.combine_operate_redis import RedisCombineOperator
from cscfist.database.delete.delete_redis import RedisDeleter
from cscfist.database.get_instance.get_connection.redis_con import redis_session
from cscfist.database.read.read_redis import RedisReader
from cscfist.database.save.save_redis import RedisSaver

redis_reader = RedisReader(redis_session)
redis_deleter = RedisDeleter(redis_session)
redis_saver = RedisSaver(redis_session)
redis_combine_operator = RedisCombineOperator(redis_session)