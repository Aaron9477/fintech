# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2023/3/30 12:08
# @Author  : wangxybjs
# @File    : caihui_con.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.connection.oracle_con import get_default_caihui_connection

caihui_connection = get_default_caihui_connection()
