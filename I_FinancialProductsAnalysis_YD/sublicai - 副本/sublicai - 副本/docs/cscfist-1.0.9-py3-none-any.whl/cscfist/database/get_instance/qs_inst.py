# -*- coding: utf-8 -*-
from cscfist.database.delete.delete_quantitative_settlement import QuantitativeSettlementDeleter
from cscfist.database.get_instance.get_connection.qs_con import qs_connection
from cscfist.database.read.read_quantitative_settlement import QuantitativeSettlementReader
from cscfist.database.save.save_quantitative_settlement import QuantitativeSettlementSaver
from cscfist.database.update.update_quantitative_settlement import QuantitativeSettlementUpdater

qs_reader = QuantitativeSettlementReader(qs_connection)
qs_saver = QuantitativeSettlementSaver(qs_connection)
qs_updater = QuantitativeSettlementUpdater(qs_connection)
qs_deleter = QuantitativeSettlementDeleter(qs_connection)