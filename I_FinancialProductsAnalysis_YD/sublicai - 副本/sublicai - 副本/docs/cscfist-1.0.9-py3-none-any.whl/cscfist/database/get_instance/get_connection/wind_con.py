# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/12/3 18:18
# @Author  : wangxybjs
# @File    : wind_con.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.connection.sql_server_con import get_default_wind_connection

wind_connection = get_default_wind_connection()
