# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/9/14 13:52
# @Author  : wangxybjs
# @File    : ht_inst.py
# @Project : workspaces_jjpg
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.get_instance.get_connection.sf_con import sf_connection
from cscfist.database.read.read_stock_factor import StockFactorReader
from cscfist.database.save.save_stock_factor import StockFactorSaver

sf_reader = StockFactorReader(sf_connection)
sf_saver = StockFactorSaver(sf_connection)
