# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/8/31 13:43
# @Author  : wangxybjs
# @File    : jy_con.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.connection.sql_server_con import get_default_jy_connection

jy_connection = get_default_jy_connection()
