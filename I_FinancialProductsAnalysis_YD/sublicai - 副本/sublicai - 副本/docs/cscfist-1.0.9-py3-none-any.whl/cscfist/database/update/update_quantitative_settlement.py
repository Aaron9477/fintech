# -*- coding: utf-8 -*-

from cscfist.tools import clean_res

from cscfist.database.connection.mysql_con import get_default_qs_connection
from cscfist.database.data_field.quantitative_settlement.quantitative_settlement_field import *


class QuantitativeSettlementUpdater(object):
    def __init__(self, qs_connection=None):
        """
        Args:
            qs_connection: 数据库连接。如果为None则使用默认配置连接
        """
        if qs_connection is None:
            qs_connection = get_default_qs_connection()
        self.session = qs_connection.session

    def _update(self, table, update_list):
        """
        Args:
            table: 表
            update_list: 是一个字典的列表, 每个字典是代表一个update语句, 有filter和update两个字典, 分别代表需要筛选和更新的部分
                例如update_list = [{'filter': {'match_column1': match_value1, 'match_column2': match_value2},
                'update': {'update_column1': update_value1, 'update_column2': update_value2}}, ...]
                表示`update table set update_column1=update_value1, update_column2=update_value2 where
                match_column1=match_value1 and match_column2=match_value2`
        """

        query = self.session.query(table)
        for update_record in update_list:
            filter_condition_dict = update_record['filter']
            update_res_dict = update_record['update']
            filter_condition = [getattr(table, col) == v for col, v in filter_condition_dict.items()]
            query_single = query.filter(*filter_condition)
            update_record_dict = {getattr(table, col): clean_res(v) for col, v in update_res_dict.items()}
            query_single.update(update_record_dict, synchronize_session=False)

    def update_rqalpha_persist(self, update_list):
        table_name = RqalphaPersist
        self._update(table_name, update_list)
        self.session.commit()

    def update_strategy_stock_trading_backtest(self, update_list):
        table_name = StrategyStockTradingBacktest
        self._update(table_name, update_list)
        self.session.commit()

    def update_strategy_stock_trading_clearing(self, update_list):
        table_name = StrategyStockTradingClearing
        self._update(table_name, update_list)
        self.session.commit()

