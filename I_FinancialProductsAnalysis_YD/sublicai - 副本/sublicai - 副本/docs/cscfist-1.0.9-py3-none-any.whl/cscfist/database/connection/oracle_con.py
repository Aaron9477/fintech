# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/9/10 10:03
# @Author  : wangxybjs
# @File    : oracle_con.py
# @Project : cscfist
# @Function: Oracle数据库连接
# @Version : V0.0.1
# ------------------------------
from typing import Optional
from urllib.parse import quote_plus as urlquote

import cx_Oracle
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase


class OracleConnection(RdbConnectionBase):
    def __init__(self, connect_str: Optional[str] = None, host: Optional[str] = None, port: Optional[str] = None,
                 user: Optional[str] = None, password: Optional[str] = None, database: Optional[str] = None, **kwargs):
        """
        Oracle数据库连接

        Args:
            connect_str:连接字符串
            host: 主机
            port: 端口号
            user: 用户名
            password: 密码
            database: 数据库
            **kwargs: 其他参数
        """
        import os
        os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.ZHS16GBK'
        if connect_str is None:
            dsn_str = cx_Oracle.makedsn(host, port, service_name=database)
            connect_str = f'oracle://{user}:{urlquote(password)}@{dsn_str}'
        encoding = kwargs.pop('encoding', 'gbk')
        self._engine = create_engine(connect_str, encoding=encoding)
        self._session = sessionmaker(bind=self.engine)()

    @property
    def engine(self):
        return self._engine

    @property
    def session(self):
        return self._session


def get_default_dfcf_connection():
    """东方财富Oracle数据库连接"""
    from cscfist.configuration import conf
    connect_str = conf.get("db.uris.dfcf.sqlalchemy_database_uri")
    dfcf_connection = OracleConnection(connect_str)
    return dfcf_connection


def get_default_jcjs_connection():
    """策略工具基础计算oracle数据库连接"""
    from cscfist.configuration import conf
    connect_str = conf.get("db.uris.jcjs.sqlalchemy_database_uri")
    jcjs_connection = OracleConnection(connect_str)
    return jcjs_connection


def get_default_zyyx_connection():
    """朝阳永续oracle数据库连接"""
    from cscfist.configuration import conf
    connect_str = conf.get("db.uris.zyyx.sqlalchemy_database_uri")
    zyyx_connection = OracleConnection(connect_str)
    return zyyx_connection


def get_default_smpp_connection():
    """私募排排oracle数据库连接"""
    from cscfist.configuration import conf
    connect_str = conf.get("db.uris.smpp.sqlalchemy_database_uri")
    smpp_connection = OracleConnection(connect_str)
    return smpp_connection


def get_default_caihui_connection():
    """财汇oracle数据库连接"""
    from cscfist.configuration import conf
    connect_str = conf.get("db.uris.caihui.sqlalchemy_database_uri")
    caihui_connection = OracleConnection(connect_str)
    return caihui_connection
