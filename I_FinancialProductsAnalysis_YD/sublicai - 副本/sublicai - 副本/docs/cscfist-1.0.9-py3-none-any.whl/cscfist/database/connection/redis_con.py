# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/11/23 14:29
# @Author  : wangxybjs
# @File    : redis_con.py
# @Project : cscfist
# @Function: Redis数据库连接
# @Version : V0.0.1
# ------------------------------
from typing import List

from redis.sentinel import Sentinel

from cscfist.model.db_model.redis_model.session import RedisSession


class RedisConnection(object):
    def __init__(self, host_list: List[str], port: str, password: str, db: str, master_name: str, decode_responses=True,
                 socket_timeout=100, socket_connect_timeout=100, **kwargs):
        """
        Redis数据库连接

        Args:
            host_list: 主机群
            port: 端口号
            password: 密码
            db: redis库分组，通常为0~15中的一个
            master_name: 哨兵Master名称
            decode_responses: 是否数据解码，解决中文乱码问题
            socket_timeout: socket超时时间
            socket_connect_timeout: socket连接超时时间
            **kwargs: 其他参数
        """
        sentinel = Sentinel([(host, port) for host in host_list], db=db, password=password,
                            decode_responses=decode_responses, socket_timeout=socket_timeout,
                            socket_connect_timeout=socket_connect_timeout, **kwargs)
        redis_master = sentinel.master_for(master_name, socket_timeout=socket_timeout,
                                           socket_connect_timeout=socket_connect_timeout,
                                           health_check_interval=30)
        self.session = RedisSession(redis_master)


def get_default_redis_session():
    """内置redis库连接"""
    from cscfist.configuration import conf
    host_list = conf.get("cache.redis.host_list")
    port = conf.get("cache.redis.port")
    password = conf.get("cache.redis.password")
    db = conf.get("cache.redis.db_num")
    master_name = conf.get("cache.redis.master_name")
    redis_connection = RedisConnection(host_list, port, password, db, master_name)
    redis_session = redis_connection.session
    return redis_session
