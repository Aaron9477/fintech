# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/8/3 9:01
# @Author  : lisl3
# @File    : es_con.py
# @Project : cscfist
# @Function: ElasticSearch数据库连接
# @Version : V0.0.1
# ------------------------------
from typing import List

from elasticsearch_dsl import connections


class EsConnection(object):
    def __init__(self, host_list: List[str], port: str, user: str, password: str, **kwargs):
        """
        ES数据库连接

        Args:
            host_list: 主机群
            port: 端口号
            user: 用户名
            password: 密码
            **kwargs: 其他参数
        """
        timeout = kwargs.pop('timeout', 60)
        self.es_client = connections.create_connection(
            hosts=[f'{host}:{port}' for host in host_list], http_auth=(user, password), timeout=timeout, **kwargs)
        self.indices_client = self.es_client.indices


def get_default_es_connection():
    """默认es数据库连接"""
    from cscfist.configuration import conf
    host_list = conf.get("elasticsearch.host_list")
    port = conf.get("elasticsearch.port")
    user = conf.get("elasticsearch.user")
    password = conf.get("elasticsearch.password")
    es_connection = EsConnection(host_list, port, user, password)
    return es_connection
