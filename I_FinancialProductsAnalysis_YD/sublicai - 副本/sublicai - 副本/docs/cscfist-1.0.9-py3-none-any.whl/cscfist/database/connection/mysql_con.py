# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/9/3 9:10
# @Author  : wangxybjs
# @File    : mysql_con.py
# @Project : cscfist
# @Function: Mysql数据库连接
# @Version : V0.0.1
# ------------------------------
from typing import Optional
from urllib.parse import quote_plus as urlquote

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase


class MySQLConnection(RdbConnectionBase):
    def __init__(self, connect_str: Optional[str] = None, host: Optional[str] = None, port: Optional[str] = None,
                 user: Optional[str] = None, password: Optional[str] = None, database: Optional[str] = None, **kwargs):
        """
        Mysql数据库连接

        Args:
            connect_str:连接字符串
            host: 主机
            port: 端口号
            user: 用户名
            password: 密码
            database: 数据库
            **kwargs: 其他参数
        """
        if connect_str is None:
            connect_str = f"mysql+pymysql://{user}:{urlquote(password)}@{host}:{port}/{database}"
        encoding = kwargs.pop('encoding', 'gbk')
        pool_recycle = kwargs.pop('pool_recycle', 3600)
        self._engine = create_engine(connect_str, encoding=encoding, pool_recycle=pool_recycle)
        self._session = sessionmaker(bind=self.engine)()

    @property
    def engine(self):
        return self._engine

    @property
    def session(self):
        return self._session


def get_default_sf_connection():
    from cscfist.configuration import conf
    connect_str = conf.get("db.uris.sf.sqlalchemy_database_uri")
    sf_connection = MySQLConnection(connect_str)
    return sf_connection


def get_default_qs_connection():
    from cscfist.configuration import conf
    connect_str = conf.get("db.uris.qs.sqlalchemy_database_uri")
    qs_connection = MySQLConnection(connect_str)
    return qs_connection


def get_default_qc_connection():
    from cscfist.configuration import conf
    connect_str = conf.get("db.uris.qc.sqlalchemy_database_uri")
    qs_connection = MySQLConnection(connect_str)
    return qs_connection


def get_default_wind_xc_connection():
    from cscfist.configuration import conf
    connect_str = conf.get("db.uris.wind_xc.sqlalchemy_database_uri")
    qs_connection = MySQLConnection(connect_str)
    return qs_connection
