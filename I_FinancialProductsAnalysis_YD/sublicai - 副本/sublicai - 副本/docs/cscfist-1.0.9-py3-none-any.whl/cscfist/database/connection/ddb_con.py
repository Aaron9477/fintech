import dolphindb as ddb


def get_ddb_session():
    """DDB数据库连接"""
    from cscfist.configuration import conf
    host = conf.get("db.uris.ddb.db_host")
    port = conf.get("db.uris.ddb.db_port")
    user = conf.get("db.uris.ddb.db_user")
    password = conf.get("db.uris.ddb.db_password")

    s = ddb.session()
    s.connect(host, port, user, password, highAvailability=True)
    return s
