# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/8/3 9:01
# @Author  : lisl3
# @File    : sql_server_con.py
# @Project : cscfist
# @Function: SqlServer数据库连接
# @Version : V0.0.1
# ------------------------------
from typing import Optional
from urllib.parse import quote_plus as urlquote

import pyodbc
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase


class SQLServerConnection(RdbConnectionBase):
    def __init__(self, connect_str: Optional[str] = None, host: Optional[str] = None, user: Optional[str] = None,
                 password: Optional[str] = None, database: Optional[str] = None, charset: Optional[str] = "cp936",
                 **kwargs):
        """
        SqlServer数据库连接

        Args:
            connect_str:连接字符串
            host: 主机
            user: 用户名
            password: 密码
            database: 数据库
            charset: 字符集
            **kwargs: 其他参数
        """
        # if connect_str is None:
        #     connect_str = f"mssql+pymssql://{user}:{password}@{host}/{database}"

        if connect_str is None:
            connect_str = f"mssql+pyodbc://{user}:{urlquote(password)}@{host}/{database}"
        driver = self.get_pyodbc_driver()
        connect_str += f"?driver={driver}&TrustServerCertificate=yes"

        self._engine = create_engine(connect_str, connect_args={'charset': charset}, pool_pre_ping=True, **kwargs)
        self._session = sessionmaker(bind=self.engine)()

    @property
    def engine(self):
        return self._engine

    @property
    def session(self):
        return self._session

    @staticmethod
    def get_pyodbc_driver():
        driver = ""
        for x in pyodbc.drivers():
            if "sql server" in x.lower():
                driver = x
                break
        if driver == "":
            raise ValueError("Missing driver in the system!")
        else:
            return driver


def get_default_wind_connection():
    """万得SqlServer数据库连接"""
    from cscfist.configuration import conf
    connect_str = conf.get("db.uris.wind.sqlalchemy_database_uri")
    wind_connection = SQLServerConnection(connect_str)
    return wind_connection


def get_default_jy_connection():
    """聚源SqlServer数据库连接"""
    from cscfist.configuration import conf
    connect_str = conf.get("db.uris.jy.sqlalchemy_database_uri")
    wind_connection = SQLServerConnection(connect_str)
    return wind_connection
