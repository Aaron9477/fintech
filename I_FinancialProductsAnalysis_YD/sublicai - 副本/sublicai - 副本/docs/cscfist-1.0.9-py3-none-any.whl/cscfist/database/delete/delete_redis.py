# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/2/8 11:23
# @Author  : wangxybjs
# @File    : delete_redis.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.data_field.redis_field import AShareEodPricesCache, ChinaMutualFundNavCache, \
    ChinaMutualFundDescriptionCache, ChinaClosedFundEodPriceCache, ChinaMFDividendCache
from cscfist.model.db_model.redis_model.redis_operator_base import RedisBaseDeleter


class RedisDeleter(RedisBaseDeleter):
    def __init__(self, redis_session_inst=None):
        if redis_session_inst is None:
            from cscfist.database.connection.redis_con import get_default_redis_session
            redis_session_inst = get_default_redis_session()
        super().__init__(redis_session_inst)

    def delete_a_share_eod_prices_cache(self, code, date_list, pipeline=None):
        table = AShareEodPricesCache
        self._delete_ts(table, code, date_list, pipeline)

    def delete_china_mutual_fund_nav_cache(self, code, date_list, pipeline=None):
        table = ChinaMutualFundNavCache
        self._delete_ts(table, code, date_list, pipeline)

    def delete_china_closed_fund_eod_price_cache(self, code, date_list, pipeline=None):
        table = ChinaClosedFundEodPriceCache
        self._delete_ts(table, code, date_list, pipeline)

    def delete_china_mutual_fund_description_cache(self, code, pipeline=None):
        table = ChinaMutualFundDescriptionCache
        self._delete_cross(table, code, pipeline)

    def delete_china_mf_dividend_cache(self, code, pipeline=None):
        table = ChinaMFDividendCache
        self._delete_cross(table, code, pipeline)

if __name__ == '__main__':
    RedisDeleter().delete_china_mutual_fund_description_cache(None, None)
