# -*- coding: utf-8 -*-

from cscfist.database.connection.mysql_con import get_default_qs_connection
from cscfist.database.data_field.quantitative_settlement.quantitative_settlement_field import *


class QuantitativeSettlementDeleter(object):
    def __init__(self, qs_connection=None):
        """
        Args:
            qs_connection: 数据库连接。如果为None则使用默认配置连接
        """
        if qs_connection is None:
            qs_connection = get_default_qs_connection()
        self.session = qs_connection.session

    def _delete(self, table, del_record_list):
        """
        Args:
            table: 表
            del_record_list: 是一个字典列表, 每个字典代表一个delete语句, Key是筛选字段, Value是筛选值
                例如del_record_list = [{'match_column1': match_value1, 'match_column2': match_value2}, ...]
                代表`delete from table where match_column1=match_value1 and match_column2=match_value2`
        """
        query = self.session.query(table)
        for del_record in del_record_list:
            filter_condition_dict = del_record
            filter_condition = [getattr(table, col) == v for col, v in filter_condition_dict.items()]
            query = query.filter(*filter_condition)
            query.delete()

    def delete_rqalpha_persist(self, del_record_list):
        self._delete(RqalphaPersist, del_record_list)

