from typing import Union, List, Dict, Optional

import pandas as pd

from cscfist.database.connection.mysql_con import get_default_qc_connection
from cscfist.database.data_field.quant_contest.quant_contest_field import StrategyPerformance
from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.model.db_model.rdb_model.rdb_operator_base import RdbBaseSaver


class QuantContestSaver(RdbBaseSaver):
    def __init__(self, db_connection: Optional[RdbConnectionBase] = None):
        """
        Args:
            db_connection: 数据库连接。如果为None则使用默认配置连接
        """
        if db_connection is None:
            db_connection = get_default_qc_connection()
        super().__init__(db_connection=db_connection)

    def save_strategy_performance(self, res_dict_list):
        self._save(StrategyPerformance, res_dict_list)