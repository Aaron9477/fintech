# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/2/7 16:19
# @Author  : wangxybjs
# @File    : save.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.database.data_field.redis_field import AShareEodPricesCache, ChinaMutualFundNavCache, \
    ChinaMutualFundDescriptionCache, ChinaClosedFundEodPriceCache, ChinaMFDividendCache
from cscfist.model.db_model.redis_model.redis_operator_base import RedisBaseSaver


class RedisSaver(RedisBaseSaver):
    def __init__(self, redis_session_inst=None):
        if redis_session_inst is None:
            from cscfist.database.connection.redis_con import get_default_redis_session
            redis_session_inst = get_default_redis_session()
        super().__init__(redis_session_inst)

    def save_a_share_eod_prices_cache(self, dict_list_or_dataframe, pipeline=None):
        if len(dict_list_or_dataframe) == 0:
            return
        self._save(AShareEodPricesCache, dict_list_or_dataframe, pipeline)

    def save_china_mutual_fund_nav_cache(self, dict_list_or_dataframe, pipeline=None):
        if len(dict_list_or_dataframe) == 0:
            return
        self._save(ChinaMutualFundNavCache, dict_list_or_dataframe, pipeline)

    def save_china_closed_fund_eod_price_cache(self, dict_list_or_dataframe, pipeline=None):
        if len(dict_list_or_dataframe) == 0:
            return
        self._save(ChinaClosedFundEodPriceCache, dict_list_or_dataframe, pipeline)

    def save_china_mutual_fund_description_cache(self, dict_list_or_dataframe, pipeline=None):
        if len(dict_list_or_dataframe) == 0:
            return
        self._save(ChinaMutualFundDescriptionCache, dict_list_or_dataframe, pipeline)

    def save_china_mf_dividend_cache(self, dict_list_or_dataframe, pipeline=None):
        if len(dict_list_or_dataframe) == 0:
            return
        self._save(ChinaMFDividendCache, dict_list_or_dataframe, pipeline)


if __name__ == '__main__':
    import pandas as pd

    redis_saver = RedisSaver()
    df = pd.DataFrame(
        {"S_INFO_WINDCODE": ["000001", "000001", "000003", "000003"], "TRADE_DT": ["2000", "2001", "2000", "2001"],
         "S_DQ_ADJCLOSE": [0, 1, 2, 3],
         "S_DQ_ADJPRECLOSE": [2, 3, 4, 5]})
    redis_saver.save_a_share_eod_prices_cache(df)
