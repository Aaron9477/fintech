# -*- coding: utf-8 -*-
from typing import Union, List, Dict

import pandas as pd
from cscfist.tools import clean_res
from sqlalchemy import inspect

from cscfist.database.data_field.quantitative_settlement.quantitative_settlement_field import *


class QuantitativeSettlementSaver(object):
    def __init__(self, qs_connection=None):
        if qs_connection is None:
            from cscfist.database.connection.mysql_con import get_default_qs_connection
            qs_connection = get_default_qs_connection()
        self.session = qs_connection.session

    def _save(self, table, dict_list_or_dataframe: Union[List, Dict, pd.DataFrame]):
        """
        Args:
            table: 表
            dict_list_or_dataframe: 字典或字典列表或DataFrame
                若为字典或字典列表, Key为字段名, Value为值
                若为DataFrame, 列为字段名
        """
        dict_list = None
        if isinstance(dict_list_or_dataframe, Dict):
            dict_list = [dict_list_or_dataframe]  # 若为字典, 先转为字典列表
        elif isinstance(dict_list_or_dataframe, pd.DataFrame):
            dict_list = dict_list_or_dataframe.to_dict(orient='records')  # 若为dataframe, 转为字典列表
        elif isinstance(dict_list_or_dataframe, List):
            dict_list = dict_list_or_dataframe

        record_list = []
        columns = [c.name for c in inspect(table).columns]
        for d in dict_list:
            d = {k: clean_res(v) for k, v in d.items() if k in columns}
            record = table(**d)
            record_list.append(record)
        self.session.add_all(record_list)

    def save_rqalpha_persist(self, res_dict_list):
        self._save(RqalphaPersist, res_dict_list)


