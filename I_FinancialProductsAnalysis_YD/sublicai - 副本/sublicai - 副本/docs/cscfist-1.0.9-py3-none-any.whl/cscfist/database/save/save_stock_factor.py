# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/12/5 0:59
# @Author  : wangxybjs
# @File    : save_stock_factor.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from typing import Optional

from cscfist.database.connection.mysql_con import get_default_sf_connection
from cscfist.database.data_field.stock_factor.basic_info import FactorBasic
from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.model.db_model.rdb_model.rdb_operator_base import RdbBaseSaver


class StockFactorSaver(RdbBaseSaver):
    def __init__(self, sf_connection: Optional[RdbConnectionBase] = None):
        """
        Args:
            sf_connection: 数据库连接。如果为None则使用默认配置连接
        """
        if sf_connection is None:
            sf_connection = get_default_sf_connection()
        super().__init__(db_connection=sf_connection)

    def save_factor_basic(self, res_dict_list):
        """
        保存因子值
        """
        return self._save(FactorBasic, res_dict_list)
