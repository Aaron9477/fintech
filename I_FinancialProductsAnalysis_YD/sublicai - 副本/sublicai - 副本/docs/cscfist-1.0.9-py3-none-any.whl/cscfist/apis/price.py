# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/1/12 11:29
# @Author  : wangxybjs
# @File    : price.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------


from cscfist.apis.date import transfer_end_n_to_begin


def get_price(stock_code=None, begin_date=None, end_date=None, trade_date=None, n=None, columns=None, frequency='d'):
    from cscfist.database.get_instance.wind_inst import wind_reader
    from cscfist.process import AShareTradeDateUtils
    begin_date = transfer_end_n_to_begin(begin_date, end_date, n)
    if stock_code is None or (isinstance(stock_code, list) and len(stock_code) > 10):
        res = wind_reader.get_a_share_eod_prices(stock_code, begin_date, end_date, trade_date, columns)
    else:
        from cscfist.database.get_instance.redis_inst import redis_reader
        res = redis_reader.get_a_share_eod_prices_cache(stock_code, begin_date, end_date, trade_date, columns)

    trade_date_utils = AShareTradeDateUtils()
    if trade_date is None:
        trade_date_list = trade_date_utils.get_trade_date_list(begin_date, end_date, period=frequency)
        res = res[res['TRADE_DT'].isin(trade_date_list)]

    return res
