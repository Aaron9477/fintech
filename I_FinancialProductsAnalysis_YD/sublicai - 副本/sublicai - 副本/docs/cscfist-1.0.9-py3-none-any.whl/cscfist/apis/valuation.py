# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/1/12 11:29
# @Author  : wangxybjs
# @File    : ashare_derivative_indicator.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------

from cscfist.apis.date import transfer_end_n_to_begin


def get_valuation(code=None, begin_date=None, end_date=None, n=None, columns=None):
    from cscfist.database.get_instance.wind_inst import wind_reader
    begin_date = transfer_end_n_to_begin(begin_date, end_date, n)
    if columns is not None:
        for col in ['S_INFO_WINDCODE', 'TRADE_DT']:
            if col not in columns:
                columns = [col] + columns
    res = wind_reader.get_a_share_eod_derivative_indicator(code, begin_date, end_date, None, columns)
    return res


if __name__ == '__main__':
    import time

    begin = time.time()
    res = get_valuation(None, end_date='20220107', n=1)
    print(time.time() - begin)
    print(res)
