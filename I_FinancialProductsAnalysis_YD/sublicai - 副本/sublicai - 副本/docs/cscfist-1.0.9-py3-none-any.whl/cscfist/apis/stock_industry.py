# -*- coding: utf-8 -*-
import datetime

import pandas as pd

from cscfist.apis.date import transfer_end_n_to_begin


def get_stock_industry(stock_code=None, industry_name='SW_1', begin_date=None, end_date=None, trade_date=None, n=None):
    from cscfist.database.get_instance.wind_inst import wind_reader
    from cscfist.process import AShareTradeDateUtils
    cur_date = datetime.datetime.now().strftime('%Y%m%d')
    begin_date = transfer_end_n_to_begin(begin_date, end_date, n)
    level = int(industry_name.split('_')[-1])
    industry_class_name = industry_name.split('_')[0]

    # logger.info('获取行业代码')
    industry_code_list = wind_reader.get_industry_code_from_industry_name(industry_class_name, level)
    # logger.info('获取{行业代码: 行业名称}字典')
    index_df = wind_reader.get_index_code_from_industry_code(industry_code_list)
    industry_code_name_dict = index_df.set_index('S_INFO_INDUSTRYCODE')['S_INFO_INDUSTRYNAME'].to_dict()
    industry_code_name_dict = {"{:<016}".format(k[:2 + 2 * level]): v for k, v in
                               industry_code_name_dict.items()}  # 末尾补0

    # logger.info('获取股票行业分类数据')
    if industry_class_name == 'SW':
        stock_industry_class = wind_reader.get_a_share_swn_industries_class(stock_code, begin_date=begin_date,
                                                                            end_date=end_date, trade_date=trade_date,
                                                                            columns=['S_INFO_WINDCODE', 'SW_IND_CODE',
                                                                                     'ENTRY_DT', 'REMOVE_DT'])
        stock_industry_class.rename(columns={"SW_IND_CODE": "IND_CODE"}, inplace=True)
        stock_industry_class["IND_CODE"] = stock_industry_class["IND_CODE"].apply(
            lambda x: "{:<016}".format(x[:2 + 2 * level]))

    else:
        stock_industry_class = wind_reader.get_a_share_industries_class(stock_code, begin_date=begin_date,
                                                                        end_date=end_date, trade_date=trade_date,
                                                                        columns=['S_INFO_WINDCODE', 'WIND_IND_CODE',
                                                                                 'ENTRY_DT', 'REMOVE_DT'])
        stock_industry_class.rename(columns={"WIND_IND_CODE": "IND_CODE"}, inplace=True)
        stock_industry_class["IND_CODE"] = stock_industry_class["IND_CODE"].apply(
            lambda x: "{:<016}".format(x[:2 + 2 * level]))

    stock_industry_class['REMOVE_DT'] = stock_industry_class['REMOVE_DT'].apply(lambda x: cur_date if x is None else x)
    if trade_date is not None:
        stock_industry_class['INDUSTRY_NAME'] = stock_industry_class['IND_CODE'].map(industry_code_name_dict)
        industry_code_series = stock_industry_class.set_index('S_INFO_WINDCODE')['IND_CODE']
        industry_name_series = stock_industry_class.set_index('S_INFO_WINDCODE')['INDUSTRY_NAME']
        return industry_code_series, industry_name_series
    else:
        all_date_list = pd.date_range(stock_industry_class['ENTRY_DT'].min(),
                                      stock_industry_class['REMOVE_DT'].max()).strftime('%Y%m%d')
        trade_date_list = AShareTradeDateUtils().get_trade_date_list(begin_date, end_date)
        stock_industry_class['INDUSTRY_NAME'] = stock_industry_class['IND_CODE'].map(industry_code_name_dict)
        # logger.info('行业代码矩阵')
        code_entry_pivot = stock_industry_class.pivot(index='ENTRY_DT', columns="S_INFO_WINDCODE", values="IND_CODE")
        code_remove_pivot = stock_industry_class.pivot(index='REMOVE_DT', columns="S_INFO_WINDCODE", values="IND_CODE")
        code_entry_pivot = code_entry_pivot.reindex(all_date_list).fillna(method='ffill')
        code_remove_pivot = code_remove_pivot.reindex(all_date_list).fillna(method='bfill')
        idx = pd.isna(code_entry_pivot + code_remove_pivot)
        industry_code_df = pd.DataFrame(columns=code_entry_pivot.columns, index=code_entry_pivot.index).where(idx,
                                                                                                              code_entry_pivot)
        industry_code_df = industry_code_df.reindex(trade_date_list)
        # logger.info('行业名称矩阵')
        name_entry_pivot = stock_industry_class.pivot(index='ENTRY_DT', columns="S_INFO_WINDCODE",
                                                      values="INDUSTRY_NAME")
        name_remove_pivot = stock_industry_class.pivot(index='REMOVE_DT', columns="S_INFO_WINDCODE",
                                                       values="INDUSTRY_NAME")
        name_entry_pivot = name_entry_pivot.reindex(all_date_list).fillna(method='ffill')
        name_remove_pivot = name_remove_pivot.reindex(all_date_list).fillna(method='bfill')
        idx = pd.isna(name_entry_pivot + name_remove_pivot)
        industry_name_df = pd.DataFrame(columns=name_entry_pivot.columns, index=name_entry_pivot.index).where(idx,
                                                                                                              name_entry_pivot)

        industry_name_df = industry_name_df.reindex(trade_date_list)
        return industry_code_df, industry_name_df


if __name__ == '__main__':
    industry_code_res, industry_name_res = get_stock_industry(industry_name='SW_2',
                                                              trade_date='20220315')
    print(industry_code_res['000002.SZ'].values[0])
    print(industry_name_res)
