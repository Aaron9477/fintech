# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/1/17 16:04
# @Author  : wangxybjs
# @File    : date.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------


def transfer_end_n_to_begin(begin_date, end_date, n):
    from cscfist.process import AShareTradeDateUtils
    if end_date is not None and n is not None:
        begin_date = AShareTradeDateUtils().get_previous_trading_date(end_date, n - 1)
    return begin_date
