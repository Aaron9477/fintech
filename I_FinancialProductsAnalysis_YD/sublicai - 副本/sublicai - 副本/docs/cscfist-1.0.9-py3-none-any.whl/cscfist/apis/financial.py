# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/1/12 11:29
# @Author  : wangxybjs
# @File    : finance.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------
import datetime

from cscfist.database.data_field.wind_field import ASHAREFINANCIALINDICATOR, ASHAREBALANCESHEET, ASHARETTMHIS


def get_financial_indicator(watch_date, n, indicator, code=None, is_annual=False, is_n_insufficient_cut=True):
    """
    获取财务指标

    Args:
        watch_date: 观察日期, 返回结果应取观察日期以前的日期
        n: 往前取多少个
        indicator: 指标名称
        code: 股票代码
        is_annual: 是否按年报取
        is_n_insufficient_cut: 当n大于0时, 若股票不足n个报告期, 是否去除该股票

    Returns:

    """
    from cscfist.database.get_instance.wind_inst import wind_reader
    # 取非退市的股票
    existing_code_list = wind_reader.get_existing_a_share_code(watch_date)
    # 取股票发布财报情况
    df_issue = wind_reader.get_a_share_issuing_date_predict(code, watch_date)
    df_issue = df_issue[df_issue["S_INFO_WINDCODE"].isin(existing_code_list)]
    execute_plan = {}
    for code, grouped in df_issue.groupby("S_INFO_WINDCODE"):
        report_date_list = grouped["REPORT_PERIOD"].tolist()
        if is_annual:
            report_date_list = [d for d in report_date_list if d[-4:] == "1231"]
        report_date_list.sort()
        if n > 0:
            if is_n_insufficient_cut and len(report_date_list) < n:
                continue
            report_date_list_ = report_date_list[-n:]
        else:
            if len(report_date_list) < -n:
                continue
            report_date_list_ = [report_date_list[n]]
        for date in report_date_list_:
            execute_plan.setdefault(date, []).append(code)
    res = wind_reader.get_financial_statement_indicator(indicator, execute_plan)
    if n > 0:
        res = res.set_index(["S_INFO_WINDCODE", "REPORT_PERIOD"])["res"]
    else:
        res = res.set_index(["S_INFO_WINDCODE"])["res"]
    return res


def get_financial_ttm(watch_date, indicator, code=None):
    res = get_financial_indicator(watch_date, 4, indicator, code)
    return res.groupby("S_INFO_WINDCODE").sum()


def get_financial_mrq(watch_date, indicator, code=None):
    res = get_financial_indicator(watch_date, -1, indicator, code)
    return res.groupby("S_INFO_WINDCODE").first()


def get_financial_lyr(watch_date, indicator, code=None):
    res = get_financial_indicator(watch_date, -1, indicator, code, is_annual=True)
    return res.groupby("S_INFO_WINDCODE").first()


if __name__ == '__main__':
    print(datetime.datetime.now())
    print(get_financial_ttm("20220302", ASHAREFINANCIALINDICATOR.S_FA_FCFE))
    print(get_financial_mrq("20220302", ASHAREFINANCIALINDICATOR.S_FA_FCFE))
    print(get_financial_lyr("20220302", ASHAREFINANCIALINDICATOR.S_FA_FCFE))
    print(get_financial_indicator("20220302", -1, ASHAREBALANCESHEET.DVD_PAYABLE))
    cur = get_financial_indicator("20220302", -1, ASHARETTMHIS.S_FA_ROE_TTM)
    before = get_financial_indicator("20220302", -5, ASHARETTMHIS.S_FA_ROE_TTM)
    res = cur / before - 1
    print(res)
    print(datetime.datetime.now())
