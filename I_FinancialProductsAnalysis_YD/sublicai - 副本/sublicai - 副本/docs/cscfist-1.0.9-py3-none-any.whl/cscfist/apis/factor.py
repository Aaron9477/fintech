# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/1/17 16:02
# @Author  : wangxybjs
# @File    : factor.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------
"""
取因子的API
"""

from cscfist.apis.date import transfer_end_n_to_begin
from cscfist.process.date_process.a_share_trade_date_process import AShareTradeDateUtils


def get_raw_factor_value(factor_id=None, begin_date=None, end_date=None, trade_date=None, n=None, stock_code=None):
    from cscfist.database.get_instance.stock_factor_inst import sf_reader
    begin_date = transfer_end_n_to_begin(begin_date, end_date, n)
    return sf_reader.get_factor_value(factor_id, begin_date, end_date, trade_date, stock_code)


def get_factor_value(factor_id=None, begin_date=None, end_date=None, trade_date=None, n=None, stock_code=None):
    from cscfist.database.get_instance.stock_factor_inst import sf_reader
    begin_date = transfer_end_n_to_begin(begin_date, end_date, n)
    return sf_reader.get_raw_factor_value(factor_id, begin_date, end_date, trade_date, stock_code)


def get_factor_ic_test_stat(factor_id=None, pool_id=None, period=1, interval='1y', end_date=None):
    from cscfist.database.get_instance.stock_factor_inst import sf_reader
    if end_date is not None:
        begin_date = AShareTradeDateUtils().date_period_change(end_date, f'-{interval}')
    else:
        begin_date = None
    return sf_reader.get_factor_ic_test_stat(factor_id, pool_id, period, interval, begin_date, end_date)


def get_factor_group_backtest_result_stat(factor_id=None, benchmark_code='000300.SH', pool_id=None, interval='1y',
                                          period=1, group_num=None, end_date=None):
    from cscfist.database.get_instance.stock_factor_inst import sf_reader
    begin_date = AShareTradeDateUtils().date_period_change(end_date, f'-{interval}') if end_date is not None else None
    return sf_reader.get_group_backtest_result_stat(factor_id, benchmark_code, pool_id, interval, period, group_num,
                                                    begin_date, end_date)


def get_factor_regress_test_stat(factor_id=None, pool_id=None, period=1, interval='1y', regress_method='OLS',
                                 end_date=None):
    from cscfist.database.get_instance.stock_factor_inst import sf_reader
    begin_date = AShareTradeDateUtils().date_period_change(end_date, f'-{interval}') if end_date is not None else None
    return sf_reader.get_factor_regress_test_stat(factor_id, pool_id, period, interval, regress_method, begin_date,
                                                  end_date)
