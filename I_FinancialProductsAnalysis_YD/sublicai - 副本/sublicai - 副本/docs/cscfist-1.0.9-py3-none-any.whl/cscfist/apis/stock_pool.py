# -*- coding: utf-8 -*-
from typing import Union, List, Dict

import numpy as np

from cscfist.apis.date import transfer_end_n_to_begin
from cscfist.model.entry_exit_set_model.get_category_model import get_single_category
from cscfist.tools import NatureDateUtils

STOCK_POOL_DICT = {"HS300": "000300.SH", "ZZ500": "000905.SH", "ZZ800": "000906.SH", "ZZ1000": "000852.SH",
                   "ALL_EXCLUDE_SUB_NEW_ST": "000985.SH"}


def get_all_exclude_sub_new_st_pool(begin_date=None, end_date=None, trade_date=None, n=None):
    """
    获取全部A股, 剔除次新股和ST, *ST, PT
    函数参数和返回见get_stock_pool
    """
    from cscfist.database.get_instance.market_inst import market_reader
    from cscfist.process import AShareTradeDateUtils
    from cscfist.database.get_instance.wind_inst import wind_reader
    begin_date = transfer_end_n_to_begin(begin_date, end_date, n)
    df_description = market_reader.get_a_share_description()
    df_description["S_INFO_DELISTDATE"].fillna("99991231", inplace=True)
    df_description = df_description[~df_description["S_INFO_LISTDATE"].isna()]  # 剔除上市日期为空的记录
    df_st = wind_reader.get_a_share_st()
    df_st = df_st[df_st["S_TYPE_ST"] != "R"]  # R表示恢复上市
    df_st["REMOVE_DT"].fillna("99991231", inplace=True)
    df_st = df_st[~df_st["ENTRY_DT"].isna()]  # 剔除异常进入日期
    # 情形1: 传入trade_date
    if trade_date is not None:
        sub_new_date = NatureDateUtils.date_period_change(trade_date, '-6m')  # 次新股日期
        df_description = df_description[(df_description["S_INFO_LISTDATE"] <= sub_new_date) &
                                        (df_description["S_INFO_DELISTDATE"] >= trade_date)]
        df_st = df_st[(df_st["ENTRY_DT"] <= trade_date) &
                      (df_st["REMOVE_DT"] >= trade_date)]
        code_list = list(set(df_description["S_INFO_WINDCODE"].tolist()) - set(df_st["S_INFO_WINDCODE"].tolist()))
        return code_list
    # 情形2: 传入end_date
    else:
        trade_date_list = AShareTradeDateUtils().get_trade_date_list(begin_date, end_date)
        all_date_list = NatureDateUtils.get_dates("19900101", end_date)
        df_description = df_description[(df_description["S_INFO_LISTDATE"] <= end_date) &
                                        (df_description["S_INFO_DELISTDATE"] >= begin_date)]
        df_st = df_st[(df_st["ENTRY_DT"] <= end_date) & (df_st["REMOVE_DT"] >= begin_date)]
        # 剔除次新股
        df_description["sub_new_date"] = df_description["S_INFO_LISTDATE"].apply(
            lambda x: NatureDateUtils.date_period_change(x, '6m'))  # 上市日期往后取6个月
        df_description = df_description[df_description["sub_new_date"] <= df_description["S_INFO_DELISTDATE"]]
        df_description.rename(
            columns={"sub_new_date": "entry_date", "S_INFO_WINDCODE": "code", "S_INFO_DELISTDATE": "remove_date"},
            inplace=True)
        df_market = get_single_category(df_description, all_date_list).reindex(trade_date_list)
        all_code_list = df_market.columns
        # 处理ST, 处理方法同上
        df_st.rename(
            columns={"ENTRY_DT": "entry_date", "S_INFO_WINDCODE": "code", "REMOVE_DT": "remove_date"},
            inplace=True)
        df_is_st = None
        for st_type, grouped in df_st.groupby("S_TYPE_ST"):
            df_is_st_ = get_single_category(grouped, all_date_list).reindex(columns=all_code_list).fillna(0).astype(
                bool).reindex(trade_date_list)
            if df_is_st is None:
                df_is_st = df_is_st_
            else:
                df_is_st = np.logical_or(df_is_st, df_is_st_)
        df_market = df_market.mask(df_is_st, ~df_is_st)
        res = df_market.to_dict(orient="index")
        res = {k: [inner_k for inner_k, inner_v in v.items() if inner_v] for k, v in
               res.items()}  # 将其中的False剔除# 将ST矩阵中的True复制到market矩阵并置为False
        return res


def get_index_member(index_code, begin_date=None, end_date=None, trade_date=None, n=None):
    """
    获取指数成分股
    函数参数和返回见get_stock_pool
    """
    from cscfist.process import AShareTradeDateUtils
    from cscfist.database.get_instance.wind_inst import wind_reader
    begin_date = transfer_end_n_to_begin(begin_date, end_date, n)
    if trade_date is not None:
        df = wind_reader.get_a_index_members(index_code, begin_date=trade_date, end_date=trade_date)
        return df["S_CON_WINDCODE"].tolist()
    else:
        trade_date_list = AShareTradeDateUtils().get_trade_date_list(begin_date, end_date)
        all_date_list = NatureDateUtils.get_dates("19900101", end_date)
        df = wind_reader.get_a_index_members(index_code, begin_date=begin_date, end_date=end_date)
        df.rename(columns={"S_CON_INDATE": "entry_date", "S_CON_OUTDATE": "remove_date", "S_CON_WINDCODE": "code"},
                  inplace=True)
        df_is_member = get_single_category(df, all_date_list).fillna(0).astype(
            bool).reindex(trade_date_list)
        res = df_is_member.to_dict(orient="index")
        res = {k: [inner_k for inner_k, inner_v in v.items() if inner_v] for k, v in
               res.items()}  # 将其中的False剔除# 将ST矩阵中的True复制到market矩阵并置为False
        return res


def get_stock_pool(pool_id: str = "ALL_EXCLUDE_SUB_NEW_ST", begin_date=None, end_date=None, trade_date=None,
                   n=None) -> Union[List[str], Dict[str, List[str]]]:
    """
    获取股票池
    "ALL_EXCLUDE_SUB_NEW_ST": 表示全部股票剔除次新股和ST, *ST, PT股
    "HS300": 沪深300
    "ZZ500": 中证500
    "ZZ800": 中证800
    "ZZ1000": 中证1000

    Args:
        pool_id: 股票池代码
        begin_date: 开始日期
        end_date: 结束日期
        trade_date: 交易日期
        n: 从end_date往前取多少日

    Returns:
        股票池
        若传入trade_date, 则返回list, 元素为当日股票池
        若传入begin_date, end_date或end_date, n, 则返回dict, Key为日期, Value为股票池
    """

    if pool_id in STOCK_POOL_DICT:
        return get_index_member(STOCK_POOL_DICT[pool_id], begin_date, end_date, trade_date, n)
    else:
        raise ValueError(f"{pool_id} not support, pool_id must be ALL_EXCLUDE_SUB_NEW_ST or index alias")


if __name__ == '__main__':
    res = get_stock_pool(begin_date="20220214", end_date="20220216")
    print(res)
    for k, v in res.items():
        print(k, len(v))
    res = get_stock_pool(trade_date="20220214")
    print(len(res))
    res = get_stock_pool("ZZ500", trade_date="20220214")
    print(len(res))

    res = get_stock_pool("ZZ500", begin_date="20220214", end_date="20220216")
    for k, v in res.items():
        print(k, len(v))
