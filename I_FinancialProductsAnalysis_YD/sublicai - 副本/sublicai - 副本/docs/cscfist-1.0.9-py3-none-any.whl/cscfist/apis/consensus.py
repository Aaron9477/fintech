# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/3/17 8:42
# @Author  : wangxybjs
# @File    : consensus.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------
"""
一致预期相关API
"""

from cscfist.tools import NatureDateUtils


def get_der_prob_excess_stock_by_date(information_code, date):
    """
    超预期事件api
    Args:
        information_code:
        date:
    Returns:

    """
    from cscfist.database.get_instance.zyyx_inst import zyyx_reader
    from cscfist.process import AShareTradeDateUtils
    trade_date_utils = AShareTradeDateUtils()
    trade_date = trade_date_utils.get_pre_nearest_trading_date(date)
    pre_trade_date = trade_date_utils.get_previous_trading_date(trade_date)
    natural_date = NatureDateUtils().date_period_change(pre_trade_date, '1d')
    df = zyyx_reader.get_der_prob_excess_stock(information_code, begin_date=natural_date, end_date=date)
    df["DECLARE_DATE"] = df["DECLARE_DATE"].apply(lambda x: trade_date_utils.get_next_nearest_trading_date(x))
    df["value"] = 1
    return df


def get_der_prob_excess_stock(information_code, begin_date=None, end_date=None):
    """
    超预期事件
    """
    from cscfist.database.get_instance.zyyx_inst import zyyx_reader
    df = zyyx_reader.get_der_prob_excess_stock(information_code, begin_date=begin_date, end_date=end_date)
    return df


def get_der_prob_below_stock(information_code, begin_date, end_date):
    """
    低于预期事件
    """
    from cscfist.database.get_instance.zyyx_inst import zyyx_reader
    df = zyyx_reader.get_der_prob_below_stock(information_code, begin_date=begin_date, end_date=end_date)
    return df


def get_rpt_rating_adjust(begin_date, end_date):
    """
    评级调整
    """
    from cscfist.database.get_instance.zyyx_inst import zyyx_reader
    df = zyyx_reader.get_rpt_rating_adjust(begin_date, end_date)
    return df


def get_rpt_earnings_adjust(begin_date, end_date):
    """
    报告盈利预测调整表
    """
    from cscfist.database.get_instance.zyyx_inst import zyyx_reader
    df = zyyx_reader.get_rpt_earnings_adjust(begin_date, end_date)
    return df


if __name__ == '__main__':
    res = get_der_prob_excess_stock_by_date("213", "20220327")
    print(res)
