# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/2/10 10:42
# @Author  : wangxybjs
# @File    : session.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.model.db_model.redis_model.query import Query


class RedisSession(object):
    """
    仿照sqlalchemy构造的session函数
    可以进行query查询
    """

    def __init__(self, redis_master):
        self.redis_master = redis_master

    def query(self, table, columns=None):
        return Query(self.redis_master, table, columns)
