# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/11/23 9:13
# @Author  : wangxybjs
# @File    : rdb_operator_base.py
# @Project : cscfist_base
# @Function: 
# @Version : V0.0.1
# ------------------------------
from typing import Dict, Union, List

import pandas as pd
from sqlalchemy import inspect, cast, VARCHAR
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from cscfist.model.db_model.rdb_model.rdb_connection_base import RdbConnectionBase
from cscfist.tools.res_cleaner import clean_res


class RdbBaseReader:
    """
    基础数据库读取
    """

    def __init__(self, db_connection: RdbConnectionBase):
        self.engine: Engine = db_connection.engine
        self.session: Session = db_connection.session
        self.make_session = db_connection.make_session

    def query(self, table_name=None, columns: Union[list, Dict, None] = None, func_query=None):
        """
        初始化查询query

        Args:
            table_name: 表名；
            columns: 查询的字段, 列表或字典. 若为字典, key是原始字段名, value是需要rename的别名；
            func_query: 聚合函数查询。
            注意：table_name与func_query必须至少指定一个，不可同时为None。

        Returns:
            query对象
        """
        query_columns = []
        # 查询某些字段
        if table_name is not None:
            if isinstance(columns, list):
                query_columns = [table_name.__dict__[name] for name in columns]
            elif isinstance(columns, dict):
                query_columns = [table_name.__dict__[name].label(alias) for name, alias in columns.items()]
            else:
                query_columns = [table_name]
        # 按聚合函数查询，如distinct、func.max
        if func_query is not None:
            if not isinstance(func_query, list):
                func_query = [func_query]
            query_columns += func_query

        if len(query_columns) == 0:
            raise ValueError('You must specify parameters of table_name or func_query, '
                             'which cannot be None at the same time')
        with self.make_session() as session:
            query = session.query(*query_columns)
        return query

    def read_sql(self, query) -> pd.DataFrame:
        return pd.read_sql(query.statement, self.engine)

    @staticmethod
    def filter_date(query, filter_column, begin_date=None, end_date=None, trade_date=None,
                    date_type=VARCHAR(8), if_cast=False):
        """
        日期筛选

        Args:
            query: query对象；
            filter_column: 过滤字段，如：table_name.TRADE_DT；
            begin_date: 开始时间；
            end_date: 结束时间；
            trade_date: 交易日；
            date_type：日期类型；
            if_cast：是否转换日期类型，默认不转换

        Returns:
            query对象
        """
        if begin_date is not None:
            if if_cast:
                query = query.filter(filter_column >= cast(begin_date, date_type))
            else:
                query = query.filter(filter_column >= begin_date)
        if end_date is not None:
            if if_cast:
                query = query.filter(filter_column <= cast(end_date, date_type))
            else:
                query = query.filter(filter_column <= end_date)
        if trade_date is not None:
            if if_cast:
                query = query.filter(filter_column == cast(trade_date, date_type))
            else:
                query = query.filter(filter_column == trade_date)
        return query

    def batch_query(self, query, batch_column=None, batch_value=None, batch_size=500) -> pd.DataFrame:
        """
        分批量查询数据

        Args:
            query: 查询对象，如：query = self.query(table_name)；
            batch_column: 批量查询的字段，如：table_name.S_INFO_WINDCODE；
            batch_value: str,list,None, 查询字段值，如：['000001.OF']；
            batch_size: 每次批量获取的大小。

        Returns:
            查询数据DataFrame
        """
        # 保证结果一定有列名
        df = pd.DataFrame(columns=[x[0] for x in query.statement.columns._collection])
        if batch_value is None:
            df = self.read_sql(query)
        elif isinstance(batch_value, str) or isinstance(batch_value, int):
            query_single = query.filter(batch_column == batch_value)
            df = self.read_sql(query_single)
        elif isinstance(batch_value, list):
            if len(batch_value) <= batch_size:
                query_batch = query.filter(batch_column.in_(batch_value))
                df = self.read_sql(query_batch)
            else:
                for i in range(0, len(batch_value), batch_size):
                    batch_value_i = batch_value[i:i + batch_size]
                    query_batch_i = query.filter(batch_column.in_(batch_value_i))
                    df_batch_i = self.read_sql(query_batch_i)
                    df = df.append(df_batch_i)
        return df

    @staticmethod
    def get_table_dtype(table):
        """
        读取表结构

        Args:
            table: 表

        Returns:
            dtype_dict: Key是字段, Value是其类型
        """
        dtype_dict = {}
        for c in inspect(table).columns:
            column = c.name
            dtype = c.type.python_type.__name__
            dtype_transfer = {"str": "str", "Decimal": "float", "datetime": "datetime64"}
            if dtype in dtype_transfer:
                dtype = dtype_transfer[dtype]
            dtype_dict[column] = dtype
        return dtype_dict


class RdbBaseSaver:
    """
    基础数据库存储
    """

    def __init__(self, db_connection: RdbConnectionBase):
        self.engine: Engine = db_connection.engine
        self.session: Session = db_connection.session
        self.make_session = db_connection.make_session

    def _save(self, table, dict_list_or_dataframe: Union[List, Dict, pd.DataFrame]):
        """
        Args:
            table: 表
            dict_list_or_dataframe: 字典或字典列表或DataFrame
                若为字典或字典列表, Key为字段名, Value为值
                若为DataFrame, 列为字段名
        """
        dict_list = None
        if isinstance(dict_list_or_dataframe, Dict):
            dict_list = [dict_list_or_dataframe]  # 若为字典, 先转为字典列表
        elif isinstance(dict_list_or_dataframe, pd.DataFrame):
            dict_list = dict_list_or_dataframe.to_dict(orient='records')  # 若为dataframe, 转为字典列表
        elif isinstance(dict_list_or_dataframe, List):
            dict_list = dict_list_or_dataframe

        record_list = []
        columns = [c.name for c in inspect(table).columns]
        for d in dict_list:
            d = {k: clean_res(v) for k, v in d.items() if k in columns}
            record = table(**d)
            record_list.append(record)
        with self.make_session() as session:
            session.bulk_save_objects(record_list)


class RdbBaseUpdater:
    """
    基础数据库更新
    """

    def __init__(self, db_connection: RdbConnectionBase):
        """
        Args:
            db_connection: 数据库连接
        """
        self.engine: Engine = db_connection.engine
        self.session: Session = db_connection.session
        self.make_session = db_connection.make_session

    def _update(self, table, update_list):
        """
        Args:
            table: 表
            update_list: 是一个字典的列表, 每个字典是代表一个update语句, 有filter和update两个字典, 分别代表需要筛选和更新的部分
                例如update_list = [{'filter': {'match_column1': match_value1, 'match_column2': match_value2},
                'update': {'update_column1': update_value1, 'update_column2': update_value2}}, ...]
                表示`update table set update_column1=update_value1, update_column2=update_value2 where
                match_column1=match_value1 and match_column2=match_value2`
        """
        with self.make_session() as session:
            query = session.query(table)
            for update_record in update_list:
                filter_condition_dict = update_record['filter']
                update_res_dict = update_record['update']
                filter_condition = [getattr(table, col) == v if v is not None else getattr(table, col).is_(None) for
                                    col, v in filter_condition_dict.items()]
                query_single = query.filter(*filter_condition)
                update_record_dict = {getattr(table, col): clean_res(v) for col, v in update_res_dict.items()}
                query_single.update(update_record_dict, synchronize_session=False)


class RdbBaseDeleter:
    """
    基础数据库删除
    """

    def __init__(self, db_connection: RdbConnectionBase):
        """
        Args:
            db_connection: 数据库连接
        """
        self.engine: Engine = db_connection.engine
        self.session: Session = db_connection.session
        self.make_session = db_connection.make_session

    def _delete(self, table, del_record_list):
        """
        Args:
            table: 表
            del_record_list: 是一个字典列表, 每个字典代表一个delete语句, Key是筛选字段, Value是筛选值
                例如del_record_list = [{'match_column1': match_value1, 'match_column2': match_value2}, ...]
                代表`delete from table where match_column1=match_value1 and match_column2=match_value2`
        """
        with self.make_session() as session:
            query = session.query(table)
            for del_record in del_record_list:
                filter_condition_dict = del_record
                filter_condition = [getattr(table, col) == v for col, v in filter_condition_dict.items()]
                query = query.filter(*filter_condition)
                query.delete()
