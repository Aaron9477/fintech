# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/2/10 10:29
# @Author  : wangxybjs
# @File    : column.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
from cscfist.model.db_model.redis_model.redis_filter_operator import RedisFilterOperator


class Column:
    """
    定义Redis中的一列
    """

    def __init__(self, data_type, is_ts_date=False, is_ts_code=False, is_hash_key=False, comment=None, default=None):
        self.type = data_type
        self.is_ts_date = is_ts_date
        self.is_ts_code = is_ts_code
        self.is_hash_key = is_hash_key
        self.comment = comment
        self.default = default

    def __ge__(self, other):
        return RedisFilterOperator.ge(self, other)

    def __eq__(self, other):
        return RedisFilterOperator.eq(self, other)

    def __le__(self, other):
        return RedisFilterOperator.le(self, other)

    def in_(self, other):
        return RedisFilterOperator.in_(self, other)
