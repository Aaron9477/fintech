# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/1/5 14:12
# @Author  : wangxybjs
# @File    : rdb_operator_base.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
import json
from typing import Union, List, Dict

import pandas as pd

from cscfist.model.db_model.redis_model.abstract_table import AbstractRedisTable
from cscfist.model.db_model.redis_model.column import Column
from cscfist.tools.data_type_transfer import transfer_input_to_dict_list, transfer_input_to_df


class RedisBaseSaver:
    def __init__(self, redis_session):
        self.redis_session = redis_session
        self.redis_master = redis_session.redis_master

    def _save(self, table, dict_list_or_dataframe: Union[List, Dict, pd.DataFrame], pipeline=None):
        if len(dict_list_or_dataframe) == 0:
            return
        if table.__redis_type__ == "time_series":
            self._save_ts(table, dict_list_or_dataframe, pipeline)
        else:
            self._save_cross(table, dict_list_or_dataframe, pipeline)

    def _save_ts(self, table: AbstractRedisTable, dict_list_or_dataframe: Union[List, Dict, pd.DataFrame],
                 pipeline=None):
        """
        Args:
            table: 时间序列型表
            dict_list_or_dataframe: 字典或字典列表或DataFrame
                若为字典或字典列表, Key为字段名, Value为值
                若为DataFrame, 列为字段名
        """
        if len(dict_list_or_dataframe) == 0:
            return
        assert table.__redis_type__ == "time_series"
        if pipeline is None:
            operator = self.redis_master
        else:
            operator = pipeline
        df = transfer_input_to_df(dict_list_or_dataframe)
        ts_code_column = table.get_table_ts_code_column()
        ts_date_column = table.get_table_ts_date_column()
        columns = table.get_table_columns(include_cal_update=True)
        for column_name in columns:
            column_object = getattr(table, column_name)
            if column_object.default is not None and column_name not in df.columns:
                if callable(column_object.default):
                    df[column_name] = column_object.default()
                else:
                    df[column_name] = column_object.default
        for code, grouped in df.groupby(ts_code_column):
            res_name = f"{table.__redis_name__}:{code}"
            res_dict = grouped.set_index(ts_date_column, drop=False).to_dict('index')
            # 序列化
            mapping = {json.dumps(v, ensure_ascii=False): int(k) for k, v in res_dict.items()}
            if len(mapping) > 0:
                operator.zadd(res_name, mapping)

    def _save_cross(self, table: AbstractRedisTable, dict_list_or_dataframe: Union[List, Dict, pd.DataFrame],
                    pipeline=None):
        """
        Args:
            table: 横截面型表
            dict_list_or_dataframe: 字典或字典列表或DataFrame
                若为字典或字典列表, Key为字段名, Value为值
                若为DataFrame, 列为字段名
        """
        if len(dict_list_or_dataframe) == 0:
            return
        assert table.__redis_type__ == "cross_sectional"
        if pipeline is None:
            operator = self.redis_master
        else:
            operator = pipeline
        df = transfer_input_to_df(dict_list_or_dataframe)
        hash_column = table.get_cross_hash_key()
        columns = table.get_table_columns(include_cal_update=True)
        for column_name in columns:
            column_object = getattr(table, column_name)
            if column_object.default is not None and column_name not in df.columns:
                if callable(column_object.default):
                    df[column_name] = column_object.default()
                else:
                    df[column_name] = column_object.default
        res_mapping = {}
        for code, grouped in df.groupby(hash_column):
            res_mapping[code] = json.dumps(grouped.to_dict('records'), ensure_ascii=False)
        res_mapping = {k: json.dumps(v, ensure_ascii=False) for k, v in res_mapping.items()}
        if len(res_mapping) > 0:
            operator.hset(table.__redis_name__, mapping=res_mapping)


class RedisBaseReader:
    def __init__(self, redis_session):
        self.session = redis_session
        self.redis_master = self.session.redis_master

    @staticmethod
    def filter_date(query, filter_column: Column, begin_date=None, end_date=None, trade_date=None):
        """
        日期筛选

        Args:
            query: query对象；
            filter_column: 过滤字段，如：table_name.TRADE_DT；
            begin_date: 开始时间；
            end_date: 结束时间；
            trade_date: 交易日；

        Returns:
            query对象
        """
        if begin_date is not None:
            query = query.filter(filter_column >= begin_date)
        if end_date is not None:
            query = query.filter(filter_column <= end_date)
        if trade_date is not None:
            query = query.filter(filter_column == trade_date)
        return query

    @staticmethod
    def filter_code(query, filter_column, code=None):
        """
        代码筛选

        Args:
            query:
            code_column:
            code:

        Returns:
            query对象
        """
        if code is not None:
            if isinstance(code, str):
                query = query.filter(filter_column == code)
            elif isinstance(code, list):
                query = query.filter(filter_column.in_(code))
        return query

    @staticmethod
    def get(query):
        return query.get()


class RedisBaseDeleter:
    def __init__(self, redis_session):
        self.session = redis_session
        self.redis_master = self.session.redis_master

    def _delete_ts(self, table, code, date_list, pipeline=None):
        assert table.__redis_type__ == "time_series"
        if pipeline is None:
            operator = self.redis_master
        else:
            operator = pipeline
        if code is None:
            code_list = self.redis_master.keys(f"{table.__redis_name__}:*")
            code_list = list(set([s.split(":")[-1] for s in code_list]))
        elif isinstance(code, str):
            code_list = [code]
        else:
            code_list = code
        for code in code_list:
            redis_name = f"{table.__redis_name__}:{code}"
            if isinstance(date_list, list):
                for date in date_list:
                    operator.zremrangebyscore(redis_name, int(date), int(date))
            elif date_list is None:
                operator.delete(redis_name)

    def _delete_cross(self, table, code, pipeline=None):
        assert table.__redis_type__ == "cross_sectional"
        if pipeline is None:
            operator = self.redis_master
        else:
            operator = pipeline
        if code is None:
            code_list = self.redis_master.keys(f"{table.__redis_name__}:*")
            code_list = list(set([s.split(":")[-1] for s in code_list]))
        elif isinstance(code, str):
            code_list = [code]
        else:
            code_list = code
        for code in code_list:
            redis_name = table.__redis_name__
            operator.hdel(redis_name, code)  # 只能单个删除
