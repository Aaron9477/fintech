# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/12/14 13:43
# @Author  : wangxybjs
# @File    : market_reader_cache2.py
# @Project : cscfist
# @Function:
# @Version : V0.0.1
# ------------------------------
"""
解决读取redis时, 先update再get前后不一致问题, 即前一秒update后被清空, 后一秒get获取不到数据
"""
from dataclasses import dataclass
from enum import Enum
from typing import Union


class RedisFilterOperatorEnum(Enum):
    """
    Redis筛选的操作符枚举
    """
    EQ = "等于Equal"
    GE = "大于等于Greater Than"
    LE = "小于等于Less Than"
    IN = "属于In"


@dataclass
class RedisFilterOperatorType:
    """
    定义筛选操作数据结构, 本质是一个三元组
    """
    operator: RedisFilterOperatorEnum
    column: None
    other: Union[str, list]


class RedisFilterOperator:
    """
    定义筛选操作, 返回三元组
    """

    @staticmethod
    def eq(column, other):
        return RedisFilterOperatorType(operator=RedisFilterOperatorEnum.EQ, column=column, other=other)

    @staticmethod
    def ge(column, other):
        return RedisFilterOperatorType(operator=RedisFilterOperatorEnum.GE, column=column, other=other)

    @staticmethod
    def le(column, other):
        return RedisFilterOperatorType(operator=RedisFilterOperatorEnum.LE, column=column, other=other)

    @staticmethod
    def in_(column, other):
        return RedisFilterOperatorType(operator=RedisFilterOperatorEnum.IN, column=column, other=other)
