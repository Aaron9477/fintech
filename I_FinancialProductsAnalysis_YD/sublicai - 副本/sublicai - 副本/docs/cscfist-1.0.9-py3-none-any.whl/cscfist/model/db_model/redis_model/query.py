# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/2/10 10:38
# @Author  : wangxybjs
# @File    : query.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
import json
from typing import Union, List

import numpy as np
import pandas as pd
from cscfist.model.db_model.redis_model.redis_filter_operator import RedisFilterOperatorType, RedisFilterOperatorEnum
from cscfist.tools import assure_redis_connection


class Query(object):
    def __init__(self, redis_master, table, columns=Union[List, None]):
        self.redis_master = redis_master
        self.table = table
        self.columns = columns if columns is not None else table.get_table_columns()
        if table.__redis_type__ == "time_series":
            # 时间序列型
            self.ts_date_column = table.get_table_ts_date_column()
            if self.ts_date_column not in self.columns:
                self.columns.append(self.ts_date_column)
            self.ts_code_column = table.get_table_ts_code_column()
            if self.ts_code_column not in self.columns:
                self.columns.append(self.ts_code_column)
            self.ts_code_list = None
            self.ts_begin_date = '0'
            self.ts_end_date = '99999999'
        else:
            # 横截面型
            self.redis_hkey_list = None
            self.hash_code_column = self.table.get_cross_hash_key()
            if self.hash_code_column not in self.columns:
                self.columns.append(self.hash_code_column)

    @assure_redis_connection
    def exists(self, name) -> np.ndarray:
        if isinstance(name, str):
            res = self.redis_master.exists(name)
        else:
            res = []
            for n in name:
                res.append(self.redis_master.exists(n))
        return np.array(res).astype(bool)

    @assure_redis_connection
    def hexists(self, name, key):
        if isinstance(key, str):
            res = self.redis_master(name, key)
        else:
            exist_keys = self.redis_master.hkeys(name)
            res = np.isin(key, exist_keys)
        return np.array(res).astype(bool)

    @assure_redis_connection
    def hkeys(self, name) -> np.ndarray:
        return np.array(self.redis_master.hkeys(name))

    @assure_redis_connection
    def hmget(self, name, keys):
        if keys is None:
            keys = self.redis_master.hkeys(name)
        if isinstance(keys, str):
            res = [self.redis_master.hget(name, keys)]
        else:
            res = []
            for i in range(0, len(keys), 100):
                batch = keys[i:i + 100]
                single_res = self.redis_master.hmget(name, batch)
                res.extend(single_res)
        res = [json.loads(line) for line in res if line is not None]
        return res

    @assure_redis_connection
    def hgetall(self, name):
        return self.redis_master.hgetall(name)

    @assure_redis_connection
    def get_z_max_score(self, name) -> str:
        """
        获取name的最大得分, 注意返回str类型
        """
        max_score_list = self.redis_master.zrevrange(name, 0, 0, withscores=True, score_cast_func=int)
        score_max = None
        if len(max_score_list) > 0:
            score_max = str(max_score_list[0][1])
        return score_max

    @assure_redis_connection
    def delete(self, name):
        return self.redis_master.delete(name)

    @assure_redis_connection
    def zadd(self, name, mapping):
        return self.redis_master.zadd(name, mapping)

    @assure_redis_connection
    def zrangebyscore(self, name, begin_date, end_date, withscores=True):
        return self.redis_master.zrangebyscore(name, begin_date, end_date, withscores=withscores)

    @assure_redis_connection
    def keys(self, pattern):
        return self.redis_master.keys(pattern)

    def filter(self, *conditions: RedisFilterOperatorType):
        if self.table.__redis_type__ == 'time_series':
            return self.filter_time_series(*conditions)
        elif self.table.__redis_type__ == 'cross_sectional':
            return self.filter_hash(*conditions)

    def get(self):
        if self.table.__redis_type__ == 'time_series':
            return self.get_ts()
        elif self.table.__redis_type__ == 'cross_sectional':
            return self.get_hash()

    def filter_time_series(self, *conditions: RedisFilterOperatorType):
        # 1. 修改redis_name
        key_equal_or_in_conditions = [c for c in conditions if c.column.is_ts_code and
                                      c.operator in [RedisFilterOperatorEnum.EQ, RedisFilterOperatorEnum.IN]]
        redis_key_list = []
        if len(key_equal_or_in_conditions) > 0:  # 若为eq或in的形式, 则修改self.redis_name_list
            for cond in key_equal_or_in_conditions:
                if cond.operator == RedisFilterOperatorEnum.EQ:
                    redis_key = [cond.other]
                else:
                    redis_key = [code for code in cond.other]
                redis_key_list = redis_key_list + redis_key
            new_redis_key_list = list(set(redis_key_list))
            if self.ts_code_list is None:  # 代表没有修改过self.redis_name_list
                self.ts_code_list = new_redis_key_list
            else:
                self.ts_code_list = list(set(self.ts_code_list) & set(new_redis_key_list))
        # 2. 修改score范围
        score_unequal_conditions = [c for c in conditions if c.column.is_ts_date and
                                    c.operator in [RedisFilterOperatorEnum.GE, RedisFilterOperatorEnum.LE,
                                                   RedisFilterOperatorEnum.EQ]]
        for cond in score_unequal_conditions:
            if cond.operator == RedisFilterOperatorEnum.GE:
                self.ts_begin_date = max(self.ts_begin_date, cond.other)
            if cond.operator == RedisFilterOperatorEnum.LE:
                self.ts_end_date = min(self.ts_end_date, cond.other)
            if cond.operator == RedisFilterOperatorEnum.EQ:
                self.ts_begin_date = cond.other
                self.ts_end_date = cond.other

        return self

    def get_ts(self):
        # 解析json格式
        if self.ts_code_list is None:
            code_list = self.keys(f"{self.table.__redis_name__}*")
            code_list = list(set([s.split(":")[-1] for s in code_list]))
            self.ts_code_list = code_list
        df_res = pd.DataFrame(columns=self.table.get_table_columns())
        for code in self.ts_code_list:
            redis_name = f"{self.table.__redis_name__}:{code}"
            if not self.redis_master.exists(redis_name):
                continue
            redis_res = self.redis_master.zrangebyscore(redis_name, self.ts_begin_date, self.ts_end_date, withscores=True)
            if redis_res is None or len(redis_res) == 0:
                continue
            res_dict = {str(int(time_tag)): json.loads(price) for price, time_tag in redis_res}
            df = pd.DataFrame(res_dict).T.reset_index(drop=True)
            df_res = df_res.append(df)

        df_res[self.ts_date_column] = df_res[self.ts_date_column].astype(getattr(self.table, self.ts_date_column).type)
        df_res = df_res[self.columns]
        return df_res

    def filter_hash(self, *conditions: RedisFilterOperatorType):
        equal_or_in_conditions = [c for c in conditions if
                                  c.operator in [RedisFilterOperatorEnum.EQ, RedisFilterOperatorEnum.IN]]
        redis_hkey_list = []
        if len(equal_or_in_conditions) > 0:
            for cond in equal_or_in_conditions:
                if not cond.column.is_hash_key:
                    raise ValueError('Equal type filter column must set `is_hash_key`=True !')
                if cond.operator == RedisFilterOperatorEnum.EQ:
                    redis_hkey = [cond.other]
                else:
                    redis_hkey = [code for code in cond.other]
                redis_hkey_list += redis_hkey
            new_redis_hkey_list = list(set(redis_hkey_list))
            if self.redis_hkey_list is None:  # 代表没有修改过self.redis_hkey_list
                self.redis_hkey_list = redis_hkey_list
            else:
                self.redis_hkey_list = list(set(self.redis_hkey_list) & set(new_redis_hkey_list))
        return self

    def get_hash(self):
        df_res = pd.DataFrame(columns=self.table.get_table_columns())
        if self.redis_hkey_list is None:
            self.redis_hkey_list = self.hkeys(self.table.__redis_name__)
        for redis_hkey in self.redis_hkey_list:
            redis_res = self.hmget(self.table.__redis_name__, redis_hkey)
            if redis_res is None or len(redis_res) == 0:
                continue
            df = pd.DataFrame(json.loads(redis_res[0]))
            df_res = df_res.append(df)
        df_res = df_res[self.columns]
        return df_res
