# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/2/9 9:01
# @Author  : wangxybjs
# @File    : abstract_table.py
# @Project : cscfist
# @Function: 
# @Version : V0.0.1
# ------------------------------
"""
存储Redis表基类
"""
import abc

from cscfist.model.db_model.redis_model.column import Column


class AbstractRedisTable(metaclass=abc.ABCMeta):
    @property
    @abc.abstractmethod
    def __redis_name__(self):
        """存储在Redis中的Key前缀"""
        raise NotImplementedError

    @property
    @abc.abstractmethod
    def __redis_type__(self):
        """Redis类型, 目前为time_series或cross_sectional"""
        raise NotImplementedError

    @classmethod
    def get_table_columns(cls, include_cal_update=False):
        """
        获取表全部字段
        """
        all_keys = list(cls.__dict__.keys())
        column_list = [k for k in all_keys if isinstance(getattr(cls, k), Column)]
        if not include_cal_update:
            column_list = [c for c in column_list if c not in ("CAL_DATE", "UPDATE_TIME")]
        return column_list

    @classmethod
    def get_table_ts_code_column(cls):
        """
        获取时间序列类型表的代码字段
        """
        assert cls.__redis_type__ == "time_series", "此表非time_series类型, 无法调用本函数"
        all_columns = cls.get_table_columns()
        for column in all_columns:
            if getattr(cls, column).is_ts_code:
                return column

    @classmethod
    def get_table_ts_date_column(cls):
        """
        获取时间序列类型表的日期字段
        """
        assert cls.__redis_type__ == "time_series", "此表非time_series类型, 无法调用本函数"
        all_columns = cls.get_table_columns()
        for column in all_columns:
            if getattr(cls, column).is_ts_date:
                return column

    @classmethod
    def get_table_ts_plain_column(cls):
        """
        获取时间序列类型表的数值型字段
        """
        assert cls.__redis_type__ == "time_series", "此表非time_series类型, 无法调用本函数"
        all_columns = cls.get_table_columns()
        ts_code_column = cls.get_table_ts_code_column()
        ts_date_column = cls.get_table_ts_date_column()
        all_columns.remove(ts_code_column)
        all_columns.remove(ts_date_column)
        return all_columns

    @classmethod
    def get_ts_redis_key(cls, code: str, column: str) -> str:
        """
        获取时间序列型Redis的key

        Args:
            code: 代码
            column: 字段

        Returns:
            拼接后的redis, 是实际的key
        """
        return f"{cls.__redis_name__}:{code}:{column}"

    @classmethod
    def get_cross_hash_key(cls) -> str:
        """
        获取横截面型Redis的key
        """
        assert cls.__redis_type__ == "cross_sectional", "此表非cross_sectional类型, 无法调用本函数"
        all_columns = cls.get_table_columns()
        for column in all_columns:
            if getattr(cls, column).is_hash_key:
                return column
