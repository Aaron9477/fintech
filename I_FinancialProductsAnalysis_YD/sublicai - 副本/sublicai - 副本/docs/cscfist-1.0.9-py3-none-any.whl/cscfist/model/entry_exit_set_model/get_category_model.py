# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2022/2/23 15:30
# @Author  : wangxybjs
# @File    : entry_exit_set_model.py
# @Project : stock_factor_analysis
# @Function: 
# @Version : V0.0.1
# ------------------------------
"""
将进入退出类型的日期扩充至全量日期
"""
import pandas as pd


def get_single_category(df: pd.DataFrame, all_date_list):
    """
    扩充进入、退出数据得到全量时间数据
    每个时间每个代码为True/False结果

    例如沪深300指数成分, 每只股票不同时间只有属于/不属于两种状态
    """
    df["value"] = 1
    entry_pivot = df.drop_duplicates(subset=["entry_date", "code"]).pivot("entry_date", "code", "value").reindex(
        all_date_list)
    remove_pivot = df.drop_duplicates(subset=["remove_date", "code"]).pivot("remove_date", "code", "value").reindex(
        all_date_list)
    df = entry_pivot.mask(remove_pivot == 1, 0)  # 将remove矩阵中的值部分复制到entry矩阵相应位置并设置为0
    df = df.fillna(method="pad").fillna(0).astype(bool)
    return df
