# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/8/18 10:39
# @author  : wangxybjs
# @File    : risk_budgeting.py
# @Project : cscfist
# @Function: 风险预算模型
# @Version : V0.0.1
# ------------------------------
import warnings
from typing import List
from typing import Union, Tuple

import numpy as np
import pandas as pd

from pypfopt import base_optimizer


class RiskBudgeting(base_optimizer.BaseOptimizer):
    """
    风险预算模型

    输出方法:

    - ``optimize()`` 优化权重
    - ``portfolio_performance()`` 计算预期收益率, 波动率, 夏普比率
    - ``set_weights()`` creates self.weights (np.ndarray) from a weights dict
    - ``clean_weights()`` rounds the weights and clips near-zeros.
    - ``save_weights_to_file()`` saves the weights to csv, json, or txt.
    """

    def __init__(
            self,
            expected_returns: Union[pd.Series, list, np.ndarray, None],
            cov_matrix: Union[pd.DataFrame, np.ndarray],
            risk_budget: List,
            weight_bounds: Union[List, Tuple] = (0, 1),
    ):
        """
        Parameters
        ----------
        expected_returns: 预期收益率, 若仅按波动优化则可为None
        cov_matrix: 协方差矩阵
        weight_bounds: 权重限制

        Raises
        ------
        TypeError: expected_returns非指定格式
        TypeError: cov_matrix非指定格式
        ValueError: cov_matrix与预期收益大小不匹配
        """
        # 输入
        self.cov_matrix = RiskBudgeting._validate_cov_matrix(cov_matrix)
        self.expected_returns = RiskBudgeting._validate_expected_returns(
            expected_returns
        )
        self.risk_budget = np.array(risk_budget)
        num_assets = len(cov_matrix)

        # 标签
        if isinstance(expected_returns, pd.Series):
            tickers = list(expected_returns.index)
        elif isinstance(cov_matrix, pd.DataFrame):
            tickers = list(cov_matrix.columns)
        else:  # use integer labels
            tickers = list(range(num_assets))
        # 权重界限
        if isinstance(weight_bounds, Tuple):
            self.weight_bounds = [weight_bounds for _ in range(len(tickers))]
        else:
            self.weight_bounds = weight_bounds

        if expected_returns is not None and cov_matrix is not None:
            if cov_matrix.shape != (num_assets, num_assets):
                raise ValueError("Covariance matrix does not match expected returns")

        super().__init__(
            len(tickers),
            tickers
        )

    @staticmethod
    def _validate_expected_returns(expected_returns):
        if expected_returns is None:
            return None
        elif isinstance(expected_returns, pd.Series):
            return expected_returns.values
        elif isinstance(expected_returns, list):
            return np.array(expected_returns)
        elif isinstance(expected_returns, np.ndarray):
            return expected_returns.ravel()
        else:
            raise TypeError("expected_returns is not a series, list or array")

    @staticmethod
    def _validate_cov_matrix(cov_matrix):
        if cov_matrix is None:
            raise ValueError("cov_matrix must be provided")
        elif isinstance(cov_matrix, pd.DataFrame):
            return cov_matrix.values
        elif isinstance(cov_matrix, np.ndarray):
            return cov_matrix
        else:
            raise TypeError("cov_matrix is not a dataframe or array")

    def _portfolio_std(self, weights: np.ndarray) -> float:
        """
        计算组合的标准差

        Parameters
        ----------
        weights: 权重
        """
        return np.sqrt(weights @ self.cov_matrix @ weights.T)

    def cal_risk_contribution(self, weights: np.ndarray) -> float:
        """
        计算风险贡献, 各分量风险贡献之和为组合总标准差

        Parameters
        ----------
        weights: 权重
        """
        rc = self.cov_matrix @ weights * weights / self._portfolio_std(weights)
        return rc

    def cost_function(self, weights: np.ndarray) -> float:
        """
        风险预算的损失函数

        Parameters
        ----------
        weights: 权重
        """
        rc = self.cal_risk_contribution(weights)
        res = np.sum(np.square(rc - self.risk_budget * self._portfolio_std(weights))) * 100000
        return res

    @staticmethod
    def constraint_weight_sum(x):
        """
        限制权重之和为1
        """
        return np.sum(x) - 1.0

    @staticmethod
    def constrain_weight_neq_0(x):
        """
        限制权重不为0
        """
        return x

    def optimize(self):
        """
        风险预算优化
        """
        from scipy.optimize import minimize
        start_weight = np.ones(len(self.tickers)) / len(self.tickers)
        cons = ({'type': 'eq', 'fun': self.constraint_weight_sum}, {'type': 'ineq', 'fun': self.constrain_weight_neq_0})
        result = minimize(self.cost_function, start_weight, method='SLSQP',
                          constraints=cons, options={'disp': False}, tol=0.01, bounds=self.weight_bounds)
        self.weights = result.x

    def portfolio_performance(self, verbose=False, risk_free_rate=0.02):
        """
        After optimising, calculate (and optionally print) the performance of the optimal
        portfolio. Currently calculates expected return, volatility, and the Sharpe ratio.

        :param verbose: whether performance should be printed, defaults to False
        :type verbose: bool, optional
        :param risk_free_rate: risk-free rate of borrowing/lending, defaults to 0.02.
                               The period of the risk-free rate should correspond to the
                               frequency of expected returns.
        :type risk_free_rate: float, optional
        :raises ValueError: if weights have not been calcualted yet
        :return: expected return, volatility, Sharpe ratio.
        :rtype: (float, float, float)
        """
        if self._risk_free_rate is not None:
            if risk_free_rate != self._risk_free_rate:
                warnings.warn(
                    "The risk_free_rate provided to portfolio_performance is different"
                    " to the one used by max_sharpe. Using the previous value.",
                    UserWarning,
                )
            risk_free_rate = self._risk_free_rate

        return base_optimizer.portfolio_performance(
            self.weights,
            self.expected_returns,
            self.cov_matrix,
            verbose,
            risk_free_rate,
        )
