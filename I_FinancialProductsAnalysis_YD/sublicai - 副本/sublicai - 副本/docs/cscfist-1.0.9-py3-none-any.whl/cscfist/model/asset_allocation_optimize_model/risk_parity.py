# -*- coding: utf-8 -*-
# ------------------------------
# @Time    : 2021/8/18 10:39
# @author  : wangxybjs
# @File    : risk_parity.py
# @Project : cscfist
# @Function: 风险平价模型
# @Version : V0.0.1
# ------------------------------
from typing import List, Tuple, Union

import numpy as np
import pandas as pd

from cscfist.model.asset_allocation_optimize_model.risk_budgeting import RiskBudgeting


class RiskParity(RiskBudgeting):
    def __init__(self,
                 expected_returns: Union[pd.Series, list, np.ndarray, None],
                 cov_matrix: Union[pd.DataFrame, np.ndarray],
                 weight_bounds: Union[List, Tuple] = (0, 1)):
        risk_budget = np.ones(len(cov_matrix)) / len(cov_matrix)
        super().__init__(expected_returns, cov_matrix, risk_budget, weight_bounds)
