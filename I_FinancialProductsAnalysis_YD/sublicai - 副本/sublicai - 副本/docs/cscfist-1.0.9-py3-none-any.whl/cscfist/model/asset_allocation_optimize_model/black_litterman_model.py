import numpy as np
import pandas as pd


def black_litterman_adjust(asset_return, cov_matrix, conf_level, P, Q, fund_codes):
    """
    BL模型调整, 输出调整后的收益率和协方差矩阵
    """
    return_ex_ante = asset_return
    risk_ex_ante = cov_matrix
    confidence_level = conf_level
    pil = np.expand_dims(return_ex_ante, axis=0).T

    p_star = np.sum(P, axis=0)
    cf = np.dot(np.dot(p_star, risk_ex_ante), p_star.T) / (1 / 0.5)
    tau = np.dot(np.dot(p_star, risk_ex_ante), p_star.T) * len(confidence_level) / np.sum(
        [cf / item for item in confidence_level])

    ts = tau * risk_ex_ante
    ts_1 = np.linalg.inv(ts)
    confidence_level = [1 / item for item in confidence_level]
    omega = cf * np.diag(confidence_level)
    # omega=np.dot(np.dot(P,ts),P.T)*np.eye(Q.shape[0])
    omega_1 = np.linalg.inv(omega)

    return_ex_post = np.dot(np.linalg.inv(ts_1 + np.dot(np.dot(P.T, omega_1), P)),
                            (np.dot(ts_1, pil) + np.dot(np.dot(P.T, omega_1), Q)))
    risk_ex_post = risk_ex_ante + np.linalg.inv(ts_1 + np.dot(np.dot(P.T, omega_1), P))

    asset_return_post = pd.Series(index=fund_codes, data=np.squeeze(return_ex_post))
    cov_matrix_post = risk_ex_post
    return asset_return_post, cov_matrix_post
