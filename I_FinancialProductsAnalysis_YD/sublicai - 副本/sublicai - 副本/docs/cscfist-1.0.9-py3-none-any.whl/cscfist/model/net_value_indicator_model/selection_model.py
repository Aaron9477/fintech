"""
择时能力
选股能力
择时选股模型R方
"""

import abc
import numpy as np
import pandas as pd


class TimingSelectionRegressModel(metaclass=abc.ABCMeta):
    """
    回归类的择时选股能力
    """

    def __init__(self, portfolio_return_list, benchmark_return_list, risk_free_rate, is_shrink: bool = False,
                 shrink_p: float = 0.05):
        """
        HM择时选股模型

        Parameters
        ----------
        portfolio_return_list: 待分析收益率序列
        benchmark_return_list: 基准收益率序列
        risk_free_rate: 无风险收益率, 与收益率序列频率保持一致, 例如若收益率为日度, 则为年化无风险收益率/252
        is_shrink: 是否收缩
        shrink_p: 收缩时采取的p值

        Returns
        -------
        selection_res: 选股能力
        timing_res: 择时能力
        fit_result: 回归结果

        收缩时, 根据回归的p值是否大于阈值p值, 若大于则进行收缩. 根据实际t值和理论t值, 按比例收缩
        """
        self.portfolio_return_list = portfolio_return_list
        self.benchmark_return_list = benchmark_return_list
        self.risk_free_rate = risk_free_rate
        self.is_shrink = is_shrink
        self.shrink_p = shrink_p

    @abc.abstractmethod
    def construct_x(self) -> pd.DataFrame:
        """
        构造回归的X变量
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_timing_res(self, fit_result) -> float:
        """
        获取择时能力
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_selection_res(self, fit_result) -> float:
        """
        获取选股能力
        """
        raise NotImplementedError

    def calculate(self):
        """
        计算
        Returns
        -------
        selection_res: 选股能力
        timing_res: 择时能力
        fit_result: 回归结果
        """
        import statsmodels.api as sm
        excess_rate = self.portfolio_return_list - self.risk_free_rate
        x = self.construct_x()
        fit_result = sm.OLS(excess_rate, x).fit()
        timing_res = self.get_timing_res(fit_result)
        selection_res = self.get_selection_res(fit_result)
        # 收缩
        if self.is_shrink:
            timing_res = self.shrink(fit_result.pvalues['coe2'], self.shrink_p, fit_result.tvalues['coe2'],
                                     fit_result.nobs - 1, timing_res)
            if 'const' in fit_result.params:
                selection_res = self.shrink(fit_result.pvalues['const'], self.shrink_p, fit_result.tvalues['const'],
                                            fit_result.nobs - 1, selection_res)
        return selection_res, timing_res, fit_result

    @staticmethod
    def shrink(p_value: float, shrink_p: float, t_value: float, n: int, res: float):
        """
        对择时选股结果收缩

        Parameters
        ----------
        p_value: 回归的p值
        shrink_p: 收缩的p值阈值
        t_value: 回归的t值
        n: 自由度
        res: 择时或选股能力

        Returns
        -------
        收缩后的择时或选股能力
        """
        if p_value > shrink_p:
            import scipy.stats as ss
            shrink_ratio = np.abs(t_value) / np.abs(ss.t(n).ppf(1 - shrink_p / 2))
            return res * shrink_ratio
        return res


class HM(TimingSelectionRegressModel):
    """
    HM择时选股模型
    """

    def construct_x(self) -> pd.DataFrame:
        import statsmodels.api as sm
        coe_beta1 = self.benchmark_return_list - self.risk_free_rate
        coe_beta2 = np.multiply(coe_beta1, coe_beta1 > 0)
        x_hm = pd.DataFrame({'coe1': coe_beta1, 'coe2': coe_beta2})
        x_hm = sm.add_constant(x_hm)
        return x_hm

    def get_selection_res(self, fit_result) -> float:
        if 'const' in fit_result.params:
            selection_res = fit_result.params['const']
        else:
            selection_res = None
        return selection_res

    def get_timing_res(self, fit_result) -> float:
        timing_res = fit_result.params['coe2']
        return timing_res


class TM(TimingSelectionRegressModel):
    """
    TM择时选股模型
    """

    def construct_x(self) -> pd.DataFrame:
        coe_beta1 = self.benchmark_return_list - self.risk_free_rate
        coe_beta2 = coe_beta1 ** 2
        x_tm = pd.DataFrame({'coe1': coe_beta1, 'coe2': coe_beta2})
        return x_tm

    def get_selection_res(self, fit_result) -> float:
        if 'const' in fit_result.params:
            selection_res = fit_result.params['const']
        else:
            selection_res = None
        return selection_res

    def get_timing_res(self, fit_result) -> float:
        timing_res = fit_result.params['coe2']
        return timing_res


class CL(TimingSelectionRegressModel):
    """
    CL择时选股模型
    """

    def construct_x(self) -> pd.DataFrame:
        benchmark_excess_return = self.benchmark_return_list - self.risk_free_rate
        coe_beta1 = np.multiply(benchmark_excess_return, benchmark_excess_return < 0)
        coe_beta2 = np.multiply(benchmark_excess_return, benchmark_excess_return > 0)
        x_cl = pd.DataFrame({'coe1': coe_beta1, 'coe2': coe_beta2})
        return x_cl

    def get_selection_res(self, fit_result) -> float:
        if 'const' in fit_result.params:
            selection_res = fit_result.params['const']
        else:
            selection_res = None
        return selection_res

    def get_timing_res(self, fit_result) -> float:
        timing_res = fit_result.params['coe2'] - fit_result.params['coe1']
        return timing_res
