"""
RBSA(Return Based Style Analysis)基于收益率的风格分析
"""
from typing import Tuple, Dict, Optional

import numpy as np
import pandas as pd
from scipy.optimize import minimize


class RBSA(object):
    def __init__(self, return_series: pd.Series, df_style_return: pd.DataFrame):
        """
        RBSA(Return Based Style Analysis)基于收益率的风格分析
        Parameters
        ----------
        return_series: 待分析收益率序列, index为日期, value为收益率
        df_style_return: 风格收益率序列
        +--------+-------------+------------+----------+
        |  字段  |     含义    |    类型    |   示例   |
        +--------+-------------+------------+----------+
        |  date  |     日期    | str, index | 20210727 |
        | style1 | 风格1收益率 |   float    |   0.02   |
        | style2 | 风格2收益率 |   float    |   0.03   |
        |  ...   |     ...     |   float    |   ...    |
        +--------+-------------+------------+----------+
        """
        self.return_series = return_series
        self.df_style_return = df_style_return

    @staticmethod
    def error_func(w, x_train, y_train):
        return np.sum(np.square(np.dot(x_train, w) - y_train))

    @staticmethod
    def constraint_weight_sum(w):
        return np.sum(w) - 1.0

    def cal_r_square(self, weight, x, y):
        sse = self.error_func(weight, x, y)
        sst = (np.sum(np.square(y - np.mean(y))))
        return 1 - sse / sst

    @staticmethod
    def constraint_weight_nonzero(w):
        return w

    def optimize(self) -> Optional[Tuple[Dict, float]]:
        """
        优化求解权重
        :return: 回归权重, R方解释度
        """
        x = self.df_style_return
        y = self.return_series
        if x.shape[0] <= x.shape[1]:
            return None
        cons = ({'type': 'eq', 'fun': self.constraint_weight_sum},
                {'type': 'ineq', 'fun': self.constraint_weight_nonzero})
        w_init = np.ones(x.shape[1]) / x.shape[1]
        res = minimize(self.error_func, w_init, args=(x, y), method='SLSQP', constraints=cons)
        r_squared = self.cal_r_square(res.x, x, y)
        weights = dict(zip(x.columns, res.x))
        return weights, r_squared


if __name__ == '__main__':
    return_series = pd.Series([5.0, 4.0, 3.0, 2.0, 1.0], index=[2000, 2001, 2002, 2003, 2004])
    df_style_return = pd.DataFrame({"style1": [5.1, 4.2, 3.2, 2.4, 0.8], "style2": [3.1, 2.5, 5.1, 2.5, 1.1]},
                                   index=[2000, 2001, 2002, 2003, 2004])
    weights, r_squared = RBSA(return_series, df_style_return).optimize()
    print(weights, r_squared)
