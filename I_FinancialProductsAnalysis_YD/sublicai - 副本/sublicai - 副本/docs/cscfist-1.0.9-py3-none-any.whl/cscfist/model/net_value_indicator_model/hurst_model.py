import numpy as np


def cal_hurst(portfolio_return_list, min_num_in_group=10):
    """
    赫斯特指数
    """
    n = len(portfolio_return_list)
    max_k = int(np.floor(n / 2))  # k为每组个数
    r_s_dict = []
    for k in range(min_num_in_group, max_k + 1):
        # 每组k个元素
        subset_list = [portfolio_return_list[i: i + k] for i in range(0, n, k)]
        # 若最后一组个数不均分, 则删掉
        if np.mod(n, k) > 0:
            subset_list.pop()
        df_subset = np.array(subset_list)
        df_mean = df_subset.mean(axis=1).reshape(-1, 1)
        df_cumsum = (df_subset - df_mean).cumsum(axis=1)
        r = df_cumsum.max(axis=1) - df_cumsum.min(axis=1) + np.spacing(1)
        s = df_subset.std(axis=1, ddof=0) + np.spacing(1)
        r_s_dict.append({'R_S': (r / s).mean(), 'N': k})
    log_r_s = []
    log_n = []
    for i in range(len(r_s_dict)):
        log_r_s.append(np.log(r_s_dict[i]['R_S']))
        log_n.append(np.log(r_s_dict[i]['N']))
    try:
        res = np.polyfit(log_n, log_r_s, 1)[0]
    except:
        res = None

    return res
