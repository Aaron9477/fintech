"""
计算k阶最大回撤
"""

from typing import Tuple, List, Dict

import numpy as np
import pandas as pd


def cal_max_draw_down(section_nav: pd.Series):
    """
    计算1阶最大回撤

    Parameters
    ----------
    section_nav: 净值序列

    Returns
    -------
    最大回撤, 最大回撤回补天数, 最大回撤开始日期, 最大回撤结束日期, 最大回撤回补时间, 平均回撤
    """
    nav_list = section_nav.values
    date_list = section_nav.index.tolist()
    draw_down_list = (nav_list - np.maximum.accumulate(nav_list)) / np.maximum.accumulate(nav_list)
    draw_down_mean = float(np.nanmean(draw_down_list))
    j = int(np.argmin(draw_down_list))  # 结束位置
    max_drawdown = draw_down_list[j]
    if j == 0 or max_drawdown == 0:  # 净值单调不减, 无回撤, 或前order-1大回撤已经置为0, order已无回撤
        return 0.0, None, None, None, None, draw_down_mean
    i = int(np.argmax(nav_list[:j]))  # 开始位置
    refill_index = np.arange(j, len(nav_list))[nav_list[j:] >= nav_list[i]]
    if len(refill_index) == 0:
        max_drawdown_refill_days = None
        max_drawdown_refill_date = None
    else:
        max_drawdown_refill_days = refill_index[0] - j
        max_drawdown_refill_date = date_list[refill_index[0]]
    max_drawdown_begin_date = date_list[i]
    max_drawdown_end_date = date_list[j]
    return (max_drawdown, max_drawdown_refill_days, max_drawdown_begin_date, max_drawdown_end_date,
            max_drawdown_refill_date, draw_down_mean)


def cal_sub_sections(total_list: List[str], sub_list: List[Tuple[str, str]]) -> List[np.ndarray]:
    """
    从完整list(total_list)中将子list(sub_list)去除，剩余元素分块返回子版块
    在计算第k回撤时, 需要将第1到第k-1大回撤区间删除, 在剩余k个区间中分别算最大回撤, 作为第k回撤结果
    例如
    total_list = ["2000", "2001", "2002", "2003", "2005", "2006", "2007", "2008", "2009"]
    sub_list = [("2001", "2003"), ("2006", "2007")]
    则list_diff(total_list, sub_list)结果应为[["2000",], ["2005", ], ["2008", "2009"]]

    Parameters
    ----------
    total_list: 完整list
    sub_list: 子list

    Returns
    -------
    子版块

    Examples
    --------
    >>> total_list = ["2000", "2001", "2002", "2003", "2005", "2006", "2007", "2008", "2009"]
    >>> sub_list = [("2001", "2003"), ("2006", "2007")]
    >>> cal_sub_sections(total_list, sub_list))
    [array(['2000'], dtype='<U4'), array(['2005'], dtype='<U4'), array(['2008', '2009'], dtype='<U4')]
    """
    total_list = np.array(total_list)
    sub_list.sort()
    begin_date_list = [g[0] for g in sub_list]
    end_date_list = [g[1] for g in sub_list]
    begin_index = np.searchsorted(total_list, begin_date_list)
    end_index = np.searchsorted(total_list, end_date_list) + 1
    key_index = np.r_[0, begin_index, end_index, len(total_list)]
    key_index.sort()
    diff_index = np.split(np.array(key_index), len(key_index) / 2)
    res = []
    for single_index in diff_index:
        if single_index[0] < single_index[1]:
            res.append(total_list[single_index[0]: single_index[1]])
    return res


def cal_k_max_draw_down(nav: pd.Series, k: int) -> Tuple[List[Dict], float]:
    """
    计算k大回撤相关指标

    Parameters
    ----------
    nav: 净值序列
    k: 分析前k大回撤

    Returns
    -------
    res_list, draw_down_mean. 其中res_list是k维list, list内元素是字典, Key包括max_drawdown,
    max_drawdown_refill_days, max_drawdown_begin_date, max_drawdown_end_date. max_drawdown_refill_date.
    draw_down_mean是平均回撤

    (1) 当净值数据单调不减时, 最大回撤为0, 最大回撤回补天数为np.inf, 最大回撤开始日期为None, 最大回撤结束日期为None
    (2) 当净值未能完成回补时, 最大回撤回补天数为np.inf
    """

    draw_down_mean = None
    exclude_period_list = []  # 在进行第k大回撤等计算时，需要将k以前的回撤区间剔除
    res_list = []
    for order in range(1, k + 1):
        sub_sections = cal_sub_sections(list(nav.index), exclude_period_list)
        if len(sub_sections) == 0:
            res_list.append(
                {
                    "max_drawdown": None,
                    "max_drawdown_refill_days": None,
                    "max_drawdown_begin_date": None,
                    "max_drawdown_end_date": None,
                    "max_drawdown_refill_date": None,
                }
            )
            continue
        single_res_list = []
        # 在进行第k大回撤的分析时, 剔除前k-1大回撤区间, 得到k个子区间
        for section in sub_sections:
            single_nav = nav.loc[section]
            single_res_list.append(cal_max_draw_down(single_nav))
        # 取这k个区间的最大回撤作为第k大回撤
        sort_tuple = sorted(single_res_list, key=lambda x: x[0])
        (section_max_drawdown, section_max_drawdown_refill_days, section_max_drawdown_begin_date,
         section_max_drawdown_end_date, section_max_drawdown_refill_date, section_draw_down_mean) = sort_tuple[0]
        if section_max_drawdown_begin_date is not None and section_max_drawdown_end_date is not None:
            exclude_period_list.append((section_max_drawdown_begin_date, section_max_drawdown_end_date))
        # 平均回撤仅在计算最大回撤时保存
        if order == 1:
            draw_down_mean = section_draw_down_mean
        res_list.append(
            {
                "max_drawdown": section_max_drawdown,
                "max_drawdown_refill_days": section_max_drawdown_refill_days,
                "max_drawdown_begin_date": section_max_drawdown_begin_date,
                "max_drawdown_end_date": section_max_drawdown_end_date,
                "max_drawdown_refill_date": section_max_drawdown_refill_date,
            }
        )
    return res_list, draw_down_mean


if __name__ == '__main__':
    total_list = ["2000", "2001", "2002", "2003", "2005", "2006", "2007", "2008", "2009"]
    sub_list = [("2001", "2003"), ("2006", "2007")]
    print(cal_sub_sections(total_list, sub_list))
