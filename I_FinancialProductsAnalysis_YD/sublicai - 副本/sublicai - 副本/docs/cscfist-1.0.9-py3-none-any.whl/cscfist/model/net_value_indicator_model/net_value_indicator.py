from functools import partial
from typing import Optional, List
import numpy as np
import pandas as pd

from cscfist.model.net_value_indicator_model.hurst_model import cal_hurst
from cscfist.model.net_value_indicator_model.max_drawdown_model import cal_k_max_draw_down
from cscfist.model.net_value_indicator_model.selection_model import HM, TM, CL
from cscfist.model.net_value_indicator_model.stutzer_model import stutzer_index
from cscfist.tools import NatureDateUtils, class_cache, TradeDateUtils


def assure_length(func, is_align=False, min_length=2):
    """
    确保净值数据满足要求装饰器
    """

    def wrap(self, *args, **kwargs):
        if is_align:
            if self.portfolio_align_net_value_list is None or len(self.portfolio_align_net_value_list) < min_length:
                return None
        else:
            if self._net_value is None or len(self._net_value) < min_length:
                return None
        res = func(self, *args, **kwargs)
        return res

    return wrap


def assure_benchmark(func, is_align=False, min_length=2):
    """
    确保基准数据满足要求装饰器
    """

    def wrap(self, *args, **kwargs):
        if is_align:
            if self.benchmark_align_close_list is None or len(self.benchmark_align_close_list) < min_length:
                return None
        else:
            if self._benchmark_close is None or len(self._benchmark_close) < min_length:
                return None
        res = func(self, *args, **kwargs)
        return res

    return wrap


class NetValueIndicator(object):
    """
    净值计算类
    """
    PERIOD_CNT_IN_YEAR_DICT = {
        "d": 252,
        "w": 52,
        "m": 12,
        "q": 4,
        "h": 2,
        "y": 1
    }

    def __init__(self, net_value: pd.Series, benchmark_close: Optional[pd.Series], risk_free_rate: float, period="d",
                 trade_date_list=None):
        """
        Parameters
        ----------
        net_value: 组合净值序列
        benchmark_close: 基准指数序列
        risk_free_rate: 无风险收益率
        period: 周期, 包括d:日度, w:周度, m:月度, q:季度, h:半年度, y:年度
        """
        # 原始输入

        self._net_value = net_value
        self._benchmark_close = benchmark_close
        self._risk_free_rate = risk_free_rate
        self._period = period
        self.day_count_in_year = self.PERIOD_CNT_IN_YEAR_DICT[period]
        self.trade_date_list = trade_date_list
        self.trade_date_utils = None
        if trade_date_list is not None:
            self.trade_date_utils = TradeDateUtils(trade_date_list)
        # 缓存
        self.cache = {}
        # 净值列表
        self._net_value_list = None
        self._net_date_list = None
        self._benchmark_close_list = None
        self._benchmark_date_list = None
        # 收益率列表
        self._portfolio_return_list = None
        self._benchmark_return_list = None
        # 对齐后Series
        self._net_value_align = None
        self._benchmark_close_align = None
        # 对齐后净值列表
        self._portfolio_align_net_value_list = None
        self._benchmark_align_close_list = None
        # 对齐后收益率列表
        self._portfolio_align_return_list = None
        self._benchmark_align_return_list = None
        self._benchmark_align_annual_return = None
        self._portfolio_align_annual_return = None

    """
    +----------+
    |  净值列表  | 
    +----------+
    """

    @property
    def net_value_list(self) -> np.array:
        """
        净值序列
        """
        if self._net_value_list is None:
            self._net_value_list = self._net_value.values
        return self._net_value_list

    @property
    def net_date_list(self) -> np.array:
        """
        净值日期序列
        """
        if self._net_date_list is None:
            self._net_date_list = self._net_value.index.values
        return self._net_date_list

    @property
    @assure_benchmark
    def benchmark_close_list(self) -> np.array:
        """
        基准行情序列
        """
        if self._benchmark_close_list is None:
            self._benchmark_close_list = self._benchmark_close.values
        return self._benchmark_close_list

    @property
    @assure_benchmark
    def benchmark_date_list(self) -> np.array:
        """
        基准日期列表
        """
        if self._benchmark_date_list is None:
            self._benchmark_date_list = self._benchmark_close.index.values
        return self._benchmark_date_list

    """
    +------------+
    |  收益率列表  | 
    +------------+
    """

    @property
    def portfolio_return_list(self):
        if self._portfolio_return_list is None:
            self._portfolio_return_list = self.net_value_list[1:] / self.net_value_list[:-1] - 1
        return self._portfolio_return_list

    @property
    @partial(assure_benchmark, min_length=2)
    def benchmark_return_list(self):
        if self._benchmark_return_list is None:
            self._benchmark_return_list = self.benchmark_close_list[1:] / self.benchmark_close_list[:-1] - 1
        return self._benchmark_return_list

    """
    +-------------+
    |  对齐Series  | 
    +-------------+
    """

    @property
    @assure_benchmark
    def net_value_align(self):
        """
        对齐后的组合净值Series
        """
        if self._net_value_align is None:
            self._net_value_align = pd.concat([self._net_value, self._benchmark_close], axis=1, join='inner').iloc[
                                    :, 0]
        return self._net_value_align

    @property
    @assure_benchmark
    def benchmark_close_align(self):
        """
        对齐后的组合净值Series
        """
        if self._benchmark_close_align is None:
            self._benchmark_close_align = pd.concat([self._net_value, self._benchmark_close], axis=1,
                                                    join='inner').iloc[:, 1]
        return self._benchmark_close_align

    """
    +--------------+
    |  对齐净值列表  | 
    +--------------+
    """

    @property
    @assure_benchmark
    def portfolio_align_net_value_list(self):
        """
        与基准对齐后的净值序列
        """
        if self._portfolio_align_net_value_list is None:
            self._portfolio_align_net_value_list = self.net_value_align.values
            return self._portfolio_align_net_value_list
        else:
            return self._portfolio_align_net_value_list

    @property
    @assure_benchmark
    def benchmark_align_close_list(self):
        """
        基准对齐后的行情序列
        """
        if self._benchmark_align_close_list is None:
            if self.benchmark_close_align is not None:
                self._benchmark_align_close_list = self.benchmark_close_align.values
        return self._benchmark_align_close_list

    """
    +---------------+
    |  对齐收益率列表  | 
    +---------------+
    """

    @property
    @partial(assure_benchmark, is_align=True, min_length=2)
    def portfolio_align_return_list(self):
        """
        对齐后的净值收益率序列
        """
        if self._portfolio_align_return_list is None:
            self._portfolio_align_return_list = (self.portfolio_align_net_value_list[1:] /
                                                 self.portfolio_align_net_value_list[:-1] - 1)
        return self._portfolio_align_return_list

    @property
    @partial(assure_benchmark, is_align=True, min_length=2)
    def benchmark_align_return_list(self):
        """
        对齐后的基准行情序列
        """
        if self._benchmark_align_return_list is None:
            self._benchmark_align_return_list = self.benchmark_align_close_list[
                                                1:] / self.benchmark_align_close_list[:-1] - 1
        return self._benchmark_align_return_list

    @property
    @partial(assure_benchmark, is_align=True, min_length=2)
    def portfolio_align_annual_return(self) -> float:
        """
        对齐后组合年化收益率
        """
        if self._portfolio_align_annual_return is None:
            portfolio_align_return = self.portfolio_align_net_value_list[-1] / self.portfolio_align_net_value_list[
                0] - 1
            res = self._annual_return_factor(portfolio_align_return, len(self.portfolio_align_return_list))
            self._portfolio_align_annual_return = res
        return self._portfolio_align_annual_return

    @property
    @partial(assure_benchmark, is_align=True, min_length=2)
    def benchmark_align_annual_return(self) -> float:
        """
        对齐后基准年化收益率
        """
        if self._benchmark_align_annual_return is None:
            market_align_return = self.benchmark_align_close_list[-1] / self.benchmark_align_close_list[0] - 1
            res = self._annual_return_factor(market_align_return, len(self.benchmark_align_return_list))
            self._benchmark_align_annual_return = res
        return self._benchmark_align_annual_return

    @property
    def df_return(self) -> pd.DataFrame:
        """
        组合收益率DataFrame形式

        Returns
        -------
        +-------+--------+-------+------------+
        |  字段 |  含义  |  类型 |    示例    |
        +-------+--------+-------+------------+
        |  date |  日期  |  str  | 20210727.0 |
        | yield | 收益率 | float |    0.02    |
        +-------+--------+-------+------------+
        """
        return pd.DataFrame({"date": self.net_date_list[1:], "yield": self.portfolio_return_list})

    @property
    @assure_benchmark
    def df_market_bm(self) -> pd.DataFrame:
        """
        基准收益率DataFrame形式
        """
        return pd.DataFrame({"date": self.benchmark_date_list[1:], "yield": self.benchmark_return_list})

    """
    +----------+
    |  工具函数  | 
    +----------+
    """

    def _annual_return_factor(self, total_return: float, count: int) -> Optional[float]:
        """
        对收益率做年化, 如果1年以上则复利, 如果1年以内则单利

        Parameters
        ----------
        total_return: 原始收益率
        count: 年化后的结果
        """
        if count == 0:
            return None
        if count <= self.day_count_in_year and total_return > 0:  # 单利
            return self.day_count_in_year / count * total_return
        else:  # 复利
            return (1 + total_return) ** (self.day_count_in_year / count) - 1

    def _annual_std_factor(self, total_std: float) -> float:
        """
        对标准差做年化

        Parameters
        ----------
        total_std: 原始标准差

        Returns
        -------
        年化后的结果
        """
        return total_std * np.sqrt(self.day_count_in_year)

    """
    +----------+
    |  模型计算  | 
    +----------+
    """

    @class_cache
    def cal_portfolio_max_drawdown(self, k: int):
        """
        计算组合最大回撤

        Parameters
        ----------
        k: 阶数
        """
        nav = self._net_value
        res_list, drawdown_mean = cal_k_max_draw_down(nav, k)
        return res_list, drawdown_mean

    @class_cache
    @partial(assure_benchmark, is_align=True)
    def cal_portfolio_excess_max_drawdown(self, k: int):
        """
        计算组合超额最大回撤

        Parameters
        ----------
        k: 阶数
        """
        portfolio_nav_from_1 = self.net_value_align / self.net_value_align[0]
        benchmark_nav_from_1 = self.benchmark_close_align / self.benchmark_close_align[0]
        nav = portfolio_nav_from_1 - benchmark_nav_from_1 + 1
        res_list, drawdown_mean = cal_k_max_draw_down(nav, k)
        return res_list, drawdown_mean

    @class_cache
    @partial(assure_benchmark, is_align=True, min_length=2)
    def cal_portfolio_selection_timing(self, model_type, is_shrink: bool = False, shrink_p: float = 0.05):
        """
        择时选股能力计算
        Parameters
        ----------
        model_type: 模型类型, 包括HM、TM、CL
        is_shrink: 是否收缩
        shrink_p: 收缩时的p值

        Returns
        -------
        selection_res: 选股能力
        timing_res: 择时能力
        fit_result: 回归结果
        """
        selection_res = None
        timing_res = None
        fit_result = None
        if model_type == "HM":
            model = HM(self.portfolio_align_return_list, self.benchmark_align_return_list,
                       self._risk_free_rate / self.day_count_in_year, is_shrink, shrink_p)
            selection_res, timing_res, fit_result = model.calculate()
        if model_type == "TM":
            model = TM(self.portfolio_align_return_list, self.benchmark_align_return_list,
                       self._risk_free_rate / self.day_count_in_year, is_shrink, shrink_p)
            selection_res, timing_res, fit_result = model.calculate()
        if model_type == "CL":
            model = CL(self.portfolio_align_return_list, self.benchmark_align_return_list,
                       self._risk_free_rate / self.day_count_in_year, is_shrink, shrink_p)
            selection_res, timing_res, fit_result = model.calculate()
        return selection_res, timing_res, fit_result

    """
    +----------+
    |  指标计算  | 
    +----------+
    """

    @class_cache
    def interval_return(self, is_annual: bool = False) -> float:
        """
        区间收益率

        Args:
            is_annual: 是否年化
        """
        res = self.net_value_list[-1] / self.net_value_list[0] - 1
        if is_annual:
            res = self._annual_return_factor(res, len(self.net_value_list) - 1)
        return res

    @partial(assure_benchmark, min_length=2)
    @class_cache
    def benchmark_return(self, is_annual: bool = False) -> float:
        """
        基准收益率

        Args:
            is_annual: 是否年化
        """
        res = self.benchmark_close_list[-1] / self.benchmark_close_list[0] - 1
        if is_annual:
            res = self._annual_return_factor(res, len(self.benchmark_close_list) - 1)
        return res

    @partial(assure_benchmark, min_length=2)
    @class_cache
    def excess_return(self, is_annual: bool = False) -> float:
        """
        超额收益率

        Parameters
        ----------
        is_annual: 是否年化
        """
        return self.interval_return(is_annual) - self.benchmark_return(is_annual)

    @class_cache
    def excess_risk_free_return(self, is_annual: bool = False) -> float:
        """
        超额无风险收益率
        Args:
            is_annual: 是否年化

        Returns:

        """
        return self.interval_return(is_annual) - self._risk_free_rate

    @class_cache
    def avg_return(self, average_method: str = "geo") -> float:
        """
        平均组合收益率

        Parameters
        ----------
        average_method: 平均方式, 包括geo: 几何平均, arith: 算数平均
        """
        res = None
        if average_method == "geo":
            res = (np.prod(1 + self.portfolio_return_list)) ** (1.0 / len(self.portfolio_return_list)) - 1
        elif average_method == "arith":
            res = np.mean(self.portfolio_return_list)
        return res

    @partial(assure_benchmark, min_length=2)
    @class_cache
    def avg_benchmark_return(self, average_method: str = "geo") -> float:
        """
        平均基准收益率

        Parameters
        ----------
        average_method: 平均方式, 包括geo: 几何平均, arith: 算数平均
        """
        res = None
        if average_method == "geo":
            res = (np.prod(1 + self.benchmark_return_list)) ** (1.0 / len(self.benchmark_return_list)) - 1
        elif average_method == "arith":
            res = np.mean(self.benchmark_return_list)
        return res

    @partial(assure_benchmark, min_length=2)
    @class_cache
    def avg_excess_return(self, average_method: str = "geo") -> float:
        """
        平均超额收益率

        Parameters
        ----------
        average_method: 平均方式, 包括geo: 几何平均, arith: 算数平均
        """
        return self.avg_return(average_method) - self.avg_benchmark_return(average_method)

    @class_cache
    def max_single_period_return(self) -> float:
        """
        最高单期回报
        """
        return max(self.portfolio_return_list)

    @class_cache
    def min_single_period_return(self) -> float:
        """
        最低单期回报
        """
        return min(self.portfolio_return_list)

    @class_cache
    def continuous_hold_return_list(self, hold_period_type: str = "1m", is_annual=False) -> List:
        """
        连续持有收益列表
        Args:
            hold_period_type: 持有时长

        Returns:
            连续持有的收益列表
        """
        hold_return_list = []
        for i in range(len(self.net_date_list)):
            begin_date = self.net_date_list[i]
            end_date = self.trade_date_utils.date_period_change(begin_date, hold_period_type)
            if end_date > self.net_date_list[-1]:
                break
            begin_net_value = self.net_value_list[i]
            idx = self.net_date_list.searchsorted(end_date)
            end_net_value = self.net_value_list[idx]
            interval_return = end_net_value / begin_net_value - 1
            if is_annual:
                interval_return = self._annual_return_factor(interval_return, idx - i)
            hold_return_list.append(interval_return)
        return hold_return_list

    @class_cache
    def continuous_hold_return_date_list(self, hold_period_type: str = "1m", is_annual=False) -> List:
        """
        连续持有收益日期列表
        Args:
            hold_period_type: 持有时长

        Returns:
            连续持有的收益列表
        """
        hold_date_list = []
        for i in range(len(self.net_date_list)):
            begin_date = self.net_date_list[i]
            end_date = self.trade_date_utils.date_period_change(begin_date, hold_period_type)
            if end_date > self.net_date_list[-1]:
                break
            begin_net_value = self.net_value_list[i]
            idx = self.net_date_list.searchsorted(end_date)
            end_net_value = self.net_value_list[idx]
            interval_return = end_net_value / begin_net_value - 1
            if is_annual:
                interval_return = self._annual_return_factor(interval_return, idx - i)
            hold_date_list.append((begin_date, end_date, interval_return))
        return hold_date_list

    @class_cache
    def continuous_hold_avg_return(self, hold_period_type: str = "1m", is_annual=False) -> float:
        """
        连续持有平均收益

        Parameters
        ----------
        hold_period_type: 持有时长
        """
        return np.mean(self.continuous_hold_return_list(hold_period_type, is_annual))

    @class_cache
    def continuous_hold_max_return(self, hold_period_type: str = "1m", is_annual=False) -> float:
        """
        连续持有最高收益

        Parameters
        ----------
        hold_period_type: 持有时长
        """
        return np.max(self.continuous_hold_return_list(hold_period_type, is_annual))

    @class_cache
    def continuous_hold_min_return(self, hold_period_type: str = "1m", is_annual=False) -> float:
        """
        连续持有最低收益

        Parameters
        ----------
        hold_period_type: 持有时长
        """
        return np.min(self.continuous_hold_return_list(hold_period_type, is_annual))

    @class_cache
    @assure_length
    def volatility(self, is_annual: bool = True):
        """
        波动率

        Parameters
        ----------
        is_annual: 是否年化
        """
        res = self.portfolio_return_list.std(ddof=1)
        if is_annual:
            res = self._annual_std_factor(res)
        return res

    @partial(assure_benchmark, min_length=2)
    @class_cache
    def benchmark_volatility(self, is_annual: bool = True):
        """
        基准波动率

        Parameters
        ----------
        is_annual: 是否年化
        """
        if len(self.benchmark_return_list) < 2:
            res = 0
        else:
            res = self.benchmark_return_list.std(ddof=1)
        if is_annual:
            res = self._annual_std_factor(res)
        return res

    @partial(assure_benchmark, min_length=2)
    @class_cache
    def excess_volatility(self, is_annual: bool = True):
        """
        超额波动
        """
        excess_return = self.portfolio_align_return_list - self.benchmark_align_return_list
        if len(excess_return) < 2:
            res = 0
        else:
            res = excess_return.std(ddof=1)
        if is_annual:
            res = self._annual_std_factor(res)
        return res

    @assure_length
    @class_cache
    def down_volatility(self, is_annual: bool = True):
        """
        下行波动率

        Parameters
        ----------
        is_annual: 是否年化
        """
        diff = self.portfolio_return_list - self._risk_free_rate / self.day_count_in_year
        diff[diff > 0] = 0.
        sum_mean_squares = np.sum(np.square(diff))
        res = np.sqrt(sum_mean_squares / (len(diff) - 1))
        if is_annual:
            res = self._annual_std_factor(res)
        return res

    @assure_length
    @class_cache
    def down_volatility_tgb(self, is_annual: bool = True):
        """
        下行波动率(托管部)

        Parameters
        ----------
        is_annual: 是否年化
        """
        diff = self.portfolio_return_list
        diff[diff > 0] = 0.
        res = float(np.std(diff, ddof=1))
        if is_annual:
            res = self._annual_std_factor(res)
        return res

    @assure_length
    @class_cache
    def up_volatility(self, is_annual: bool = True):
        """
        上行波动率

        Parameters
        ----------
        is_annual: 是否年化
        """
        diff = self.portfolio_return_list - self._risk_free_rate / self.day_count_in_year
        diff[diff < 0] = 0.
        sum_mean_squares = np.sum(np.square(diff))
        res = np.sqrt(sum_mean_squares / (len(diff) - 1))
        if is_annual:
            res = self._annual_std_factor(res)
        return res

    @class_cache
    def max_drawdown(self, k=1) -> Optional[float]:
        """
        最大回撤
        """
        res_list, drawdown_mean = self.cal_portfolio_max_drawdown(k)
        return res_list[k - 1]["max_drawdown"]

    max_draw_down = max_drawdown

    @class_cache
    def max_drawdown_refill_days(self, k=1) -> Optional[int]:
        """
        最大回撤回补天数
        """
        res_list, drawdown_mean = self.cal_portfolio_max_drawdown(k)
        return res_list[k - 1]["max_drawdown_refill_days"]

    max_draw_down_refill_days = max_drawdown_refill_days

    @class_cache
    def max_drawdown_refill_date(self, k=1) -> Optional[int]:
        """
        最大回撤回补天数
        """
        res_list, drawdown_mean = self.cal_portfolio_max_drawdown(k)
        return res_list[k - 1]["max_drawdown_refill_date"]

    max_draw_down_refill_date = max_drawdown_refill_date

    @class_cache
    def max_drawdown_begin_date(self, k=1) -> Optional[int]:
        """
        最大回撤开始时间
        """
        res_list, drawdown_mean = self.cal_portfolio_max_drawdown(k)
        return res_list[k - 1]["max_drawdown_begin_date"]

    max_draw_down_begin_date = max_drawdown_begin_date

    @class_cache
    def max_drawdown_end_date(self, k=1) -> Optional[int]:
        """
        最大回撤开始时间
        """
        res_list, drawdown_mean = self.cal_portfolio_max_drawdown(k)
        return res_list[k - 1]["max_drawdown_end_date"]

    max_draw_down_end_date = max_drawdown_end_date

    @class_cache
    def drawdown_mean(self, k=1) -> float:
        """
        平均最大回撤
        """
        res_list, drawdown_mean = self.cal_portfolio_max_drawdown(k)
        return drawdown_mean

    mean_max_draw_down = drawdown_mean

    @partial(assure_benchmark, is_align=True)
    @class_cache
    def excess_max_drawdown(self, k=1):
        """
        超额最大回撤
        """
        res_list, drawdown_mean = self.cal_portfolio_excess_max_drawdown(k)
        return res_list[k - 1]["max_drawdown"]

    excess_max_draw_down = excess_max_drawdown

    @partial(assure_benchmark, is_align=True)
    @class_cache
    def excess_max_drawdown_refill_days(self, k=1):
        """
        超额最大回撤回补天数
        """
        res_list, drawdown_mean = self.cal_portfolio_excess_max_drawdown(k)
        return res_list[k - 1]["max_drawdown_refill_days"]

    excess_max_draw_down_refill_days = excess_max_drawdown_refill_days

    @partial(assure_benchmark, is_align=True)
    @class_cache
    def mean_excess_max_drawdown(self, k=1) -> float:
        """
        平均超额回撤
        """
        res_list, drawdown_mean = self.cal_portfolio_excess_max_drawdown(k)
        return drawdown_mean

    mean_excess_max_draw_down = mean_excess_max_drawdown

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def tracking_error(self, is_annual=True) -> float:
        """
        跟踪误差

        Parameters
        ----------
        is_annual: 是否年化
        """
        res = (self.portfolio_align_return_list - self.benchmark_align_return_list).std(ddof=1)
        if is_annual:
            res = self._annual_std_factor(res)
        return res

    @class_cache
    def var(self, confidence: float = 0.95) -> float:
        """
        VaR

        Parameters
        ----------
        confidence: 置信度
        """
        res = np.percentile(self.portfolio_return_list, 100 * (1 - confidence))
        res = max(-res, 0)
        return res

    @class_cache
    def cvar(self, confidence: float = 0.95) -> np.ndarray:
        """
        CVaR

        Parameters
        ----------
        confidence: 置信度
        """
        var = np.percentile(self.portfolio_return_list, 100 * (1 - confidence))
        res = np.mean(self.portfolio_return_list[self.portfolio_return_list <= var])
        res = max(-res, 0)
        return res

    @class_cache
    def var_indicator(self, var_type="var", confidence: float = 0.95) -> float:
        """
        计算VaR/CVaR

        Args:
            var_type: VaR的类型
            confidence: 置信度

        """
        res = None
        if var_type.upper() == "VAR":
            res = self.var(confidence)
        elif var_type.upper() == "CVAR":
            res = self.cvar(confidence)
        return res

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def beta(self) -> float:
        """
        Beta
        """
        cov = np.cov(np.vstack([self.portfolio_align_return_list, self.benchmark_align_return_list]), ddof=1)
        if cov[1][1] == 0.0:
            res = np.nan
        else:
            res = cov[0][1] / cov[1][1]
        return res

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def alpha(self):
        """
        alpha
        """
        if len(self.portfolio_return_list) < 2:
            res = np.nan
        else:
            res = (self.portfolio_align_annual_return - self._risk_free_rate) - self.beta() * (
                    self.benchmark_align_annual_return - self._risk_free_rate)
        return res

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def corr(self) -> float:
        """
        相关系数
        """
        if len(self.portfolio_return_list) < 2:
            res = 0
        else:
            res = np.corrcoef(self.portfolio_align_return_list, self.benchmark_align_return_list)[0][1]
        return res

    @assure_length
    @partial(assure_benchmark, min_length=2)
    @class_cache
    def non_system_risk(self) -> float:
        """
        非系统性风险, sqrt(基金波动率^2-Beta^2*比较基准波动率^2), 理论上可近似计算为每日收益回归的残差平方
        """
        res = np.sqrt(
            self.volatility(is_annual=True) ** 2 - self.beta() ** 2 * self.benchmark_volatility(is_annual=True) ** 2)
        return res

    @assure_length
    @class_cache
    def skewness(self):
        """
        偏度
        """
        skewness = np.mean((self.portfolio_return_list - np.mean(self.portfolio_return_list)) ** 3) / pow(
            np.std(self.portfolio_return_list), 3.0)
        return skewness

    @partial(assure_benchmark, min_length=2)
    @class_cache
    def benchmark_skewness(self):
        """
        基准偏度
        """
        benchmark_skewness = np.mean((self.benchmark_return_list - np.mean(self.benchmark_return_list)) ** 3) / pow(
            np.std(self.benchmark_return_list), 3.0)
        return benchmark_skewness

    @assure_length
    @partial(assure_benchmark, min_length=2)
    @class_cache
    def excess_skewness(self):
        """
        超额偏度
        """
        excess_return = self.portfolio_align_return_list - self.benchmark_align_return_list
        excess_skewness = np.mean((excess_return - np.mean(excess_return)) ** 3) / pow(np.std(excess_return), 3.0)
        return excess_skewness

    @assure_length
    @partial(assure_benchmark, min_length=2)
    @class_cache
    def benchmark_kurtosis(self):
        """
        基准峰度
        """
        benchmark_kurtosis = np.mean((self.benchmark_return_list - np.mean(self.benchmark_return_list)) ** 4) / pow(
            np.std(self.benchmark_return_list), 4.0)
        return benchmark_kurtosis

    @assure_length
    @class_cache
    def kurtosis(self):
        """
        峰度
        """
        kurtosis = np.mean((self.portfolio_return_list - np.mean(self.portfolio_return_list)) ** 4) / pow(
            np.std(self.portfolio_return_list), 4.0)
        return kurtosis

    @assure_length
    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def excess_kurtosis(self):
        """
        超额峰度
        """
        excess_return = self.portfolio_align_return_list - self.benchmark_align_return_list
        excess_kurtosis = np.mean((excess_return - np.mean(excess_return)) ** 4) / pow(
            np.std(excess_return), 4.0)
        return excess_kurtosis

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def jensen_alpha(self):
        """
        詹森Alpha
        """
        if np.isnan(self.beta()):
            res = np.nan
        else:
            res = (self.portfolio_align_annual_return - self._risk_free_rate) - self.beta() * (
                    self.benchmark_align_annual_return - self._risk_free_rate)
        return res

    @partial(assure_benchmark, min_length=2)
    @assure_length
    @class_cache
    def m2(self) -> float:
        """
        M2测度
        """
        if self.volatility(is_annual=True) == 0:
            res = 0
        else:
            res = self._risk_free_rate + self.sharpe() * self.benchmark_volatility(
                is_annual=True) - self.benchmark_return(is_annual=True)
        return res

    @class_cache
    @assure_length
    def sharpe(self) -> float:
        """
        夏普比率
        """
        res = (self.interval_return(is_annual=True) - self._risk_free_rate) / self.volatility(is_annual=True)
        return res

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def excess_sharpe(self) -> float:
        """
        超额夏普比率
        """
        res = (self.excess_return(is_annual=True) - self._risk_free_rate) / self.excess_volatility(is_annual=True)
        return res

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def stutzer(self) -> float:
        """
        Stutzer指数
        """
        portfolio_nav_from_1 = self.net_value_align / self.net_value_align[0]
        benchmark_nav_from_1 = self.benchmark_close_align / self.benchmark_close_align[0]
        excess_nav = portfolio_nav_from_1[1:] / benchmark_nav_from_1[1:]
        return stutzer_index(excess_nav)

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def treynor(self):
        """
        特雷诺比率
        """
        if self.beta() == 0:
            res = np.inf * np.sign(self.interval_return(is_annual=True))
        else:
            res = self.excess_risk_free_return(is_annual=True) / self.beta()
        return res

    @assure_length
    @class_cache
    def sortino(self):
        """
        索提诺比率
        """
        res = self.excess_risk_free_return(is_annual=True) / self.down_volatility(is_annual=True)
        return res

    @assure_length
    @class_cache
    def sortino_tgb(self):
        """
        索提诺比率(托管部)
        """
        res = self.excess_risk_free_return(is_annual=True) / self.down_volatility_tgb(is_annual=True)
        return res

    @class_cache
    def up_potential(self):
        """
        上行潜力指数
        """
        diff = self.portfolio_return_list - self._risk_free_rate / self.day_count_in_year
        res = diff[diff > 0].mean() / self.down_volatility(is_annual=False)
        return res

    @class_cache
    def calmar(self):
        """
        卡玛比率
        """
        if np.isclose(self.max_draw_down(), 0):
            res = np.inf * np.sign(self.interval_return())
        else:
            res = self.interval_return(is_annual=True) / - self.max_draw_down()
        return res

    @class_cache
    def sterling(self, k: int = 1) -> float:
        """
        Sterling指数 = 年化收益率/前K大回撤平均值

        Parameters
        ----------
        k: 计算sterling指数时所用的前k大回撤
        """
        max_draw_down_list = [self.max_draw_down(i) for i in range(1, k + 1)]
        res = self.interval_return(is_annual=True) / -np.mean(max_draw_down_list)
        return res

    @class_cache
    def burke(self, k: int = 1):
        """
        Burke指数 = 年化收益率/sqrt(前k大回撤的平方和)
        """
        max_drawdown_list = [self.max_drawdown(i) for i in range(1, k + 1)]
        res = self.interval_return(is_annual=True) / np.sqrt(np.sum(np.array(max_drawdown_list) ** 2))
        return res

    @class_cache
    def raroc(self, var_type: str = 'var', confidence: float = 0.95):
        """
        RAROC指数 = （年化收益率 - 无风险收益率）/ 在险价值

        Parameters
        ----------
        var_type: VaR计算类型, 包括VaR、CVaR
        confidence: 置信度
        """
        var = self.var_indicator(var_type, confidence)
        if var is None:
            return None
        else:
            return self.excess_risk_free_return(is_annual=True) / var

    @assure_length
    @partial(assure_benchmark, min_length=2)
    @class_cache
    def information_ratio(self):
        """
        信息比率
        """
        if self.tracking_error(is_annual=True) == 0:
            res = None
        else:
            res = self.excess_return(is_annual=True) / self.tracking_error(is_annual=True)
        return res

    @class_cache
    def pos_num(self) -> int:
        """
        盈利周期数
        """
        res = np.sum(self.portfolio_return_list > 0)
        return res

    @class_cache
    def neg_num(self) -> int:
        """
        亏损周期数
        """
        res = np.sum(self.portfolio_return_list < 0)
        return res

    @class_cache
    def pos_ratio(self) -> float:
        """
        盈利期占比
        """
        res = self.pos_num() / len(self.portfolio_return_list)
        return res

    @class_cache
    def neg_ratio(self) -> float:
        """
        亏损期占比
        """
        res = self.neg_num() / len(self.portfolio_return_list)
        return res

    @class_cache
    def profit_loss_ratio(self) -> float:
        """
        盈亏比
        """
        res = self.pos_ratio() / abs(self.neg_ratio())
        return res

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def win_ratio(self) -> float:
        """
        超额收益胜率
        """
        return_diff = self.portfolio_align_return_list - self.benchmark_align_return_list
        res = np.sum(return_diff > 0) / len(return_diff)
        return res

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def pos_excess_return_mean(self):
        """
        超额收益上涨期间平均收益
        """
        excess_return = self.portfolio_align_return_list - self.benchmark_align_return_list
        res = np.mean(excess_return[excess_return >= 0])
        return res

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def neg_excess_return_mean(self):
        """
        超额收益下跌期间平均收益
        """
        excess_return = self.portfolio_align_return_list - self.benchmark_align_return_list
        res = np.mean(excess_return[excess_return < 0])
        return res

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def excess_profit_loss_ratio(self):
        """
        超额盈亏比
        """
        res = self.pos_excess_return_mean() / abs(self.neg_excess_return_mean())
        return res

    @assure_length
    @class_cache
    def return_auto_corr(self) -> float:
        """
        收益自相关系数
        """
        corr_array = np.corrcoef(self.portfolio_return_list[:-1], self.portfolio_return_list[1:])
        res = corr_array[0, 1]
        return res

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def excess_return_auto_corr(self) -> float:
        """
        超额收益自相关系数
        """
        excess_return = self.portfolio_align_return_list - self.benchmark_align_return_list
        corr_array = np.corrcoef(excess_return[:-1], excess_return[1:])
        res = corr_array[0, 1]
        return res

    @class_cache
    def return_hurst(self, min_num_in_group=2):
        """
        收益赫斯特指数
        """
        return cal_hurst(self.portfolio_return_list, min_num_in_group)

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def excess_return_hurst(self, min_num_in_group=2):
        """
        超额收益赫斯特指数
        """
        excess_return = self.portfolio_align_return_list - self.benchmark_align_return_list
        return cal_hurst(excess_return, min_num_in_group)

    @class_cache
    def high_count(self):
        """
        创新高次数
        """
        res = np.sum(self.net_value_list[1:] > np.maximum.accumulate(self.net_value_list[:-1]))
        return res

    @class_cache
    def up_avg_gain(self):
        """
        上涨期间平均收益
        """
        up_period_return = self.portfolio_return_list[self.portfolio_return_list > 0]
        return np.mean(up_period_return)

    @class_cache
    def down_avg_loss(self):
        """
        下跌期间平均收益
        """
        down_period_return = self.portfolio_return_list[self.portfolio_return_list < 0]
        return np.mean(down_period_return)

    @class_cache
    def continuous_hold_gain_prob(self, hold_period_type: str = "1m"):
        """
        连续持有盈利概率
        """
        hold_return_list = np.array(self.continuous_hold_return_list(hold_period_type))
        if len(hold_return_list) == 0:
            return None
        else:
            prob = len(hold_return_list[hold_return_list > 0]) / len(hold_return_list)
            return prob

    @class_cache
    def continuous_hold_loss_prob(self, hold_period_type: str = "1m"):
        """
        连续持有亏损概率
        """
        hold_return_list = np.array(self.continuous_hold_return_list(hold_period_type))
        if len(hold_return_list) == 0:
            return None
        else:
            prob = len(hold_return_list[hold_return_list < 0]) / len(hold_return_list)
            return prob

    @class_cache
    def continuous_hold_return_std(self, hold_period_type: str = "1m"):
        """
        连续持有收益标准差
        """
        hold_return_list = self.continuous_hold_return_list(hold_period_type)
        return np.std(hold_return_list, ddof=1)

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def up_capture(self, average_method: str = "geo") -> Optional[float]:
        """
        上行捕获能力
        """
        pos_index_ratio = self.benchmark_align_return_list[self.benchmark_align_return_list > 0]
        pos_days = len(pos_index_ratio)
        pos_net_value_ratio = self.portfolio_align_return_list[self.benchmark_align_return_list > 0]  # 使用指数上行日确定基金相应收益率
        res = None
        if len(pos_net_value_ratio) > 0 and len(pos_index_ratio) > 0:
            if average_method == 'geo':
                res = (np.prod(1 + pos_net_value_ratio) ** (1 / pos_days) - 1) / (
                        np.prod(1 + pos_index_ratio) ** (1 / pos_days) - 1)
            elif average_method == 'arith':
                res = np.mean(pos_net_value_ratio) - np.mean(pos_index_ratio)
        return res

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def up_capture_return(self) -> Optional[float]:
        """
        上行捕获收益率
        """
        pos_net_value_ratio = self.portfolio_align_return_list[self.benchmark_align_return_list > 0]  # 使用指数上行日确定基金相应收益率
        res = None
        if len(pos_net_value_ratio) > 0:
            res = self._annual_return_factor(np.prod(1 + pos_net_value_ratio) - 1, len(pos_net_value_ratio))
        return res

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def down_capture(self, average_method: str = "geo") -> Optional[float]:
        """
        下行捕获能力
        """
        neg_index_ratio = self.benchmark_align_return_list[self.benchmark_align_return_list < 0]
        neg_days = len(neg_index_ratio)
        neg_net_value_ratio = self.portfolio_align_return_list[self.benchmark_align_return_list < 0]  # 使用指数下行日确定基金相应收益率
        res = None
        if len(neg_net_value_ratio) > 0 and len(neg_index_ratio) > 0:
            if average_method == 'geo':
                res = (np.prod(1 + neg_net_value_ratio) ** (1 / neg_days) - 1) / (
                        np.prod(1 + neg_index_ratio) ** (1 / neg_days) - 1)
            elif average_method == 'arith':
                res = np.mean(neg_net_value_ratio) - np.mean(neg_index_ratio)
        return res

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def down_capture_return(self) -> Optional[float]:
        """
        下行捕获收益率
        """
        neg_net_value_ratio = self.portfolio_align_return_list[self.benchmark_align_return_list < 0]  # 使用指数下行日确定基金相应收益率
        res = None
        if len(neg_net_value_ratio) > 0:
            res = self._annual_return_factor(np.prod(1 + neg_net_value_ratio) - 1, len(neg_net_value_ratio))
        return res

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def up_minus_down_capture(self, average_method: str = "geo"):
        """
        弃用
        上行-下行捕获能力
        """
        if self.up_capture(average_method) is not None and self.down_capture(average_method) is not None:
            minus_capture = self.up_capture(average_method) - self.down_capture(average_method)
        else:
            minus_capture = None
        return minus_capture

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def timing_hm(self, is_shrink=True, shrink_p=0.05) -> float:
        """
        HM模型择时能力
        """
        selection_hm, timing_hm, estimate_hm = self.cal_portfolio_selection_timing(model_type='HM', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        return timing_hm

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def selection_hm(self, is_shrink=True, shrink_p=0.05) -> float:
        """
        HM模型选股能力
        """
        selection_hm, timing_hm, estimate_hm = self.cal_portfolio_selection_timing(model_type='HM', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        return selection_hm

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def timing_r2_hm(self, is_shrink=True, shrink_p=0.05) -> float:
        """
        HM模型择时选股R方
        """
        selection_hm, timing_hm, estimate_hm = self.cal_portfolio_selection_timing(model_type='HM', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        if abs(estimate_hm.rsquared) < 10000:
            hm_r = estimate_hm.rsquared  # r方也有可能爆炸
        else:
            hm_r = None
        return hm_r

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def selection_t_value_hm(self, is_shrink=True, shrink_p=0.05):
        """
        HM模型选证t_value
        """
        selection_hm, timing_hm, estimate_hm = self.cal_portfolio_selection_timing(model_type='HM', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        if 'const' in estimate_hm.tvalues and abs(estimate_hm.tvalues['const']) < 10000:
            selection_t_value_hm = estimate_hm.tvalues['const']  # 若净值无变化，则t值爆炸
        else:
            selection_t_value_hm = None
        return selection_t_value_hm

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def timing_t_value_hm(self, is_shrink=True, shrink_p=0.05):
        """
        HM模型择时能力t_value
        """
        selection_hm, timing_hm, estimate_hm = self.cal_portfolio_selection_timing(model_type='HM', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        if 'coe2' in estimate_hm.tvalues and abs(estimate_hm.tvalues['coe2']) < 10000:
            timing_t_value_hm = estimate_hm.tvalues['coe2']
        else:
            timing_t_value_hm = None
        return timing_t_value_hm

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def timing_tm(self, is_shrink=True, shrink_p=0.05) -> float:
        """
        TM模型择时能力
        """
        selection_tm, timing_tm, estimate_tm = self.cal_portfolio_selection_timing(model_type='TM', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        return timing_tm

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def selection_tm(self, is_shrink=True, shrink_p=0.05) -> float:
        """
        TM模型选股能力
        """
        selection_tm, timing_tm, estimate_tm = self.cal_portfolio_selection_timing(model_type='TM', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        return selection_tm

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def timing_r2_tm(self, is_shrink=True, shrink_p=0.05) -> float:
        """
        TM模型择时选股R方
        """
        selection_tm, timing_tm, estimate_tm = self.cal_portfolio_selection_timing(model_type='TM', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        if abs(estimate_tm.rsquared) < 10000:
            tm_r = estimate_tm.rsquared  # r方也有可能爆炸
        else:
            tm_r = None
        return tm_r

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def timing_t_value_tm(self, is_shrink=True, shrink_p=0.05):
        """
        TM模型择时能力t_value
        """
        selection_tm, timing_tm, estimate_tm = self.cal_portfolio_selection_timing(model_type='TM', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        if 'coe2' in estimate_tm.tvalues and abs(estimate_tm.tvalues['coe2']) < 10000:
            timing_t_value_tm = estimate_tm.tvalues['coe2']
        else:
            timing_t_value_tm = None
        return timing_t_value_tm

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def selection_t_value_tm(self, is_shrink=True, shrink_p=0.05):
        """
        TM模型选证t_value
        """
        selection_tm, timing_tm, estimate_tm = self.cal_portfolio_selection_timing(model_type='TM', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        if 'const' in estimate_tm.tvalues and abs(estimate_tm.tvalues['const']) < 10000:
            selection_t_value_tm = estimate_tm.tvalues['const']  # 若净值无变化，则t值爆炸
        else:
            selection_t_value_tm = None
        return selection_t_value_tm

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def timing_cl(self, is_shrink=True, shrink_p=0.05) -> float:
        """
        CL模型择时能力
        """
        selection_cl, timing_cl, estimate_cl = self.cal_portfolio_selection_timing(model_type='CL', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        return timing_cl

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def selection_cl(self, is_shrink=True, shrink_p=0.05) -> float:
        """
        CL模型选股能力
        """
        selection_cl, timing_cl, estimate_cl = self.cal_portfolio_selection_timing(model_type='CL', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        return selection_cl

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def timing_r2_cl(self, is_shrink=True, shrink_p=0.05) -> float:
        """
        CL模型择时选股R方
        """
        selection_cl, timing_cl, estimate_cl = self.cal_portfolio_selection_timing(model_type='CL', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        if abs(estimate_cl.rsquared) < 10000:
            cl_r = estimate_cl.rsquared  # r方也有可能爆炸
        else:
            cl_r = None
        return cl_r

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def timing_t_value_cl(self, is_shrink=True, shrink_p=0.05):
        """
        CL模型择时能力t_value
        """
        selection_tm, timing_tm, estimate_tm = self.cal_portfolio_selection_timing(model_type='CL', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        if 'coe2' in estimate_tm.tvalues and abs(estimate_tm.tvalues['coe2']) < 10000:
            timing_t_value_tm = estimate_tm.tvalues['coe2']
        else:
            timing_t_value_tm = None
        return timing_t_value_tm

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def selection_t_value_cl(self, is_shrink=True, shrink_p=0.05):
        """
        CL模型选证t_value
        """
        selection_tm, timing_tm, estimate_tm = self.cal_portfolio_selection_timing(model_type='CL', is_shrink=is_shrink,
                                                                                   shrink_p=shrink_p)
        if 'const' in estimate_tm.tvalues and abs(estimate_tm.tvalues['const']) < 10000:
            selection_t_value_tm = estimate_tm.tvalues['const']  # 若净值无变化，则t值爆炸
        else:
            selection_t_value_tm = None
        return selection_t_value_tm

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def timing(self, model_type='HM', is_shrink=True, shrink_p=0.05):
        if model_type == 'HM':
            return self.timing_hm(is_shrink, shrink_p)
        elif model_type == 'TM':
            return self.timing_tm(is_shrink, shrink_p)
        elif model_type == 'CL':
            return self.timing_cl(is_shrink, shrink_p)

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def selection(self, model_type='HM', is_shrink=True, shrink_p=0.05):
        if model_type == 'HM':
            return self.selection_hm(is_shrink, shrink_p)
        elif model_type == 'TM':
            return self.selection_tm(is_shrink, shrink_p)
        elif model_type == 'CL':
            return self.selection_cl(is_shrink, shrink_p)

    @partial(assure_benchmark, is_align=True, min_length=2)
    @class_cache
    def timing_r2(self, model_type='HM', is_shrink=True, shrink_p=0.05):
        if model_type == 'HM':
            return self.timing_r2_hm(is_shrink, shrink_p)
        elif model_type == 'TM':
            return self.timing_r2_tm(is_shrink, shrink_p)
        elif model_type == 'CL':
            return self.timing_r2_cl(is_shrink, shrink_p)

    # 正收益概率
    def pos_return_probability(self):
        return len(self.portfolio_return_list >= 0) / len(self.portfolio_return_list)

    # 负收益概率
    def neg_return_probability(self):
        return len(self.portfolio_return_list < 0) / len(self.portfolio_return_list)
    # 正收益平均
    # 负收益平均
    # 盈亏比


if __name__ == '__main__':
    date_list1 = ['20190121', '20190125', '20190222', '20190329', '20190426', '20190531', '20190628', '20190726',
                  '20190830', '20190927', '20191025', '20191129', '20191227', '20200131', '20200228', '20200327',
                  '20200424', '20200529', '20200731', '20200828', '20200925', '20201030', '20201127', '20201225',
                  '20210129', '20210226', '20210326', '20210430', '20210528', '20210625', '20210730', '20210827',
                  '20210924', '20211029', '20211126', '20211231', '20220128', '20220225', '20220325', '20220429',
                  '20220527', '20220624', '20220729', '20220826', '20220930', '20221028', '20221125', '20221230',
                  '20230127', '20230224', '20230331', '20230428', '20230526', '20230630', '20230707']
    value_list1 = [1.0, 1.0, 0.999, 1.001, 1.0, 1.013, 0.987, 0.993, 0.991, 0.954, 0.957, 0.963, 0.968, 0.972, 0.982,
                   0.984, 0.987, 0.989, 0.992, 0.993, 0.996, 1.0, 1.0, 1.005, 1.007, 1.009, 1.013, 1.016, 1.02, 1.022,
                   1.03, 1.035, 1.036, 1.043, 1.05, 1.05, 1.057, 1.057, 1.05, 1.061, 1.058, 1.058, 1.057, 1.061, 1.056,
                   1.06, 1.06, 1.041, 1.046, 1.064, 1.078, 1.08, 1.08, 1.079, 1.081]
    date_list2 = ['20190121', '20190125', '20190222', '20190329', '20190426', '20190531', '20190628', '20190726',
                  '20190830', '20190927', '20191025', '20191129', '20191227', '20200228', '20200327', '20200424',
                  '20200529', '20200731', '20200828', '20200925', '20201030', '20201127', '20201225', '20210129',
                  '20210226', '20210326', '20210430', '20210528', '20210625', '20210730', '20210827', '20210924',
                  '20211029', '20211126', '20211231', '20220128', '20220225', '20220325', '20220429', '20220527',
                  '20220624', '20220729', '20220826', '20220930', '20221028', '20221125', '20221230', '20230224',
                  '20230331', '20230428', '20230526', '20230630', '20230707']
    value_list2 = [3185.6364, 3184.4696, 3520.1182, 3872.3412, 3889.2748, 3629.7893, 3825.5873, 3858.5688, 3799.5863,
                   3852.6534, 3896.7923, 3828.6706, 4022.0278, 3940.0488, 3710.0605, 3796.9721, 3867.0232, 4695.0462,
                   4844.2652, 4570.0216, 4695.3338, 4980.765, 5042.0137, 5351.9646, 5336.7609, 5037.9899, 5123.489,
                   5321.0886, 5239.9684, 4811.1695, 4827.0433, 4849.4277, 4908.7701, 4860.1265, 4940.3733, 4563.772,
                   4573.4247, 4174.5742, 4016.241, 4001.2988, 4394.7723, 4170.1019, 4107.5455, 3804.8853, 3541.3295,
                   3775.7764, 3871.6338, 4061.0457, 4050.9257, 4029.0858, 3850.9511, 3842.4516, 3825.6988]
    fund_nav = pd.Series(value_list1, date_list1)
    benchmark_nav = pd.Series(value_list2, date_list2)
    risk_free_rate = 0.018279
    net_value_indicator = NetValueIndicator(fund_nav, benchmark_nav, risk_free_rate, period='m')
    res1 = net_value_indicator.win_ratio()
