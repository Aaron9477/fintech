"""
用于Stutzer指数的计算
该指数改进了夏普比率, 考虑了偏度和峰度
"""
import numpy as np


def stutzer_index(excess_nav: np.ndarray) -> float:
    """
    stutzer指数
    若超额收益率均值为负数, 则结果应返回0
    若超额收益率全部为正数, 则结果应返回inf
    若超额收益率服从正态分布, 则结果应与夏普比率一致

    Parameters
    ----------
    excess_nav: 超额收益率
    """
    if (excess_nav > 0).all():
        return np.inf
    from scipy.optimize import minimize
    res = minimize(lambda theta: np.log(np.sum(np.exp(excess_nav * theta)) / len(excess_nav)),
                   np.array([0.0]), bounds=[(-np.inf, 0)])
    res = abs(np.mean(excess_nav)) / np.mean(excess_nav) * np.sqrt(2 * -res.fun)
    return res


if __name__ == '__main__':
    a = (np.random.randn(100) / 10 + 1).cumprod()
    b = (np.random.randn(100) / 10 + 1).cumprod()
    excess_return = a - b
    excess_return = np.array(excess_return)
    print(excess_return.tolist())
    print("均值", np.mean(excess_return))
    print("标准差", np.std(excess_return))
    print("夏普", np.mean(excess_return) / np.std(excess_return))
    print("Stutzer", stutzer_index(excess_return))
