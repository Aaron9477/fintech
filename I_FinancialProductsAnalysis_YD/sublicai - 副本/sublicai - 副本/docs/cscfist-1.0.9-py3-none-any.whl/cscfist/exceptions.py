class AppException(Exception):
    """
    Base class for all App's errors.
    Each custom exception should be derived from this class
    """

    status_code = 500


class AppConfigException(AppException):
    """Raise when there is configuration problem"""


class AppOptionExpandException(AppException):
    """Raise when there is option expand problem"""


class NoOptionError(Exception):
    """Raise when there is no configuration option"""
